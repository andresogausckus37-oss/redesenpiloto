import { useCallback, useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import ArchivosPedido, { subirArchivosSemana } from "./ArchivosPedido";
import {
  ArrowRight, ChevronDown, ExternalLink, LogOut,
  RefreshCw, ShieldCheck, UserRound, Send,
  Check, ChevronLeft, ChevronRight, CloudUpload, FileImage, Film, Images,
  Heart, MessageCircle, MoreHorizontal, ThumbsUp, Trash2,
} from "lucide-react";

// Diseño del panel de cliente. Las rutas, los contratos de API y las autorizaciones
// Los pagos reales se gestionan por separado del cron y de la prueba gratuita.
const LOGOS = {
  instagram: "https://i.postimg.cc/1tGRTnck/3840px-Instagram-logo-2022-svg.png",
  facebook: "https://i.postimg.cc/rshTXS0k/Logo-de-Facebook.png",
};

function LogoRed({ red, size = 22 }) {
  return <img
    src={LOGOS[red]}
    alt={red === "instagram" ? "Instagram" : "Facebook"}
    loading="lazy"
    width={size}
    height={size}
    className="shrink-0 object-contain"
    style={{ width: size, height: size }}
  />;
}

const BASE = "/servicios/publicacion-automatica";
const API = "/api/servicios/clientes/panel";
const API_INSTAGRAM = "/api/servicios/meta/pedidos/instagram";
const PEDIDO_SESION = "pedido-publicaciones-transferencia-v1";
const VALIDAR_PEDIDO = /^SER-[a-f0-9-]{36}$/i;
const VALIDAR_CLAVE = /^[a-f0-9]{64}$/i;
const BTN = "inline-flex min-h-8 items-center justify-center gap-1.5 rounded-sm px-3 py-1.5 text-xs font-medium transition-all focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-terracota disabled:cursor-not-allowed disabled:opacity-50";
const BTN_PRIMARIO = `${BTN} border border-terracota bg-terracota text-white hover:border-terracota-oscuro hover:bg-terracota-oscuro active:bg-terracota-oscuro`;
const BTN_SECUNDARIO = `${BTN} border border-sky-300 bg-sky-100 text-sky-900 hover:border-sky-400 hover:bg-sky-200`;
const CARD = "rounded-sm border border-borde bg-white";
const CAMPO = "w-full min-h-9 rounded-sm border border-borde bg-white px-3 py-1.5 text-sm text-tinta outline-none focus:border-terracota focus:ring-2 focus:ring-terracota-suave";

const ESTADOS = {
  pendiente: "Pendiente", confirmado: "Confirmado", conectada: "Conectada",
  no_requerido: "Sin pago durante la prueba", pendiente_activacion: "Sin comenzar",
  prueba_en_preparacion: "En preparación", pendiente_carga: "Faltan archivos",
  pendiente_revision: "En revisión", aprobados: "Aprobados",
  sin_activar: "Sin activar", activo: "Activo", activado: "Activo",
  en_curso: "En curso", finalizado: "Finalizado", completado: "Completado",
  pendiente_preparacion: "Por preparar", pendiente_vinculacion: "Sin conectar",
  verificando: "En verificación", verificando_comprobante: "Revisando comprobante",
  verificando_pago: "Verificando pago", completando_operacion: "Pago confirmado",
  pendiente_comprobante: "Esperando comprobante", rechazado: "Requiere corrección",
  correccion_solicitada: "Requiere corrección", aprobado: "Aprobado",
  aprobado_tecnicamente: "Aprobado técnicamente", programado: "Programado",
  publicado: "Publicado", error: "Requiere atención",
};
function estado(valor) { return ESTADOS[valor] || String(valor || "Pendiente").replace(/_/g, " "); }
function redLabel(red) { return red === "instagram" ? "Instagram" : "Facebook"; }
function esAprobado(valor) { return ["aprobado", "aprobado_tecnicamente", "aprobados"].includes(valor); }
function tonoEstado(valor) {
  if (esAprobado(valor) || ["publicado", "conectada", "confirmado"].includes(valor)) return "border-emerald-200 bg-emerald-50 text-emerald-800";
  if (["rechazado", "correccion_solicitada", "error"].includes(valor)) return "border-amber-200 bg-amber-50 text-amber-800";
  return "border-sky-200 bg-sky-50 text-sky-800";
}
function Etiqueta({ valor, texto }) {
  return <span className={`inline-flex max-w-full items-center rounded-sm border px-2.5 py-1 text-[11px] font-medium ${tonoEstado(valor)}`}>
    {texto || estado(valor)}
  </span>;
}
function CampoInfo({ etiqueta, valor }) {
  return <div className="min-w-0">
    <p className="text-[11px] text-tinta-apagado">{etiqueta}</p>
    <p className="mt-0.5 break-words text-xs font-medium text-tinta">{valor}</p>
  </div>;
}

const ZONAS_DISPONIBLES = [
  { pais: "Argentina", zonas: [["America/Argentina/Buenos_Aires", "Buenos Aires"]] },
  { pais: "Belice", zonas: [["America/Belize", "Belmopán"]] },
  { pais: "Bolivia", zonas: [["America/La_Paz", "La Paz"]] },
  { pais: "Brasil", zonas: [
    ["America/Noronha", "Fernando de Noronha"],
    ["America/Manaus", "Manaos"],
    ["America/Rio_Branco", "Rio Branco"],
    ["America/Sao_Paulo", "São Paulo (Brasilia y la mayor parte del país)"],
  ] },
  { pais: "Chile", zonas: [
    ["America/Coyhaique", "Aysén / Coyhaique"],
    ["Pacific/Easter", "Isla de Pascua (Rapa Nui)"],
    ["America/Punta_Arenas", "Magallanes / Punta Arenas"],
    ["America/Santiago", "Santiago (zona central)"],
  ] },
  { pais: "Colombia", zonas: [["America/Bogota", "Bogotá"]] },
  { pais: "Costa Rica", zonas: [["America/Costa_Rica", "San José"]] },
  { pais: "Cuba", zonas: [["America/Havana", "La Habana"]] },
  { pais: "Ecuador", zonas: [
    ["Pacific/Galapagos", "Islas Galápagos"],
    ["America/Guayaquil", "Quito / Guayaquil (continental)"],
  ] },
  { pais: "El Salvador", zonas: [["America/El_Salvador", "San Salvador"]] },
  { pais: "España", zonas: [
    ["Atlantic/Canary", "Islas Canarias"],
    ["Europe/Madrid", "Madrid (península y Baleares)"],
  ] },
  { pais: "Estados Unidos", zonas: [
    ["America/Anchorage", "Alaska"],
    ["America/Chicago", "Central (Chicago / Dallas)"],
    ["America/Denver", "Montaña (Denver)"],
    ["America/New_York", "Este (Nueva York / Miami)"],
    ["Pacific/Honolulu", "Hawái"],
    ["America/Los_Angeles", "Pacífico (Los Ángeles)"],
    ["America/Phoenix", "Arizona (Phoenix, sin horario de verano)"],
  ] },
  { pais: "Guatemala", zonas: [["America/Guatemala", "Ciudad de Guatemala"]] },
  { pais: "Haití", zonas: [["America/Port-au-Prince", "Puerto Príncipe"]] },
  { pais: "Honduras", zonas: [["America/Tegucigalpa", "Tegucigalpa"]] },
  { pais: "México", zonas: [
    ["America/Tijuana", "Baja California (Tijuana)"],
    ["America/Cancun", "Cancún (Quintana Roo)"],
    ["America/Chihuahua", "Chihuahua (interior)"],
    ["America/Ciudad_Juarez", "Ciudad Juárez (frontera)"],
    ["America/Matamoros", "Frontera noreste (Matamoros)"],
    ["America/Mazatlan", "Pacífico (Mazatlán / Sinaloa)"],
    ["America/Mexico_City", "Zona centro (Ciudad de México)"],
    ["America/Hermosillo", "Sonora (Hermosillo)"],
  ] },
  { pais: "Nicaragua", zonas: [["America/Managua", "Managua"]] },
  { pais: "Panamá", zonas: [["America/Panama", "Ciudad de Panamá"]] },
  { pais: "Paraguay", zonas: [["America/Asuncion", "Asunción"]] },
  { pais: "Perú", zonas: [["America/Lima", "Lima"]] },
  { pais: "Puerto Rico", zonas: [["America/Puerto_Rico", "San Juan"]] },
  { pais: "República Dominicana", zonas: [["America/Santo_Domingo", "Santo Domingo"]] },
  { pais: "Uruguay", zonas: [["America/Montevideo", "Montevideo"]] },
  { pais: "Venezuela", zonas: [["America/Caracas", "Caracas"]] },
].sort((a, b) => a.pais.localeCompare(b.pais, "es", { sensitivity: "base" }));


// Configuración de la semana dentro del panel: no se navega a otra página.
const DIAS_SEMANA = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"];
const HORAS_SEMANA = ["09:00", "10:00", "12:00", "14:00", "17:00", "18:00", "19:00", "20:00", "21:00"];
const SEMANA_BASE = [
  ["reel", "Lunes", "18:00"], ["carrusel", "Miércoles", "18:00"],
  ["imagen", "Viernes", "18:00"], ["reel", "Domingo", "18:00"],
];
const crearSemana = () => SEMANA_BASE.map(([tipo, dia, hora], i) => ({
  id: `contenido-${i + 1}`, tipo, dia, hora,
  formato: tipo === "reel" ? "9:16" : "4:5", descripcion: "",
  ctaInstagram: "", ctaFacebook: "", urlFacebook: "", hashtags: "", archivos: [],
}));

function VistaArchivoLocal({ archivo, tipo }) {
  const [url, setUrl] = useState("");
  useEffect(() => {
    if (!archivo) { setUrl(""); return; }
    const nueva = URL.createObjectURL(archivo);
    setUrl(nueva);
    return () => URL.revokeObjectURL(nueva);
  }, [archivo]);
  if (!archivo || !url) return (
    <div className="flex h-full w-full flex-col items-center justify-center gap-2 px-4 text-center text-tinta-apagado">
      <FileImage size={28} strokeWidth={1.5} />
      <p className="text-xs leading-5">Elegí {tipo === "reel" ? "un video" : "imágenes"} para ver tu publicación</p>
    </div>
  );
  return tipo === "reel"
    ? <video key={url} className="h-full w-full object-contain" src={url} controls playsInline preload="metadata" aria-label="Vista previa del video" />
    : <img className="h-full w-full object-contain" src={url} alt={archivo.name} />;
}

function EditorPrimeraSemana({ perfil, email, alFinalizar, pedidoRenovacion = null }) {
  const modoRenovacion = Boolean(pedidoRenovacion?.id);
  const [redes, setRedes] = useState(() => modoRenovacion ? pedidoRenovacion.redes : ["facebook", "instagram"]);
  const [paisZona, setPaisZona] = useState(() => ZONAS_DISPONIBLES.some(x => x.pais === perfil?.pais) ? perfil.pais : "Argentina");
  const [zonaHoraria, setZonaHoraria] = useState(() => {
    const pais = ZONAS_DISPONIBLES.find(x => x.pais === perfil?.pais);
    const navegador = Intl.DateTimeFormat().resolvedOptions().timeZone;
    return pais?.zonas.find(([id]) => id === navegador)?.[0] || pais?.zonas[0]?.[0] || "America/Argentina/Buenos_Aires";
  });
  const [contenidos, setContenidos] = useState(crearSemana);
  const [seleccionado, setSeleccionado] = useState(0);
  const [redVista, setRedVista] = useState("instagram");
  const [mediaVista, setMediaVista] = useState(0);
  const [habilitada, setHabilitada] = useState(false);
  const [consultando, setConsultando] = useState(true);
  const [enviando, setEnviando] = useState(false);
  const [pedidoCreado, setPedidoCreado] = useState("");
  const [subida, setSubida] = useState(null);
  const [errorEditor, setErrorEditor] = useState("");
  const envioEnCurso = useRef(false);
  // Evita volver a subir archivos ya confirmados durante un reintento de Semana 2.
  const subidosSemana2 = useRef(new Set());
  useEffect(() => {
    if (modoRenovacion) { setHabilitada(true); setConsultando(false); return; }
    let activo = true;
    fetch("/api/servicios/publicaciones/plan", { cache: "no-store", credentials: "same-origin" })
      .then(r => r.json()).then(r => { if (activo) setHabilitada(r.ok === true && r.pruebasDisponibles === true); })
      .catch(() => { if (activo) setHabilitada(false); })
      .finally(() => { if (activo) setConsultando(false); });
    return () => { activo = false; };
  }, [modoRenovacion]);
  const item = contenidos[seleccionado];
  const redPrevia = redes.includes(redVista) ? redVista : redes[0];
  const nombre = perfil?.emprendimiento?.trim() || "";
  const datosCompletos = Boolean(nombre && perfil?.nombreApellido?.trim() && email && perfil?.whatsapp?.trim());
  const actualizar = cambios => setContenidos(lista => lista.map((c, i) => i === seleccionado ? { ...c, ...cambios } : c));
  const esCarrusel = item.tipo === "carrusel";
  const cantidad = contenidos.length * redes.length;
  const cambiarTipo = tipo => {
    if (tipo === item.tipo) return;
    actualizar({ tipo, formato: tipo === "reel" ? "9:16" : "4:5", archivos: [] });
    setMediaVista(0);
    setErrorEditor("");
  };
  const seleccionarArchivos = event => {
    const nuevos = Array.from(event.target.files || []);
    event.target.value = "";
    if (!nuevos.length || pedidoCreado || enviando) return;
    setErrorEditor("");
    const esReel = item.tipo === "reel";
    const invalidos = nuevos.some(archivo => archivo.size <= 0 ||
      (esReel
        ? archivo.type !== "video/mp4" || archivo.size > 150 * 1024 * 1024
        : !["image/jpeg", "image/png", "image/webp"].includes(archivo.type) || archivo.size > 20 * 1024 * 1024));
    if (invalidos || (modoRenovacion && nuevos.some(a => a.size > 25 * 1024 * 1024))) {
      setErrorEditor(modoRenovacion ? "En la semana pagada, cada archivo debe pesar 25 MB como máximo." : esReel ? "Seleccioná videos MP4 de hasta 150 MB." : "Seleccioná imágenes JPG, PNG o WebP de hasta 20 MB.");
      return;
    }
    if (esCarrusel) {
      const disponibles = 10 - item.archivos.length;
      if (disponibles <= 0) {
        setErrorEditor("El carrusel admite hasta diez imágenes. Quitá una para agregar otra.");
        return;
      }
      if (nuevos.length > disponibles) setErrorEditor("Solo se agregaron las imágenes permitidas (máximo diez por carrusel).");
      actualizar({ archivos: [...item.archivos, ...nuevos.slice(0, disponibles)] });
    } else {
      if (nuevos.length > 1) setErrorEditor("Para este formato se admite un solo archivo.");
      actualizar({ archivos: nuevos.slice(0, 1) });
    }
    setMediaVista(0);
  };
  const quitarArchivo = indice => {
    if (pedidoCreado || enviando) return;
    actualizar({ archivos: item.archivos.filter((_, i) => i !== indice) });
    setMediaVista(0);
    setErrorEditor("");
  };
  const alternarRed = red => {
    if (pedidoCreado || enviando || modoRenovacion) return;
    setRedes(actual => actual.includes(red)
      ? (actual.length === 1 ? actual : actual.filter(x => x !== red))
      : ["instagram", "facebook"].filter(x => x === red || actual.includes(x)));
  };
  const cambiarPais = pais => {
    setPaisZona(pais);
    setZonaHoraria(ZONAS_DISPONIBLES.find(item => item.pais === pais)?.zonas[0]?.[0] || "America/Argentina/Buenos_Aires");
  };

  async function programar(evento) {
    evento.preventDefault();
    if (envioEnCurso.current || !habilitada || !datosCompletos) return;
    if (!redes.length) { setErrorEditor("Elegí al menos una red."); return; }
    if (contenidos.some(c => c.archivos.length < (c.tipo === "carrusel" ? 2 : 1))) {
      setErrorEditor("Elegí los archivos de los cuatro contenidos. Cada carrusel necesita al menos dos imágenes."); return;
    }
    envioEnCurso.current = true;
    setEnviando(true);
    setErrorEditor("");
    setSubida(null);
    let id = pedidoCreado;
    try {
      const publicaciones = contenidos.map(c => ({
        id: c.id, tipo: c.tipo, formato: c.formato, dia: c.dia, hora: c.hora,
        descripcion: c.descripcion, ctaInstagram: c.ctaInstagram, ctaFacebook: c.ctaFacebook,
        urlFacebook: c.urlFacebook, hashtags: c.hashtags,
        archivosSeleccionados: c.archivos.map(a => ({ nombre: a.name, tipo: a.type, tamano: a.size })),
      }));
      if (modoRenovacion) {
        if (!id) {
          const res = await fetch("/api/servicios/publicaciones/renovacion-contenidos/configurar", {
            method: "POST", credentials: "same-origin", cache: "no-store",
            headers: { "Content-Type": "application/json", "X-Comunidad-Panel": "1" },
            body: JSON.stringify({ id: pedidoRenovacion.id, zonaHoraria, publicaciones }),
          });
          const info = await res.json().catch(() => ({}));
          if (!res.ok || info.ok !== true || info.estado !== "en_preparacion") throw new Error(info.error || "No se pudo guardar la semana 2.");
          id = pedidoRenovacion.id;
          setPedidoCreado(id);
        }
        // Tres cargas simultáneas como máximo: reduce las esperas de red/MongoDB
        // sin abrir decenas de conexiones ni saturar un celular.
        const archivos = contenidos.flatMap(c => c.archivos.map((archivo, pos) => ({
          contenido: c.id, pos, archivo,
          clave: `${id}:${c.id}:${pos}:${archivo.name}:${archivo.size}:${archivo.lastModified}`,
        })));
        const pendientes = archivos.filter(a => !subidosSemana2.current.has(a.clave));
        let hechos = archivos.length - pendientes.length;
        let siguiente = 0;
        let primerError = null;
        const subirSiguiente = async () => {
          while (!primerError) {
            const a = pendientes[siguiente++];
            if (!a) return;
            try {
              const ruta = `/api/servicios/publicaciones/renovacion-contenidos/medio?id=${encodeURIComponent(id)}&contenido=${encodeURIComponent(a.contenido)}&pos=${a.pos}`;
              const res = await fetch(ruta, {
                method: "POST", credentials: "same-origin", cache: "no-store",
                headers: { "Content-Type": a.archivo.type, "X-Comunidad-Panel": "1" },
                body: a.archivo,
              });
              const info = await res.json().catch(() => ({}));
              if (!res.ok || info.ok !== true || info.contenido !== a.contenido || info.pos !== a.pos) {
                throw new Error(info.error || `No se pudo subir ${a.archivo.name}.`);
              }
              subidosSemana2.current.add(a.clave);
              hechos++;
              setSubida({ archivo: `${hechos} de ${archivos.length} archivos`,
                porcentaje: Math.round(hechos / archivos.length * 100) });
            } catch (error) {
              // Las cargas ya iniciadas terminan; no se lanzan otras si falla una.
              primerError = primerError || error;
            }
          }
        };
        await Promise.all(Array.from({ length: Math.min(2, pendientes.length) }, () => subirSiguiente()));
        if (primerError) throw primerError;
        const res = await fetch("/api/servicios/publicaciones/renovacion-contenidos/enviar", {
          method:"POST",credentials:"same-origin",cache:"no-store",
          headers:{"Content-Type":"application/json","X-Comunidad-Panel":"1"},
          body:JSON.stringify({id}),
        });
        const info = await res.json().catch(() => ({}));
        if (!res.ok || info.ok !== true || info.estado !== "en_revision") throw new Error(info.error || "No se pudo enviar la semana.");
      } else {
        if (!id) {
          const respuesta = await fetch("/api/servicios/publicaciones/prueba", {
            method: "POST", credentials: "same-origin", cache: "no-store",
            headers: { "Content-Type": "application/json", "X-Comunidad-Panel": "1" },
            body: JSON.stringify({ planId: "comunidad-semanal", moneda: "ARS", redes,
              zonaHoraria, negocio: { nombre, contacto: perfil.nombreApellido, email,
                whatsapp: perfil.whatsapp, url: perfil.web || "", rubro: "", publico: "", tono: "cercano" },
              publicaciones }),
          });
          const datos = await respuesta.json().catch(() => ({}));
          if (!respuesta.ok || !datos.ok || !/^SER-[a-f0-9-]{36}$/i.test(datos.pedidoId || "")) {
            throw new Error(datos.error || "No se pudo registrar la semana gratuita.");
          }
          id = datos.pedidoId;
          setPedidoCreado(id);
        }
        await subirArchivosSemana(id, contenidos, setSubida);
      }
      alFinalizar();
    } catch (error) {
      setSubida(null);
      setErrorEditor(`${error.message || "No se pudieron subir los archivos."} ${id ? "Podés reintentar sobre el mismo pedido." : "Revisá el panel antes de crear otro pedido."}`);
    } finally {
      envioEnCurso.current = false;
      setEnviando(false);
    }
  }

  async function finalizarEnvioAnterior() {
    if (!modoRenovacion || !pedidoRenovacion?.id || envioEnCurso.current) return;
    envioEnCurso.current = true;
    setEnviando(true);
    setErrorEditor("");
    try {
      // Solo completa una renovación real ya existente: no crea otro pedido,
      // no cambia sus horarios y no vuelve a subir archivos a R2.
      const respuesta = await fetch("/api/servicios/publicaciones/renovacion-contenidos/enviar", {
        method: "POST", credentials: "same-origin", cache: "no-store",
        headers: { "Content-Type": "application/json", "X-Comunidad-Panel": "1" },
        body: JSON.stringify({ id: pedidoRenovacion.id }),
      });
      const resultado = await respuesta.json().catch(() => ({}));
      if (!respuesta.ok || resultado.ok !== true || resultado.estado !== "en_revision") {
        throw new Error(resultado.error || "No se pudo finalizar el envío anterior. Revisá si faltan archivos.");
      }
      alFinalizar();
    } catch (error) {
      setErrorEditor(error.message || "No se pudo finalizar el envío anterior.");
    } finally {
      envioEnCurso.current = false;
      setEnviando(false);
    }
  }

  const nombreVisible = nombre || "Tu emprendimiento";
  const usuarioVisible = nombreVisible.toLowerCase().normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "") || "tu_emprendimiento";
  const ctaVisible = redPrevia === "instagram" ? item.ctaInstagram : item.ctaFacebook;
  const textoVistaPrevia = (
    <div className="px-3 py-3">
      <p className="whitespace-pre-wrap break-words text-sm font-normal leading-5 text-tinta-suave">
        {item.descripcion.trim() || "Acá vas a ver la idea de tu publicación."}
      </p>
      {ctaVisible.trim() && <p className="mt-2 text-sm font-medium text-tinta">{ctaVisible}</p>}
      {redPrevia === "facebook" && item.urlFacebook.trim() &&
        <p className="mt-1 break-all text-sm text-terracota-oscuro underline underline-offset-2">{item.urlFacebook}</p>}
      {item.hashtags.trim() && <p className="mt-2 break-words text-sm text-terracota-oscuro">{item.hashtags}</p>}
    </div>
  );
  const sinEdicion = !!pedidoCreado || enviando;
  const TIPOS_EDITOR = {
    reel: { titulo: "Reel", icono: Film },
    carrusel: { titulo: "Carrusel", icono: Images },
    imagen: { titulo: "Imagen", icono: FileImage },
  };

  return <form onSubmit={programar} className="space-y-4 font-normal">
    <div className={`${CARD} p-4 sm:p-5`}>
      <h2 className="text-sm font-medium">{modoRenovacion ? `Programar nueva semana · Semana ${pedidoRenovacion.numeroSemana || 2}` : "Programá tu primera semana"}</h2>
      <p className="mt-1 text-xs leading-5 text-tinta-apagado">{modoRenovacion ? "Configurá los cuatro contenidos de tu semana pagada. Se enviarán a revisión administrativa antes de publicarse." : "Prepará tu contenido semanal y envialo para que lo revisemos y publiquemos en tus cuentas."}</p>
      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <div>
          <p className="mb-2 text-xs font-medium">Facebook e Instagram</p>
          <div className="grid grid-cols-2 gap-2" role="group" aria-label="Redes para la primera semana">
            {["instagram", "facebook"].map(red => {
              const activa = redes.includes(red);
              return <button type="button" key={red} aria-pressed={activa} disabled={sinEdicion || modoRenovacion}
                onClick={() => alternarRed(red)}
                className={`flex min-h-9 items-center justify-center gap-1.5 rounded-sm border px-2 py-1.5 text-xs font-medium transition ${activa ? "border-terracota bg-terracota-suave text-terracota-oscuro" : "border-borde bg-white text-tinta-suave hover:border-tinta-apagado"}`}>
                <LogoRed red={red} size={19} />{redLabel(red)} {activa && <Check size={13} />}
              </button>;
            })}
          </div>
          <p className="mt-2 text-[11px] text-tinta-apagado">{cantidad} publicaciones · {redes.length} {redes.length === 1 ? "red" : "redes"}</p>
        </div>
        <div>
          <label className="mb-2 block text-xs font-medium" htmlFor="pais-zona">Zona horaria con selección de país</label>
          <div className="grid grid-cols-2 gap-2">
            <select id="pais-zona" className={CAMPO} value={paisZona} disabled={sinEdicion} onChange={e => cambiarPais(e.target.value)}>
              {ZONAS_DISPONIBLES.map(p => <option key={p.pais} value={p.pais}>{p.pais}</option>)}
            </select>
            <select aria-label="Zona horaria" className={CAMPO} value={zonaHoraria} disabled={sinEdicion} onChange={e => setZonaHoraria(e.target.value)}>
              {(ZONAS_DISPONIBLES.find(p => p.pais === paisZona)?.zonas || []).map(([id, ciudad]) => <option key={id} value={id}>{ciudad}</option>)}
            </select>
          </div>
        </div>
      </div>
    </div>

    <div className={`${CARD} p-4 sm:p-5`}>
      <h2 className="text-sm font-medium">Elegí el contenido que querés publicar</h2>
      <p className="mt-1 text-xs leading-5 text-tinta-apagado">Cada contenido conserva sus propios archivos, formato, textos, día, horario y hagstags.</p>
    </div>

    <div className="grid items-start gap-4 lg:grid-cols-[minmax(0,1fr)_350px]">
      <div className="min-w-0 space-y-4">
        <details open className={`${CARD} group`}>
          <summary className="flex cursor-pointer list-none items-center justify-between gap-2 px-4 py-3 text-xs font-medium [&::-webkit-details-marker]:hidden">
            Contenidos <ChevronDown size={14} className="transition group-open:rotate-180" />
          </summary>
          <div className="border-t border-borde p-4">
            <p className="mb-3 text-xs text-tinta-apagado">Formato, archivos, día y hora.</p>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-4" role="group" aria-label="Elegir contenido">
              {contenidos.map((c, i) => {
                const Icono = TIPOS_EDITOR[c.tipo].icono;
                return <button type="button" key={c.id} aria-pressed={seleccionado === i}
                  onClick={() => { setSeleccionado(i); setMediaVista(0); setErrorEditor(""); }}
                  className={`flex items-center justify-center gap-1.5 rounded-sm border px-2 py-2 text-xs font-medium transition ${seleccionado === i ? "border-terracota bg-terracota-suave text-terracota-oscuro" : "border-borde bg-white text-tinta-suave hover:border-tinta-apagado"}`}>
                  <Icono size={15} /> Contenido {i + 1}
                </button>;
              })}
            </div>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <label className="text-xs font-medium">Tipo de publicación
                <select className={`mt-1 ${CAMPO}`} value={item.tipo} disabled={sinEdicion} onChange={e => cambiarTipo(e.target.value)}>
                  <option value="imagen">Imagen</option><option value="carrusel">Carrusel</option><option value="reel">Reel</option>
                </select>
              </label>
              <label className="text-xs font-medium">Formato
                <select className={`mt-1 ${CAMPO}`} value={item.formato} disabled={sinEdicion} onChange={e => actualizar({ formato: e.target.value })}>
                  {(item.tipo === "reel" ? ["9:16"] : ["4:5", "1:1"]).map(x => <option key={x} value={x}>{x}</option>)}
                </select>
              </label>
              <label className="text-xs font-medium">Día
                <select className={`mt-1 ${CAMPO}`} value={item.dia} disabled={sinEdicion} onChange={e => actualizar({ dia: e.target.value })}>
                  {DIAS_SEMANA.map(x => <option key={x}>{x}</option>)}
                </select>
              </label>
              <label className="text-xs font-medium">Horario local
                <select className={`mt-1 ${CAMPO}`} value={item.hora} disabled={sinEdicion} onChange={e => actualizar({ hora: e.target.value })}>
                  {HORAS_SEMANA.map(x => <option key={x}>{x}</option>)}
                </select>
              </label>
            </div>
            <div className="mt-4 border-t border-borde pt-4">
              <p className="mb-2 text-xs font-medium">{item.tipo === "reel" ? "Video del reel" : esCarrusel ? "Imágenes del carrusel" : "Imagen de la publicación"}</p>
              <label className={`flex items-center justify-center gap-2 rounded-sm border border-dashed border-borde bg-white px-3 py-3 text-center transition ${sinEdicion ? "cursor-not-allowed opacity-60" : "cursor-pointer hover:border-terracota"}`}>
                <CloudUpload size={19} className="shrink-0 text-terracota-oscuro" />
                <span className="text-xs font-medium">{item.archivos.length ? "Agregar o cambiar archivos" : "Elegir archivos"}</span>
                <span className="hidden text-xs text-tinta-apagado sm:inline">{modoRenovacion ? "Hasta 25 MB por archivo" : item.tipo === "reel" ? "MP4 · 150 MB" : "JPG, PNG, WebP · 20 MB"}</span>
                <input type="file" className="sr-only" disabled={sinEdicion}
                  accept={item.tipo === "reel" ? "video/mp4,.mp4" : "image/jpeg,image/png,image/webp,.jpg,.jpeg,.png,.webp"}
                  multiple={esCarrusel} onChange={seleccionarArchivos} />
              </label>
              <p className="mt-2 text-[11px] text-tinta-apagado">{esCarrusel ? "De 2 a 10 imágenes" : item.tipo === "reel" ? "Un video MP4" : "Una imagen"}.</p>
              {modoRenovacion && redes.includes("instagram") && item.tipo !== "reel" && (
                <p className="mt-1 text-[11px] text-tinta-suave">
                  Admitimos JPG, PNG y WebP. Durante la revisión, preparamos una copia JPEG antes de programar Instagram.
                </p>
              )}
              {item.archivos.length > 0 && <div className="mt-2 flex flex-wrap gap-1.5">
                {item.archivos.map((archivo, indice) => <span key={`${item.id}-${indice}-${archivo.name}`} className="inline-flex max-w-full items-center gap-1.5 rounded-sm border border-borde px-2 py-1 text-xs">
                  <span className="max-w-36 truncate" title={archivo.name}>{archivo.name}</span>
                  <button type="button" aria-label={`Quitar ${archivo.name}`} disabled={sinEdicion} className="text-tinta-apagado hover:text-red-700 disabled:opacity-50"
                    onClick={() => quitarArchivo(indice)}><Trash2 size={13} /></button>
                </span>)}
              </div>}
              {errorEditor && <p className="mt-2 text-xs text-red-700" role="alert">{errorEditor}</p>}
            </div>
          </div>
        </details>

        <details className={`${CARD} group`}>
          <summary className="flex cursor-pointer list-none items-center justify-between gap-2 px-4 py-3 text-xs font-medium [&::-webkit-details-marker]:hidden">
            Texto y detalles de la publicación <ChevronDown size={14} className="transition group-open:rotate-180" />
          </summary>
          <div className="grid gap-3 border-t border-borde p-4 sm:grid-cols-2">
            <p className="col-span-full text-xs text-tinta-apagado">Mensaje, llamadas a la acción, enlaces y hashtags.</p>
            <label className="col-span-full text-xs font-medium">Copy o texto de la publicación
              <textarea className={`${CAMPO} mt-1 min-h-24`} placeholder="Escribí el texto de tu publicación" maxLength={1500} disabled={sinEdicion} value={item.descripcion} onChange={e => actualizar({ descripcion: e.target.value })} />
            </label>
            {redes.includes("instagram") && <label className="text-xs font-medium">CTA para Instagram
              <input className={`mt-1 ${CAMPO}`} placeholder="ej: Enlace en nuestra bio" maxLength={100} value={item.ctaInstagram} disabled={sinEdicion} onChange={e => actualizar({ ctaInstagram: e.target.value })} />
            </label>}
            {redes.includes("facebook") && <>
              <label className="text-xs font-medium">CTA para Facebook
                <input className={`mt-1 ${CAMPO}`} placeholder="ej: Visitá nuestra tienda" maxLength={100} value={item.ctaFacebook} disabled={sinEdicion} onChange={e => actualizar({ ctaFacebook: e.target.value })} />
              </label>
              <label className="text-xs font-medium">URL para Facebook
                <input className={`mt-1 ${CAMPO}`} placeholder="ej: minegocio.com.ar" maxLength={500} value={item.urlFacebook} disabled={sinEdicion} onChange={e => actualizar({ urlFacebook: e.target.value })} />
              </label>
            </>}
            <label className="text-xs font-medium">Hashtags
              <input className={`mt-1 ${CAMPO}`} placeholder="#redesenpiloto #minegocio #redes" maxLength={240} value={item.hashtags} disabled={sinEdicion} onChange={e => actualizar({ hashtags: e.target.value })} />
            </label>
          </div>
        </details>
      </div>

      <aside className="min-w-0 lg:sticky lg:top-20" aria-label="Vista previa de la publicación">
        <details open className={`${CARD} group`}>
          <summary className="flex cursor-pointer list-none items-center justify-between gap-2 px-4 py-3 text-xs font-medium [&::-webkit-details-marker]:hidden">
            Vista previa <ChevronDown size={14} className="transition group-open:rotate-180" />
          </summary>
          <div className="border-t border-borde p-3 sm:p-4">
            <p className="mb-3 text-xs text-tinta-apagado">Contenido {seleccionado + 1} · Así se verá en cada red</p>
            <div className="mb-3 flex gap-2" role="group" aria-label="Ver publicación por red">
              {["instagram", "facebook"].filter(red => redes.includes(red)).map(red => <button type="button" key={red} aria-pressed={redPrevia === red} onClick={() => setRedVista(red)}
                className={`flex min-h-9 flex-1 items-center justify-center gap-1.5 rounded-sm border px-2 py-1 text-xs font-medium ${redPrevia === red ? "border-terracota bg-terracota-suave text-terracota-oscuro" : "border-borde text-tinta-suave"}`}>
                <LogoRed red={red} size={19} /> {redLabel(red)}
              </button>)}
            </div>
            <div className="overflow-hidden rounded-sm border border-borde bg-white">
              <div className="flex items-center gap-2 px-3 py-3">
                <LogoRed red={redPrevia} size={27} />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-xs font-medium text-tinta">{redPrevia === "instagram" ? usuarioVisible : nombreVisible}</p>
                  <p className="text-[11px] font-normal text-tinta-apagado">{redPrevia === "instagram" ? "Publicación de Instagram" : "Página de Facebook · Público"}</p>
                </div>
                <MoreHorizontal size={19} className="text-tinta-apagado" />
              </div>
              {redPrevia === "facebook" && textoVistaPrevia}
              <div className="bg-crema px-3 py-2">
                <div className={`relative mx-auto overflow-hidden rounded-sm bg-borde ${item.formato === "9:16" ? "w-full max-w-[225px]" : "w-full max-w-[300px]"}`}
                  style={{ aspectRatio: item.formato.replace(":", " / ") }}>
                  <VistaArchivoLocal archivo={item.archivos[mediaVista] || item.archivos[0]} tipo={item.tipo} />
                  {esCarrusel && item.archivos.length > 1 && <>
                    <button type="button" aria-label="Imagen anterior" onClick={() => setMediaVista(i => (i - 1 + item.archivos.length) % item.archivos.length)}
                      className="absolute left-1.5 top-1/2 -translate-y-1/2 rounded-sm bg-white/90 p-1.5 text-tinta"><ChevronLeft size={16} /></button>
                    <button type="button" aria-label="Imagen siguiente" onClick={() => setMediaVista(i => (i + 1) % item.archivos.length)}
                      className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded-sm bg-white/90 p-1.5 text-tinta"><ChevronRight size={16} /></button>
                    <span className="absolute right-1.5 top-1.5 rounded-sm bg-black/65 px-2 py-1 text-[10px] text-white">{mediaVista + 1}/{item.archivos.length}</span>
                  </>}
                </div>
              </div>
              {redPrevia === "instagram" ? <div className="flex items-center gap-3 px-3 pt-3 text-tinta" aria-label="Acciones orientativas de Instagram">
                <Heart size={19} /><MessageCircle size={19} /><Send size={19} />
              </div> : <div className="flex items-center justify-around border-b border-borde px-3 py-2 text-xs text-tinta-apagado" aria-label="Acciones orientativas de Facebook">
                <span className="inline-flex items-center gap-1"><ThumbsUp size={15} /> Me gusta</span>
                <span className="inline-flex items-center gap-1"><MessageCircle size={15} /> Comentar</span>
                <span className="inline-flex items-center gap-1"><Send size={15} /> Compartir</span>
              </div>}
              {redPrevia === "instagram" && textoVistaPrevia}
            </div>
            <p className="mt-2 text-xs font-normal leading-4 text-tinta-apagado">Simulación orientativa: la apariencia final puede variar según la red social.</p>
          </div>
        </details>
      </aside>
    </div>

    <details open className={`${CARD} group`}>
      <summary className="flex cursor-pointer list-none items-center justify-between gap-2 px-4 py-3 text-xs font-medium [&::-webkit-details-marker]:hidden">
        Resumen y programación <ChevronDown size={14} className="transition group-open:rotate-180" />
      </summary>
      <div className="space-y-3 border-t border-borde p-4 text-xs">
        <div><p className="font-medium">{cantidad} publicaciones</p><p className="mt-0.5 text-tinta-apagado">{redes.map(redLabel).join(" · ")}</p></div>
        {contenidos.map((c, i) => <div key={c.id} className="flex flex-wrap items-center justify-between gap-2 border-b border-borde pb-2 last:border-0 last:pb-0">
          <p>Contenido {i + 1} · {TIPOS_EDITOR[c.tipo].titulo}</p>
          <p className="text-tinta-apagado">{c.dia} · {c.hora} hora local</p>
        </div>)}
        {errorEditor && <p role="alert" className="text-red-700">{errorEditor}</p>}
        {!consultando && !habilitada && <p className="text-tinta-suave">La programación gratuita todavía no está habilitada en el servidor.</p>}
        {!datosCompletos && <p className="text-amber-700">Revisá tus datos personales y el nombre del emprendimiento en el registro.</p>}
        {subida && <p role="status" className="text-tinta-suave">Subiendo {subida.archivo} · {subida.porcentaje}%</p>}
        <button type="submit" className={BTN_PRIMARIO} disabled={consultando || !habilitada || !datosCompletos || enviando || !redes.length}>
          {enviando ? "Guardando y subiendo archivos..." : pedidoCreado ? "Reintentar subida de archivos" : modoRenovacion ? "Enviar semana pagada para revisión" : "Programar semana gratuita"}
        </button>
        {modoRenovacion && (pedidoCreado || pedidoRenovacion?.configuracionEstado === "en_preparacion") &&
          <button type="button" className={BTN_SECUNDARIO} disabled={enviando}
            onClick={finalizarEnvioAnterior}>
            Finalizar envío anterior (sin volver a subir)
          </button>}
        <p className="text-[11px] text-tinta-apagado">{modoRenovacion
          ? "Si tus archivos ya quedaron cargados, podés finalizar el envío anterior sin seleccionarlos otra vez."
          : "El pedido queda pendiente de revisión. Los 7 días de prueba comienzan luego de la aprobación."}</p>
      </div>
    </details>
  </form>;

}

function RenovacionPaypalReal({pedidoId,seleccion,alActualizar}) {
  const [info,setInfo]=useState(null);
  const [ocupado,setOcupado]=useState(false);
  const [error,setError]=useState("");
  const [mensaje,setMensaje]=useState("");
  const API="/api/servicios/publicaciones/renovacion-paypal";
  const consultar=useCallback(async()=>{
    const r=await fetch(`${API}?pedidoId=${encodeURIComponent(pedidoId)}`,{credentials:"same-origin",cache:"no-store"});
    const j=await r.json().catch(()=>null);
    if(!r.ok||j?.ok!==true)throw Error(j?.error||`No se pudo consultar PayPal (HTTP ${r.status}).`);
    setInfo(j);return j;
  },[pedidoId]);
  useEffect(()=>{let activo=true;consultar().catch(e=>{if(activo)setError(e.message)});return()=>{activo=false;};},[consultar]);
  const crear=async()=>{
    setOcupado(true);setError("");setMensaje("");
    try {
      const redes=seleccion==="ambas"?["facebook","instagram"]:[seleccion];
      const r=await fetch(`${API}/crear`,{method:"POST",credentials:"same-origin",cache:"no-store",
        headers:{"Content-Type":"application/json","X-Comunidad-Panel":"1"},body:JSON.stringify({pedidoId,redes})});
      const j=await r.json().catch(()=>null);
      if(!r.ok||!j?.ok)throw Error(j?.error||`Error HTTP ${r.status} al preparar PayPal.`);
      if(j.pagado){await consultar();setMensaje("Esta semana ya tiene el pago confirmado.");return;}
      if(typeof j.url!=="string")throw Error("No se recibió la página de PayPal.");
      // PayPal recibe al usuario directamente; no se crean ventanas emergentes.
      window.location.assign(j.url);
    }catch(e){setError(e.message||"PayPal no está disponible.");}
    finally{setOcupado(false);}
  };
  const verificar=async()=>{
    if(!info?.pedido?.id)return;
    setOcupado(true);setError("");setMensaje("");
    try{
      const r=await fetch(`${API}/capturar`,{method:"POST",credentials:"same-origin",cache:"no-store",
        headers:{"Content-Type":"application/json","X-Comunidad-Panel":"1"},
        body:JSON.stringify({pedidoId,semanaId:info.pedido.id})});
      const j=await r.json().catch(()=>null);
      if(!r.ok||!j?.ok)throw Error(j?.error||`PayPal aún no confirmó el pago (HTTP ${r.status}).`);
      setMensaje("Pago confirmado. La activación administrativa de la semana continúa por separado.");
      alActualizar?.(j.pedido||null);await consultar();
    }catch(e){setError(e.message||"No se pudo verificar el pago.");}
    finally{setOcupado(false);}
  };
  const pedido=info?.pedido,precio=seleccion==="ambas"?"15.00":"10.00";
  const finalizada=pedido&&(pedido.configuracionEstado==="programada"||pedido.estadoSemana==="finalizada");
  const pendiente=pedido&&!finalizada;
  const otrasRedes=pendiente&&JSON.stringify([...(pedido.redes||[])].sort())!==JSON.stringify((seleccion==="ambas"?["facebook","instagram"]:[seleccion]).sort());
  return <div className="space-y-3 rounded-sm border border-borde bg-white p-3 text-xs">
    <p className="font-medium text-tinta">PayPal · semana adicional de 7 días</p>
    <p className="text-tinta-suave">Importe seleccionado: <strong>USD {precio}</strong>. El importe definitivo se verifica en el servidor antes de enviar a PayPal.</p>
    {info?.entorno==="sandbox"&&<p className="text-amber-700">Entorno de prueba Sandbox: no se cobran fondos reales.</p>}
    {info&&!info.habilitada&&<p className="text-amber-700">{info.motivo||"PayPal todavía no está habilitado."}</p>}
    {info?.bloqueada&&<p className="text-amber-700">{info.bloqueada}</p>}
    {pedido&&<div className="rounded-sm bg-crema p-3 text-tinta-suave">
      <p>Semana {pedido.numeroSemana} · Estado: <strong>{pedido.estado}</strong></p>
      <p className="mt-1">Redes reservadas: {(pedido.redes||[]).map(redLabel).join(" · ")}</p>
      <p className="mt-1">Importe reservado: <strong>USD {Number(pedido.importe).toFixed(2)}</strong></p>
      {pedido.pagoConfirmado&&<p className="mt-1 text-emerald-700">Pago confirmado. Pendiente de la preparación o programación administrativa.</p>}
    </div>}
    {otrasRedes&&<p className="text-amber-700">La semana pendiente tiene otras redes seleccionadas. Terminá ese pago antes de cambiar las redes.</p>}
    {info?.habilitada&&!info.bloqueada&&(!pendiente||(!pedido?.pagoConfirmado&&!otrasRedes))&&
      <button type="button" disabled={ocupado} className={BTN_PRIMARIO} onClick={crear}>
        {ocupado?"Preparando PayPal...":pendiente?"Continuar pago pendiente":finalizada?`Solicitar Semana ${(pedido.numeroSemana||2)+1} con PayPal`:"Pagar con PayPal"}
      </button>}
    {info?.habilitada&&pendiente&&!pedido.pagoConfirmado&&<button type="button" disabled={ocupado} className={BTN_SECUNDARIO} onClick={verificar}>
      {ocupado?"Verificando...":"Verificar si el pago se completó"}
    </button>}
    {error&&<p role="alert" className="text-red-700">{error}</p>}
    {mensaje&&<p role="status" className="text-emerald-700">{mensaje}</p>}
  </div>;
}

function RetornoPaypalRenovacion({alActualizar}) {
  const [resultado,setResultado]=useState("");
  const [error,setError]=useState("");
  const ejecutado=useRef(false);
  useEffect(()=>{
    if(ejecutado.current)return;
    const url=new URL(window.location.href),modo=url.searchParams.get("paypal");
    const pedidoId=url.searchParams.get("pedidoId"),semanaId=url.searchParams.get("semanaId");
    if(!["retorno","cancelado"].includes(modo)||!VALIDAR_PEDIDO.test(pedidoId||"")||!/^renovacion-real:SER-[a-f0-9-]{36}(?::(?:[3-9]|[1-9][0-9]{1,2}))?$/i.test(semanaId||""))return;
    ejecutado.current=true;
    // No conservar tokens de PayPal ni identificadores de pago en la barra de direcciones.
    url.searchParams.delete("paypal");url.searchParams.delete("pedidoId");url.searchParams.delete("semanaId");url.searchParams.delete("token");url.searchParams.delete("PayerID");
    window.history.replaceState(window.history.state,"",url.pathname+(url.search||"")+url.hash);
    if(modo==="cancelado"){setResultado("Cancelaste la autorización en PayPal. No se registró ningún cobro nuevo.");return;}
    (async()=>{
      try{
        const r=await fetch("/api/servicios/publicaciones/renovacion-paypal/capturar",{
          method:"POST",credentials:"same-origin",cache:"no-store",headers:{"Content-Type":"application/json","X-Comunidad-Panel":"1"},
          body:JSON.stringify({pedidoId,semanaId})});
        const j=await r.json().catch(()=>null);
        if(!r.ok||!j?.ok)throw Error(j?.error||`No se pudo verificar el pago (HTTP ${r.status}).`);
        alActualizar?.(j.pedido||null);
        setResultado("PayPal confirmó el pago. La semana sigue pendiente de activación y revisión de contenidos.");
      }catch(e){setError(`${e.message} Si el cargo figura en PayPal, no repitas el pago: abrí la opción PayPal y utilizá «Verificar si el pago se completó».`);}
    })();
  },[alActualizar]);
  if(!resultado&&!error)return null;
  return <div className={`mb-4 rounded-sm border p-3 text-sm ${error?"border-red-200 bg-red-50 text-red-800":"border-green-200 bg-green-50 text-green-800"}`} role="status">{error||resultado}</div>;
}

function RenovacionTransferenciaReal({ pedidoId, seleccion, alActualizar }) {
  const [datosRenovacion, setDatosRenovacion] = useState(null);
  const [archivoRenovacion, setArchivoRenovacion] = useState(null);
  const [ocupadoRenovacion, setOcupadoRenovacion] = useState(false);
  const [errorRenovacion, setErrorRenovacion] = useState("");
  const [mensajeRenovacion, setMensajeRenovacion] = useState("");
  const [avisoRecibido, setAvisoRecibido] = useState(false);
  const API_RENOVACION = "/api/servicios/publicaciones/renovacion-transferencia";
  const consultar = useCallback(async () => {
    const respuesta = await fetch(`${API_RENOVACION}?pedidoId=${encodeURIComponent(pedidoId)}`, {
      credentials: "same-origin", cache: "no-store",
    });
    const tipo = respuesta.headers.get("content-type") || "";
    if (!tipo.includes("application/json")) throw new Error(`No se pudo consultar el cobro (HTTP ${respuesta.status}).`);
    const resultado = await respuesta.json();
    if (!respuesta.ok || !resultado.ok) throw new Error(resultado.error || "No se pudo consultar la renovación.");
    setDatosRenovacion(resultado);
    alActualizar?.(resultado.pedido || null);
    return resultado;
  }, [pedidoId]);
  useEffect(() => {
    let activo = true;
    (async () => {
      try {
        const respuesta = await fetch(`${API_RENOVACION}?pedidoId=${encodeURIComponent(pedidoId)}`, {
          credentials: "same-origin", cache: "no-store",
        });
        const tipo = respuesta.headers.get("content-type") || "";
        if (!tipo.includes("application/json")) throw new Error(`La API devolvió HTML (HTTP ${respuesta.status}).`);
        const resultado = await respuesta.json();
        if (!respuesta.ok || !resultado.ok) throw new Error(resultado.error || "No se pudo consultar el pago.");
        if (activo) setDatosRenovacion(resultado);
      } catch (err) { if (activo) setErrorRenovacion(err.message || "No se pudo consultar el pago."); }
    })();
    return () => { activo = false; };
  }, [pedidoId]);
  const crear = async () => {
    setOcupadoRenovacion(true); setErrorRenovacion(""); setMensajeRenovacion("");
    const redes = seleccion === "ambas" ? ["facebook", "instagram"] : [seleccion];
    try {
      const respuesta = await fetch(`${API_RENOVACION}/crear`, {
        method: "POST", credentials: "same-origin", cache: "no-store",
        headers: { "Content-Type": "application/json", "X-Comunidad-Panel": "1" },
        body: JSON.stringify({ pedidoId, redes }),
      });
      const tipo = respuesta.headers.get("content-type") || "";
      if (!tipo.includes("application/json")) throw new Error(`El servidor devolvió una página (HTTP ${respuesta.status}).`);
      const json = await respuesta.json();
      if (!respuesta.ok || !json.ok) throw new Error(json.error || "No se pudo preparar la renovación.");
      await consultar();
    } catch (err) { setErrorRenovacion(err.message || "No se pudo preparar la renovación."); }
    finally { setOcupadoRenovacion(false); }
  };
  const subir = async () => {
    if (!archivoRenovacion || !datosRenovacion?.pedido) return;
    if (!["image/jpeg", "image/png", "application/pdf"].includes(archivoRenovacion.type) ||
        archivoRenovacion.size > 8 * 1024 * 1024 || archivoRenovacion.size < 100) {
      setErrorRenovacion("Seleccioná un comprobante JPG, PNG o PDF de hasta 8 MB."); return;
    }
    setOcupadoRenovacion(true); setErrorRenovacion(""); setMensajeRenovacion("");
    try {
      const respuesta = await fetch(`${API_RENOVACION}/comprobante?pedidoId=${encodeURIComponent(pedidoId)}`, {
        method: "POST", credentials: "same-origin", cache: "no-store",
        headers: { "Content-Type": archivoRenovacion.type, "X-Comunidad-Panel": "1" },
        body: archivoRenovacion,
      });
      const tipo = respuesta.headers.get("content-type") || "";
      if (!tipo.includes("application/json")) throw new Error(`El servidor devolvió una página (HTTP ${respuesta.status}). Revisá los registros de Cloudflare.`);
      const json = await respuesta.json();
      if (!respuesta.ok || !json.ok) throw new Error(json.error || `No se pudo enviar el comprobante (HTTP ${respuesta.status}).`);
      setArchivoRenovacion(null);
      await consultar();
      setMensajeRenovacion("Comprobante recibido. Estamos verificando tu transferencia y te avisaremos por correo cuando se apruebe.");
      setAvisoRecibido(true);
    } catch (err) { setErrorRenovacion(err.message || "No pudimos subir el comprobante."); }
    finally { setOcupadoRenovacion(false); }
  };
  const copiar = async dato => {
    try { await navigator.clipboard.writeText(dato); setMensajeRenovacion("Dato copiado."); }
    catch { setErrorRenovacion("Seleccioná el dato y copialo manualmente."); }
  };
  const pedido = datosRenovacion?.pedido;
  if(pedido?.metodoPago==='paypal')return <p className="rounded-sm border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800">La semana actual se solicitó por PayPal. Para continuar el pago, seleccioná PayPal en el formulario.</p>;
  const estados = {
    pendiente_comprobante: "Esperando comprobante", en_revision: "Comprobante en revisión",
    aprobado: "Pago aprobado", rechazado: "Comprobante rechazado · podés enviar uno nuevo",
  };
  return <div className="space-y-3 rounded-sm border border-borde bg-white p-3 text-xs">
    {avisoRecibido && <div role="dialog" aria-modal="true" aria-label="Comprobante recibido" className="fixed inset-0 z-50 flex items-center justify-center bg-tinta/40 p-4">
      <div className="w-full max-w-md space-y-4 rounded-sm bg-white p-5 text-tinta shadow-xl">
        <p className="text-sm font-medium">Comprobante recibido</p>
        <p className="text-xs leading-6">Recibimos tu comprobante y estamos verificando la transferencia. Cuando aprobemos el pago, te enviaremos un correo de confirmación.</p>
        <p className="text-xs text-tinta-suave">La semana adicional no empieza hasta que su programación sea confirmada.</p>
        <button type="button" className={BTN_PRIMARIO} onClick={() => setAvisoRecibido(false)}>Entendido</button>
      </div>
    </div>}
    <p className="font-medium text-tinta">Transferencia bancaria · semana adicional de 7 días</p>
    <p className="text-tinta-suave">Importe: <strong>{pedido ? `$${pedido.importe.toLocaleString("es-AR")}` : seleccion === "ambas" ? "$15.000" : "$10.000"} ARS</strong>. El pago se acredita únicamente después de verificar la transferencia.</p>
    {datosRenovacion === null && !errorRenovacion && <p className="text-tinta-apagado">Consultando disponibilidad...</p>}
    {datosRenovacion && !datosRenovacion.habilitada &&
      <p role="status" className="text-amber-700">{datosRenovacion.motivo || "Los pagos reales todavía no están habilitados."}</p>}
    {datosRenovacion?.habilitada && !pedido &&
      <button type="button" disabled={ocupadoRenovacion} className={BTN_PRIMARIO} onClick={crear}>
        {ocupadoRenovacion ? "Preparando pedido..." : "Continuar con transferencia"}
      </button>}
    {pedido?.configuracionEstado === "programada" && datosRenovacion?.habilitada &&
      <button type="button" disabled={ocupadoRenovacion} className={BTN_PRIMARIO} onClick={crear}>
        {ocupadoRenovacion ? "Preparando renovación..." : `Solicitar Semana ${(pedido.numeroSemana || 2) + 1}`}
      </button>}
    {pedido && <div className="space-y-3">
      <div className="rounded-sm bg-crema px-3 py-2 text-tinta-suave">
        <p>Estado: <strong>{estados[pedido.estado] || pedido.estado}</strong></p>
        <p className="mt-1">Redes: {(pedido.redes || []).map(redLabel).join(" · ")}</p>
        <p className="mt-1">Importe reservado: <strong>${pedido.importe.toLocaleString("es-AR")} ARS</strong></p>
      </div>
      {["pendiente_comprobante", "rechazado"].includes(pedido.estado) && datosRenovacion?.habilitada && <>
        <details open className="rounded-sm border border-borde p-3">
          <summary className="cursor-pointer font-medium">Entidad bancaria y datos de pago <ChevronDown size={13} className="ml-1 inline"/></summary>
          <div className="mt-3 space-y-3 border-t border-borde pt-3">
            <CampoInfo etiqueta="Entidad bancaria" valor={datosRenovacion.cuenta?.entidad || "—"}/>
            <CampoInfo etiqueta="Titular" valor={datosRenovacion.cuenta?.titular || "—"}/>
            {[["CBU / CVU", datosRenovacion.cuenta?.cbuCvu], ["Alias", datosRenovacion.cuenta?.alias]].map(([etiqueta, valor]) =>
              <div key={etiqueta} className="flex flex-wrap items-end justify-between gap-2">
                <CampoInfo etiqueta={etiqueta} valor={valor || "—"}/>
                <button type="button" className={BTN_SECUNDARIO} onClick={() => copiar(valor || "")}>Copiar</button>
              </div>)}
          </div>
        </details>
        <p className="text-tinta-suave">Transferí exactamente <strong>${pedido.importe.toLocaleString("es-AR")} ARS</strong> y después adjuntá tu comprobante.</p>
        <label className="block font-medium">Comprobante de transferencia (JPG, PNG o PDF, máximo 8 MB)
          <input type="file" accept="image/jpeg,image/png,application/pdf"
            className="mt-2 block w-full rounded-sm border border-dashed border-borde p-3 text-xs"
            onChange={e => setArchivoRenovacion(e.target.files?.[0] || null)}/>
        </label>
        <button type="button" className={BTN_PRIMARIO} disabled={!archivoRenovacion || ocupadoRenovacion} onClick={subir}>
          {ocupadoRenovacion ? "Enviando comprobante..." : "Ya pagué · enviar comprobante"}
        </button>
      </>}
      {pedido.estado === "en_revision" && <p className="text-tinta-suave">Estamos verificando el comprobante. No hace falta enviarlo otra vez.</p>}
      {pedido.estado === "aprobado" && <p className="text-emerald-800">Pago aprobado. La programación de los contenidos de la semana adicional requiere una aprobación independiente; no comienza automáticamente por el pago.</p>}
    </div>}
    {mensajeRenovacion && <p role="status" className="text-emerald-700">{mensajeRenovacion}</p>}
    {errorRenovacion && <p role="alert" className="text-red-700">{errorRenovacion}</p>}
    <p className="text-[11px] leading-5 text-tinta-apagado">Tu comprobante se guarda de forma privada. PayPal todavía no está disponible para cobros reales.</p>
  </div>;
}

export default function PanelClientePublicaciones() {
  const [datos, setDatos] = useState(null);
  const [configurando, setConfigurando] = useState(false);
  const [configurandoSemana2, setConfigurandoSemana2] = useState(false);
  const [detallesPanel, setDetallesPanel] = useState({perfil:null,detalles:{},semanasPagadas:{}});
  const intentoVinculacion = useRef(false);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState("");
  const [mensaje, setMensaje] = useState("");
  const [cerrando, setCerrando] = useState(false);
  const [instagramPorPedido, setInstagramPorPedido] = useState({});
  const [instagramError, setInstagramError] = useState("");
  const [accionInstagram, setAccionInstagram] = useState("");
  const [accionFacebook, setAccionFacebook] = useState("");
  const [solicitudes, setSolicitudes] = useState({});
  const solicitudesEnCurso = useRef(new Set());
  const [consultandoSolicitud, setConsultandoSolicitud] = useState({});
  const [confirmacionesSolicitud, setConfirmacionesSolicitud] = useState({});
  const [gestionandoSolicitud, setGestionandoSolicitud] = useState("");
  const [erroresSolicitud, setErroresSolicitud] = useState({});
  const [planSemanal, setPlanSemanal] = useState({});
  const [medioSemanal, setMedioSemanal] = useState({});
  const [archivosAbiertos, setArchivosAbiertos] = useState({});
  const [renovacionReal, setRenovacionReal] = useState(null);


  const cargarPanel = useCallback(async () => {
    setCargando(true);
    setError("");
    try {
      const respuesta = await fetch(API, { credentials: "same-origin", cache: "no-store" });
      const tipoPanel = respuesta.headers.get("content-type") || "";
      if (!tipoPanel.includes("application/json")) {
        throw new Error(`La API del panel devolvió HTML en vez de JSON (HTTP ${respuesta.status}). Revisá la ruta /api/servicios/clientes/panel y el despliegue del Worker.`);
      }
      let json = await respuesta.json();
      // Solo un 401 confirmado por la API indica que hay que iniciar sesión.
      if (respuesta.status === 401) {
        setDatos({ autenticado: false }); setConfigurando(false);
        setDetallesPanel({ perfil: null, detalles: {} });
        setInstagramPorPedido({}); setRenovacionReal(null);
        return;
      }
      if (!respuesta.ok || !json.ok) throw new Error(json.error || `No se pudo consultar el panel (HTTP ${respuesta.status}).`);
      if (!json.autenticado) {
        setDatos(json); setConfigurando(false);
        setDetallesPanel({ perfil: null, detalles: {} });
        setInstagramPorPedido({}); setRenovacionReal(null);
        return;
      }
      // Si el pedido acaba de crearse en este navegador, vincularlo en silencio
      // mediante la clave privada guardada en esta pestaña. El servidor exige
      // sesión verificada y valida el token; nunca confiamos solo en el código.
      if (!intentoVinculacion.current) {
        intentoVinculacion.current = true;
        let pendiente = null;
        try { pendiente = JSON.parse(sessionStorage.getItem(PEDIDO_SESION) || "null"); } catch { /* Sin acceso local */ }
        // Compatibilidad con enlaces anteriores: solo se vinculan tras verificar
        // la sesión y la clave original; nunca se vuelve a mostrar el configurador.
        const fragmento = new URLSearchParams(window.location.hash.slice(1));
        if (VALIDAR_PEDIDO.test(fragmento.get("pedido") || "") && VALIDAR_CLAVE.test(fragmento.get("clave") || "")) {
          pendiente = { id: fragmento.get("pedido"), tokenAcceso: fragmento.get("clave") };
          window.history.replaceState(window.history.state, "", window.location.pathname + window.location.search);
        }
        if (VALIDAR_PEDIDO.test(pendiente?.id || "") && VALIDAR_CLAVE.test(pendiente?.tokenAcceso || "") &&
            !(json.pedidos || []).some(p => p.pedidoId === pendiente.id)) {
          try {
            const r = await fetch(`${API}/vincular`, {
              method: "POST", credentials: "same-origin", cache: "no-store",
              headers: { "Content-Type": "application/json", "X-Comunidad-Panel": "1" },
              body: JSON.stringify({ pedidoId: pendiente.id, clave: pendiente.tokenAcceso }),
            });
            const info = await r.json().catch(() => ({}));
            if (r.ok && info.ok) {
              const actualizado = await fetch(API, { credentials: "same-origin", cache: "no-store" });
              const nuevo = await actualizado.json().catch(() => null);
              if (actualizado.ok && nuevo?.ok) json = nuevo;
            }
          } catch { /* La falta de red no concede acceso ni expone la clave. */ }
        }
      }
      setDatos(json);
      try {
        const pidReal=json.pedidos?.[0]?.pedidoId;
        if(pidReal){
          const pago=await fetch(`/api/servicios/publicaciones/renovacion-transferencia?pedidoId=${encodeURIComponent(pidReal)}`,
            {credentials:"same-origin",cache:"no-store"});
          const j=await pago.json().catch(()=>null);
          if(pago.ok&&j?.ok)setRenovacionReal(j.pedido||null);
        } else setRenovacionReal(null);
      } catch { /* La consulta adicional no debe bloquear el panel. */ }
      try {
        const detalleRespuesta = await fetch(`${API}/detalles`,{credentials:"same-origin",cache:"no-store"});
        const detalle = await detalleRespuesta.json();
        if (detalleRespuesta.ok && detalle?.ok) { // FASE4_V2_CONEXIONES_DESDE_DETALLES
          const conexiones = Object.fromEntries(
            Object.entries(detalle.detalles || {})
              .filter(([, item]) => item?.cuentas?.instagram)
              .map(([pedidoId, item]) => [pedidoId, item.cuentas.instagram])
          );
          setInstagramPorPedido(conexiones);
          setInstagramError("");
        }
        if (detalleRespuesta.ok && detalle.ok) setDetallesPanel({perfil:detalle.perfil||null,detalles:detalle.detalles||{},semanasPagadas:detalle.semanasPagadas||{}});
      } catch { /* El resumen del panel sigue disponible. */ }
    } catch (e) {
      // No borrar la sesión visual ni los pedidos por un error 503 / de red.
      setError(`${e.message || "No se pudo cargar el panel."} Es un error de consulta, no un cierre de sesión. Los datos visibles pueden estar desactualizados. Probá «Actualizar».`);
    } finally { setCargando(false); }
  }, []);
  useEffect(() => { cargarPanel(); }, [cargarPanel]);
  const cargarRenovacionReal = useCallback(async pedidoId => {
    const r = await fetch(`/api/servicios/publicaciones/renovacion-transferencia?pedidoId=${encodeURIComponent(pedidoId)}`,
      {credentials:"same-origin",cache:"no-store"});
    const j = await r.json().catch(() => ({}));
    if(!r.ok || j.ok!==true)throw new Error(j.error||"No se pudo consultar la renovación.");
    setRenovacionReal(j.pedido || null);
    return j.pedido || null;
  },[]);
  useEffect(() => {
    if(window.location.hash==="#programar-semana-2" && renovacionReal?.estado==="activada" &&
       !["en_revision","aprobada","programada"].includes(renovacionReal.configuracionEstado)){
      setConfigurandoSemana2(true);
      requestAnimationFrame(()=>document.getElementById("programar-semana-2")?.scrollIntoView({behavior:"smooth",block:"center"}));
    }
  },[renovacionReal?.estado,renovacionReal?.configuracionEstado]);

  // FASE6_AUTORIZACION_DEMANDA_20261024: la verificación profunda de archivos,
  // conexiones y consentimiento se ejecuta solo cuando se abre el contenido.
  // La confirmación POST mantiene todas las verificaciones en el servidor.
  const consultarSolicitud = useCallback(async pedidoId => {
    if (solicitudesEnCurso.current.has(pedidoId)) return;
    solicitudesEnCurso.current.add(pedidoId);
    setConsultandoSolicitud(prev => ({ ...prev, [pedidoId]: true }));
    setErroresSolicitud(prev => ({ ...prev, [pedidoId]: "" }));
    try {
      const respuesta = await fetch(`/api/servicios/publicaciones/solicitud/estado?pedidoId=${encodeURIComponent(pedidoId)}`,
        { credentials: "same-origin", cache: "no-store" });
      const tipo = respuesta.headers.get("content-type") || "";
      if (!tipo.includes("application/json")) {
        throw new Error(`No se pudo comprobar la autorización (HTTP ${respuesta.status}). Probá nuevamente.`);
      }
      const info = await respuesta.json();
      if (!respuesta.ok || info.ok !== true) throw new Error(info.error || "No se pudo comprobar la autorización.");
      setSolicitudes(prev => ({ ...prev, [pedidoId]: info }));
    } catch (e) {
      setErroresSolicitud(prev => ({ ...prev, [pedidoId]: e?.message || "No se pudo comprobar la autorización." }));
    } finally {
      solicitudesEnCurso.current.delete(pedidoId);
      setConsultandoSolicitud(prev => ({ ...prev, [pedidoId]: false }));
    }
  }, []);

  const registrarSolicitud = async pedidoId => {
    const s = solicitudes[pedidoId];
    if (!s?.listaParaSolicitud || !s.revision || !confirmacionesSolicitud[pedidoId]) return;
    setGestionandoSolicitud(pedidoId);
    setErroresSolicitud(actual => ({ ...actual, [pedidoId]: "" }));
    try {
      const respuesta = await fetch("/api/servicios/publicaciones/solicitud/confirmar", {
        method: "POST", credentials: "same-origin", cache: "no-store",
        headers: { "Content-Type": "application/json", "X-Comunidad-Panel": "1" },
        body: JSON.stringify({ pedidoId, revision: s.revision, aceptoProgramacion: true }),
      });
      const resultado = await respuesta.json();
      if (!respuesta.ok || resultado.ok !== true || !resultado.confirmada || !resultado.vigente ||
          resultado.publicacionHabilitada !== false) throw new Error(resultado.error || "No se pudo registrar la solicitud.");
      setSolicitudes(actual => ({ ...actual, [pedidoId]: resultado }));
      setConfirmacionesSolicitud(actual => ({ ...actual, [pedidoId]: false }));
      setMensaje("La solicitud quedó confirmada. Podés consultar su estado desde este panel.");
    } catch (e) {
      setErroresSolicitud(actual => ({ ...actual, [pedidoId]: e.message || "No se pudo confirmar." }));
    } finally { setGestionandoSolicitud(""); }
  };
  const revocarSolicitud = async pedidoId => {
    if (!window.confirm("¿Revocar la autorización de programación? Los contenidos se conservarán.")) return;
    setGestionandoSolicitud(pedidoId);
    setErroresSolicitud(actual => ({ ...actual, [pedidoId]: "" }));
    try {
      const respuesta = await fetch("/api/servicios/publicaciones/solicitud/revocar", {
        method: "POST", credentials: "same-origin", cache: "no-store",
        headers: { "Content-Type": "application/json", "X-Comunidad-Panel": "1" },
        body: JSON.stringify({ pedidoId, confirmarRevocacion: true }),
      });
      const resultado = await respuesta.json();
      if (!respuesta.ok || resultado.ok !== true) throw new Error(resultado.error || "No se pudo revocar la autorización.");
      setSolicitudes(actual => ({ ...actual, [pedidoId]: { ...actual[pedidoId], confirmada: false,
        vigente: false, requiereNuevaConfirmacion: false, estado: "sin_solicitud" } }));
      setConfirmacionesSolicitud(actual => ({ ...actual, [pedidoId]: false }));
      setMensaje("Autorización revocada. Tus archivos siguen guardados.");
    } catch (e) {
      setErroresSolicitud(actual => ({ ...actual, [pedidoId]: e.message || "No se pudo revocar." }));
    } finally { setGestionandoSolicitud(""); }
  };

  const conectarFacebook = async pedidoId => {
    setAccionFacebook(pedidoId); setError("");
    try {
      const respuesta = await fetch("/api/servicios/meta/pedidos/iniciar", {
        method: "POST", credentials: "same-origin", cache: "no-store",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pedidoId }),
      });
      const info = await respuesta.json().catch(() => ({}));
      if (!respuesta.ok || !info.ok || !info.authorizationUrl) throw new Error(info.error || "No se pudo iniciar Facebook.");
      const url = new URL(info.authorizationUrl);
      if (url.protocol !== "https:" || url.hostname !== "www.facebook.com") throw new Error("La autorización no es válida.");
      window.location.assign(url.toString());
    } catch (e) { setError(e.message || "No se pudo conectar Facebook."); setAccionFacebook(""); }
  };
  const desconectarFacebook = async pedidoId => {
    if (!window.confirm("¿Desconectar Facebook de este pedido? Instagram seguirá conectado.")) return;
    setAccionFacebook(pedidoId); setError("");
    try {
      const r = await fetch(`${API}/detalles/desconectar-facebook`,{
        method:"POST", credentials:"same-origin",headers:{"Content-Type":"application/json","X-Comunidad-Panel":"1"},
        body:JSON.stringify({pedidoId}),
      });
      const info=await r.json();
      if (!r.ok || !info.ok) throw new Error(info.error||"No se pudo desconectar Facebook.");
      setMensaje("Facebook quedó desconectado. Instagram no se modificó.");
      await cargarPanel();
    } catch(e) {setError(e.message||"No se pudo desconectar Facebook.");}
    finally {setAccionFacebook("");}
  };
  const conectarInstagram = async pedidoId => {
    setAccionInstagram(pedidoId); setError("");
    try {
      const respuesta = await fetch(`${API_INSTAGRAM}/iniciar`, {
        method: "POST", credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pedidoId }),
      });
      const info = await respuesta.json();
      if (!respuesta.ok || !info.ok || !info.authorizationUrl) throw new Error(info.error || "No se pudo iniciar Instagram.");
      const url = new URL(info.authorizationUrl);
      if (url.protocol !== "https:" || url.hostname !== "www.facebook.com") throw new Error("La autorización no es válida.");
      window.location.assign(url.toString());
    } catch (e) { setError(e.message || "No se pudo conectar Instagram."); setAccionInstagram(""); }
  };
  const desconectarInstagram = async pedidoId => {
    if (!window.confirm("¿Desconectar Instagram? La conexión de Facebook se conservará.")) return;
    setAccionInstagram(pedidoId); setError("");
    try {
      const respuesta = await fetch(`${API_INSTAGRAM}/desconectar`, {
        method: "POST", credentials: "same-origin",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pedidoId }),
      });
      const info = await respuesta.json();
      if (!respuesta.ok || !info.ok) throw new Error(info.error || "No se pudo desconectar Instagram.");
      setInstagramPorPedido(actual => { const copia = { ...actual }; delete copia[pedidoId]; return copia; });
      // FASE5_CPU_IG_20261024: actualizar también la copia del estado en /panel/detalles.
      // Era la fuente prioritaria del botón y quedaba desactualizada hasta refrescar.
      setDetallesPanel(actual => {
        const item = actual.detalles?.[pedidoId];
        if (!item) return actual;
        return { ...actual, detalles: {
          ...actual.detalles,
          [pedidoId]: { ...item, cuentas: { ...(item.cuentas || {}), instagram: null } },
        } };
      });
      setMensaje("Instagram quedó desconectado de este pedido.");
    } catch (e) { setError(e.message || "No se pudo desconectar Instagram."); }
    finally { setAccionInstagram(""); }
  };
  const salir = async () => {
    setCerrando(true); setError("");
    try {
      const respuesta = await fetch("/api/servicios/clientes/acceso/salir", {
        method: "POST", credentials: "same-origin", headers: { "Content-Type": "application/json" }, body: "{}",
      });
      if (!respuesta.ok) throw new Error("No se pudo cerrar la sesión.");
      window.location.assign(BASE);
    } catch (e) { setError(e.message || "No se pudo cerrar la sesión."); setCerrando(false); }
  };


function fechaLocal(valor, zonaHoraria) {
  if (!valor) return "Por confirmar";
  const d = new Date(valor);
  if (!Number.isFinite(d.getTime())) return "Por confirmar";
  try { return new Intl.DateTimeFormat("es-AR", {
    day:"numeric", month:"short", hour:"2-digit", minute:"2-digit",
    ...(zonaHoraria ? { timeZone:zonaHoraria } : {}),
  }).format(d); }
  catch { return new Intl.DateTimeFormat("es-AR", {day:"numeric",month:"short",hour:"2-digit",minute:"2-digit"}).format(d); }
}
function enlacePublicado(contenido, red) {
  // Cada red utiliza exclusivamente su enlace confirmado: un enlace general
  // puede corresponder a Instagram y no debe mostrarse como Facebook.
  const valor = contenido?.urlsPublicadas?.[red] || contenido?.enlaces?.[red] || contenido?.[`${red}UrlPublicada`];
  if (typeof valor !== "string") return "";
  try {
    const u = new URL(valor);
    const dominios = red === "instagram"
      ? ["instagram.com", "www.instagram.com"]
      : ["facebook.com", "www.facebook.com", "m.facebook.com"];
    return u.protocol === "https:" && dominios.includes(u.hostname) ? u.toString() : "";
  } catch { return ""; }
}
function urlWebSegura(valor) {
  if (typeof valor !== "string" || !valor.trim()) return "";
  try {
    const url = new URL(/^[a-z][a-z0-9+.-]*:/i.test(valor) ? valor : `https://${valor}`);
    return ["http:", "https:"].includes(url.protocol) && !url.username && !url.password ? url.toString() : "";
  } catch { return ""; }
}
function horaLocalEn12Horas(hora) {
  const partes = /^(\d{2}):([0-5]\d)$/.exec(hora || "");
  if (!partes) return "Hora por confirmar";
  const h = Number(partes[1]);
  return `${h % 12 || 12}:${partes[2]} ${h < 12 ? "a. m." : "p. m."}`;
}
function nombreTipo(tipo) { return tipo === "reel" ? "Reel" : tipo === "carrusel" ? "Carrusel" : "Imagen"; }
function fechaContenido(c, zona) {
  const definitiva = c.fechaHoraDefinitiva || c.fechaProgramada || c.programadoPara;
  if (definitiva && Number.isFinite(Date.parse(definitiva))) {
    try {
      return new Intl.DateTimeFormat("es-AR", {
        weekday: "long", day: "numeric", hour: "2-digit", minute: "2-digit",
        ...(zona ? { timeZone: zona } : {}),
      }).format(new Date(definitiva));
    } catch { /* Mantener el horario elegido aunque la zona sea inválida. */ }
  }
  // El cliente ya eligió un día y una hora. No inventar un número de día
  // hasta que Administración confirme la fecha concreta.
  if (c.diaPreferido && c.horaLocalPreferida) {
    return `${c.diaPreferido} · ${c.horaLocalPreferida}`;
  }
  return "Horario pendiente";
}
function tieneEstadoActivo(p) {return ["activo","activado","en_curso"].includes(p.estadoServicio) || ["activa","en_curso"].includes(p.prueba?.estado);}
function infoPersonal(datos, pedido) {
  const perfil = datos?.perfil || datos?.usuario || datos?.cliente || {};
  const cliente = pedido?.cliente || {};
  return {
    nombre: perfil.nombreApellido || perfil.nombreCompleto || perfil.nombre || cliente.nombreApellido || cliente.nombre || "Pendiente de registrar",
    emprendimiento: perfil.emprendimiento || perfil.nombreEmprendimiento || (typeof pedido?.negocio === "string" ? pedido.negocio : pedido?.negocio?.nombre) || "Pendiente de registrar",
    whatsapp: perfil.whatsapp || perfil.telefono || cliente.whatsapp || pedido?.whatsapp || "Pendiente de registrar",
    pais: perfil.pais || "No informado",
    web: perfil.web || "",
  };
}
  const pedidos = Array.isArray(datos?.pedidos) ? datos.pedidos : [];
  const pedidoPrincipal = pedidos[0];
  const personal = infoPersonal({...datos,perfil:detallesPanel.perfil||datos?.perfil||datos?.usuario?.perfil}, pedidoPrincipal);
  return <main className="min-h-[76vh] bg-[#f6f7f9] px-3 py-7 text-tinta sm:px-6 sm:py-9" style={{fontFamily: "Montserrat, system-ui, sans-serif",fontWeight:400}}>
    <RetornoPaypalRenovacion alActualizar={setRenovacionReal}/>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500&display=swap" />
    <div className="mx-auto max-w-5xl space-y-5">
      <header className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="mb-1 text-xs font-medium tracking-wide text-terracota-oscuro">Comunidad Semanal</p>
          <h1 className="text-xl font-medium text-tinta sm:text-2xl">Bienvenido a tu panel privado</h1>
          <p className="mt-1 max-w-2xl text-xs leading-5 text-tinta-apagado">Aca podes revisar tu email registrado, las cuentas conectadas, tu plan actual, el contenido detallado y programado, y configurar una nueva semana.</p>
        </div>
        <div className="flex items-center gap-2">
          <button type="button" onClick={cargarPanel} disabled={cargando} className={BTN_SECUNDARIO}><RefreshCw size={13}/> Actualizar</button>
          {datos?.autenticado ? <button type="button" disabled={cerrando} onClick={salir} className={BTN_SECUNDARIO}><LogOut size={13}/> Salir</button>
            : <Link to={`${BASE}?acceso=ingreso`} className={BTN_PRIMARIO}>Iniciar sesión <ArrowRight size={13}/></Link>}
        </div>
      </header>

      {cargando && <div className={`${CARD} p-5 text-xs text-tinta-apagado`}>Cargando tu panel...</div>}
      {error && <div role="alert" className="rounded-sm border border-red-200 bg-red-50 px-4 py-3 text-xs text-red-800">{error}</div>}
      {mensaje && <div role="status" className="rounded-sm border border-emerald-200 bg-emerald-50 px-4 py-3 text-xs text-emerald-800">{mensaje}</div>}
      {!cargando && !error && (!datos || !datos.autenticado) && <section className={`${CARD} p-5`}>
        <h2 className="text-sm font-medium">Accedé a tu cuenta</h2>
        <p className="mt-1 text-xs leading-5 text-tinta-apagado">Para ingresar a tu panel, solicitá un nuevo código de seis dígitos desde Iniciar sesión.</p>
        <Link to={`${BASE}?acceso=ingreso`} className={`${BTN_PRIMARIO} mt-3`}>Iniciar sesión <ArrowRight size={13}/></Link>
      </section>}

      {!cargando && datos?.autenticado && <>
        <section className={`${CARD} overflow-hidden`} aria-label="Datos personales">
          <div className="flex items-center justify-between border-b border-borde px-4 py-3 sm:px-5">
            <div className="flex items-center gap-2"><UserRound size={16} className="text-terracota"/><h2 className="text-sm font-medium">Datos personales</h2></div>
            <span className="inline-flex items-center gap-1 rounded-sm bg-emerald-50 px-2 py-1 text-[11px] font-medium text-emerald-700"><ShieldCheck size={13}/> Email confirmado</span>
          </div>
          <div className="grid gap-x-6 gap-y-4 p-4 sm:grid-cols-2 sm:p-5">
            <CampoInfo etiqueta="Email confirmado" valor={datos.email || "—"}/>
            <CampoInfo etiqueta="Nombre y apellido" valor={personal.nombre}/>
            <CampoInfo etiqueta="Nombre emprendimiento" valor={personal.emprendimiento}/>
            <CampoInfo etiqueta="WhatsApp" valor={personal.whatsapp}/>
            <CampoInfo etiqueta="País" valor={personal.pais}/>
            {urlWebSegura(personal.web) && <CampoInfo etiqueta="Web o enlace principal" valor={<a className="text-terracota-oscuro underline underline-offset-2" href={urlWebSegura(personal.web)} rel="noopener noreferrer" target="_blank">{personal.web}</a>}/>}
          </div>
        </section>



        {pedidos.length === 0 ? <>
          <section className={`${CARD} space-y-3 p-4`}>
            <h2 className="text-sm font-medium">Cuentas</h2>
            <p className="text-xs leading-5 text-tinta-apagado">Facebook e Instagram estarán disponibles para conectar después de preparar tu primera semana.</p>
            <div className="grid gap-2 sm:grid-cols-2">
              {["facebook","instagram"].map(red => <div key={red} className="flex items-center gap-2 rounded-sm border border-borde bg-crema px-3 py-2">
                <LogoRed red={red} size={20}/><span className="text-xs font-medium">{redLabel(red)}</span><span className="ml-auto text-[11px] text-tinta-apagado">Sin conectar</span>
              </div>)}
            </div>
          </section>
          <section className={`${CARD} space-y-3 p-4`}>
            <h2 className="text-sm font-medium">Programá tu primera semana</h2>
            <p className="text-xs leading-5 text-tinta-apagado">Prepará tu contenido semanal y envialo para que lo revisemos y publiquemos en tus cuentas.</p>
            <button type="button" className={BTN_PRIMARIO} onClick={() => setConfigurando(v=>!v)}>
              {configurando ? "Cerrar" : "Programá tu primera semana"} <ChevronDown size={13}/>
            </button>
          </section>
          {configurando && <EditorPrimeraSemana perfil={detallesPanel.perfil || datos.perfil || {}} email={datos.email} alFinalizar={() => {setConfigurando(false); cargarPanel(); setMensaje("Estamos revisando tus contenidos. Recibirás pronto un correo con la confirmación.");}} />}
        </> : pedidos.map((p) => {
          const redes = Array.isArray(p.redes) ? p.redes : [];
          const contenidos = Array.isArray(p.contenidos) ? p.contenidos : [];
          const detalle = detallesPanel.detalles?.[p.pedidoId];
          const semanasPagadas = detallesPanel.semanasPagadas?.[p.pedidoId] || [];
          const ig = detalle?.cuentas?.instagram || instagramPorPedido[p.pedidoId];
          const facebook = detalle?.cuentas?.facebook !== undefined ? detalle.cuentas.facebook : p.facebook;
          const contenidosVistos = detalle?.contenidos?.length ? contenidos.map(c=>({...c,...(detalle.contenidos.find(v=>v.id===c.id)||{})})) : contenidos;
          const solicitud = solicitudes[p.pedidoId];
          const pruebaActiva = tieneEstadoActivo(p);
          const prueba = detalle?.prueba || p.prueba;
          const publicados = contenidosVistos.reduce((s, c) => s + redes.filter(red =>
            c.publicadoEn?.includes?.(red) || c.estadoPorRed?.[red] === "publicado").length, 0);
          const programados = contenidosVistos.reduce((s, c) => s + redes.filter(red =>
            ["programado", "publicado"].includes(c.estadoPorRed?.[red] || c.estado)).length, 0);
          const total = redes.length * Math.max(contenidos.length, 4);
          const programacionConfirmada = total > 0 && programados === total &&
            contenidosVistos.every(c => [c.fechaHoraDefinitiva, c.fechaProgramada, c.programadoPara]
              .some(valor => valor && Number.isFinite(Date.parse(valor))));
          const archivosPorCorregir = p.estadoContenidos === "correccion_solicitada";
          const archivosIncompletos = ["pendiente_carga", "en_preparacion"].includes(p.estadoContenidos);
          return <article key={p.pedidoId} className="space-y-5">
            <section className={`${CARD} p-4 sm:p-5`} aria-label="Cuentas">
              <div className="mb-4"><h2 className="text-sm font-medium">Cuentas</h2><p className="mt-1 text-xs leading-5 text-tinta-apagado">{redes.length > 0 && redes.every(red => red === "facebook" ? Boolean(facebook) : Boolean(ig)) ? "Tus cuentas están conectadas. Ahora podemos publicar automáticamente tu contenido programado." : "Conectá las cuentas seleccionadas después de preparar tu primera semana."}</p></div>
              {redes.length ? redes.map((red) => {
                const conexion = red === "facebook" ? facebook : ig;
                const conectada = Boolean(conexion);
                return <div key={red} className="flex flex-wrap items-center justify-between gap-3 border-t border-borde py-3 first:border-t-0">
                  <div className="flex min-w-0 items-center gap-3">
                    <LogoRed red={red} size={25}/>
                    <div className="min-w-0"><p className="text-xs font-medium text-tinta">{redLabel(red)}</p>
                    {conectada ? <><p className="max-w-xs truncate text-xs text-tinta-suave">{red === "facebook" ? conexion.nombre || "Página conectada" : `@${conexion.usuario}`}</p>
                      {conexion.pageId && <p className="text-[11px] text-tinta-apagado">ID: {conexion.pageId}</p>}
                      <p className="text-[11px] text-tinta-apagado">Estado: conectada</p></>
                      : <p className="text-[11px] text-tinta-apagado">{red === "instagram" && instagramError ? "Estado de conexión no disponible" : "Sin conectar"}</p>}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {conectada ? <Etiqueta valor="conectada" texto="Conectada"/> : <button type="button" className={BTN_PRIMARIO} disabled={Boolean(accionInstagram || accionFacebook)}
                      onClick={() => red === "facebook" ? conectarFacebook(p.pedidoId) : conectarInstagram(p.pedidoId)}>
                      {((red === "facebook" && accionFacebook === p.pedidoId) || (red === "instagram" && accionInstagram === p.pedidoId)) ? "Conectando..." : "Conectar"}
                    </button>}
                    {conectada && <button type="button"
                      className="rounded-sm border border-borde bg-white px-2.5 py-1.5 text-xs font-medium text-tinta-suave hover:bg-crema disabled:cursor-not-allowed disabled:opacity-50"
                      disabled={p.estadoServicio !== "sin_activar" || Boolean(accionInstagram || accionFacebook)}
                      title={p.estadoServicio === "sin_activar" ? "Desconectar cuenta" : "No podés desconectar mientras haya una semana activa o publicaciones pendientes."}
                      onClick={() => red === "facebook" ? desconectarFacebook(p.pedidoId) : desconectarInstagram(p.pedidoId)}>
                      Desconectar
                    </button>}
                  </div>
                </div>;
              }) : <p className="text-xs text-tinta-apagado">Todavía no hay redes elegidas para este pedido.</p>}
              {instagramError && redes.includes("instagram") && <p className="mt-2 text-[11px] text-amber-700">Estado de Instagram temporalmente no disponible: {instagramError}</p>}
            </section>

            <section className={`${CARD} overflow-hidden`} aria-label="Resumen de prueba gratuita">
              <div className="border-b border-terracota-suave bg-terracota-suave/70 px-4 py-3 sm:px-5">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div><h2 className="text-sm font-medium">{p.modalidad === "prueba_gratuita" ? "Semana 1" : "Resumen de tu plan"}</h2><p className="mt-0.5 text-[11px] text-tinta-apagado">{p.modalidad === "prueba_gratuita" ? "Prueba gratuita" : "Plan contratado"}</p></div>
                  <Etiqueta valor={p.estadoServicio}/>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 p-4 text-xs sm:p-5">
                <CampoInfo etiqueta="Redes elegidas" valor={redes.map(redLabel).join(" · ") || "—"}/>
                <CampoInfo etiqueta="Estado" valor={pruebaActiva ? "En curso" : estado(prueba?.estado || p.estadoServicio)}/>
                <CampoInfo etiqueta="Publicaciones programadas" valor={pruebaActiva ? `${programados}/${total}` : "Aún sin activar"}/>
                <CampoInfo etiqueta="Publicaciones realizadas" valor={pruebaActiva ? `${publicados}/${total}` : "Sin publicaciones"}/>
                {pruebaActiva && prueba?.inicioEn && <CampoInfo etiqueta="Desde" valor={fechaLocal(prueba.inicioEn, detalle?.zonaHoraria)}/>}
                {pruebaActiva && prueba?.finEn && <CampoInfo etiqueta="Hasta" valor={fechaLocal(prueba.finEn, detalle?.zonaHoraria)}/>}
              </div>
              {total > 0 && publicados === total && <p className="border-t border-borde px-4 py-3 text-xs text-emerald-700 sm:px-5">Todos tus contenidos se publicaron correctamente.</p>}
              {p.modalidad === "prueba_gratuita" && <p className="border-t border-borde px-4 py-3 text-xs leading-5 text-tinta-suave sm:px-5">Te notificaremos por correo cuando tu prueba gratuita esté por finalizar.</p>}
            </section>

            <details className={`${CARD} group`} aria-label="Contenido programado"
              onToggle={e => {
                if (!e.currentTarget.open || p.modalidad !== "prueba_gratuita" ||
                    p.estadoServicio !== "sin_activar" || solicitudes[p.pedidoId] ||
                    erroresSolicitud[p.pedidoId]) return;
                consultarSolicitud(p.pedidoId);
              }}>
              <summary className="flex cursor-pointer list-none items-center justify-between gap-3 px-4 py-3 [&::-webkit-details-marker]:hidden sm:px-5">
                <div><h2 className="text-sm font-medium">Contenido programado</h2>
                <p className="mt-1 text-xs leading-5 text-tinta-apagado">
                  {programacionConfirmada
                    ? "Este contenido ya está programado para publicarse con la configuración que definiste."
                    : "La publicación comenzará después de la revisión y la activación de tu semana."}
                </p></div><ChevronDown size={15} className="shrink-0 text-tinta-apagado transition group-open:rotate-180" />
              </summary>
              <div className="border-t border-borde p-4 sm:p-5">
              {redes.map(red => <div key={red} className="mb-4 last:mb-0">
                <div className="mb-2 flex items-center gap-2 border-b border-borde pb-2"><LogoRed red={red} size={18}/><h3 className="text-xs font-medium">{redLabel(red)}</h3></div>
                <div className="space-y-1">{contenidosVistos.length ? contenidosVistos.map((c, i) => {
                  const url = enlacePublicado(c, red);
                  const estadoPorRed = c.estadoPorRed?.[red] || c.estado;
                  const sinFecha = ![c.fechaHoraDefinitiva, c.fechaProgramada, c.programadoPara]
                    .some(valor => valor && Number.isFinite(Date.parse(valor)));
                  const estadoVisible = ["rechazado", "correccion_solicitada", "error"].includes(estadoPorRed)
                    ? "Requiere corrección"
                    : sinFecha ? "Por confirmar" : undefined;
                  return <div key={`${red}:${c.id || i}`} className="flex flex-wrap items-center justify-between gap-3 border-b border-borde py-3 last:border-b-0 text-xs">
                    <div className="min-w-0 space-y-1">
                      <p className="font-medium text-tinta">Contenido {i+1} · {nombreTipo(c.tipo)}</p>
                      <p className="text-[11px] text-tinta-apagado">{fechaContenido(c, detalle?.zonaHoraria)} · hora local</p>
                    </div>
                    <div className="flex shrink-0 flex-wrap items-center gap-2">
                      <Etiqueta valor={estadoPorRed} texto={estadoVisible}/>
                      {red === "instagram" && estadoPorRed === "publicado" && !url &&
                        <span className="text-[11px] text-tinta-apagado">Enlace pendiente</span>}
                      {url && <>
                        <a href={url} target="_blank" rel="noopener noreferrer"
                          className={`${BTN_SECUNDARIO} text-[11px]`}>Ver publicación <ExternalLink size={12}/></a>
                        {red === "instagram" && <button type="button" className={`${BTN_SECUNDARIO} text-[11px]`}
                          onClick={() => navigator.clipboard.writeText(url)
                            .then(() => setMensaje("Enlace de Instagram copiado. Abrilo en la app si el navegador no lo muestra."))
                            .catch(() => setError("No se pudo copiar el enlace. Abrí la publicación desde Instagram."))}>
                          Copiar enlace
                        </button>}
                      </>}
                    </div>
                  </div>;
                }) : <p className="py-2 text-xs text-tinta-apagado">Todavía no hay contenidos cargados.</p>}</div>
              </div>)}
              {p.modalidad === "prueba_gratuita" && p.estadoServicio === "sin_activar" && (
                <div className="mt-4 border-t border-borde pt-3">
                  <button type="button" className={BTN_SECUNDARIO}
                    disabled={Boolean(consultandoSolicitud[p.pedidoId]) || Boolean(gestionandoSolicitud)}
                    onClick={() => consultarSolicitud(p.pedidoId)}>
                    {consultandoSolicitud[p.pedidoId] ? "Comprobando requisitos..." : "Actualizar requisitos de publicación"}
                  </button>
                </div>
              )}
              {/* La autorización sigue siendo explícita cuando el servidor la exige.
                  No se muestra otro paso mientras el pedido está en revisión. */}
              {p.modalidad === "prueba_gratuita" && solicitud?.listaParaSolicitud && (!solicitud?.vigente || solicitud?.requiereNuevaConfirmacion) && (
                <div className="mt-4 space-y-2 border-t border-borde pt-3">
                  {solicitud.motivos?.length > 0 && <p className="text-xs text-amber-700">{solicitud.motivos.join(" · ")}</p>}
                  <label className="flex items-start gap-2 text-xs leading-5 text-tinta-suave">
                    <input type="checkbox" className="mt-1 accent-terracota"
                      checked={Boolean(confirmacionesSolicitud[p.pedidoId])}
                      onChange={e => setConfirmacionesSolicitud(v => ({ ...v, [p.pedidoId]: e.target.checked }))}/>
                    <span>Autorizo la programación y publicación de mis contenidos en las redes y horarios seleccionados.</span>
                  </label>
                  <button type="button" className={BTN_PRIMARIO}
                    disabled={!solicitud.revision || !confirmacionesSolicitud[p.pedidoId] || Boolean(gestionandoSolicitud)}
                    onClick={() => registrarSolicitud(p.pedidoId)}>Autorizar publicación <Send size={13}/></button>
                </div>
              )}
              {p.modalidad === "prueba_gratuita" && solicitud?.vigente && p.estadoServicio === "sin_activar" && (
                <div className="mt-3 flex justify-end">
                  <button type="button" className="text-[11px] text-tinta-apagado underline underline-offset-2 disabled:opacity-50"
                    disabled={Boolean(gestionandoSolicitud)} onClick={() => revocarSolicitud(p.pedidoId)}>Revocar autorización</button>
                </div>
              )}
              {erroresSolicitud[p.pedidoId] && <p role="alert" className="mt-2 text-xs text-red-700">{erroresSolicitud[p.pedidoId]}</p>}
              {(archivosPorCorregir || archivosIncompletos) && (
                <details className="mt-4 rounded-sm border border-amber-200 bg-amber-50/50 p-3"
                  onToggle={e => { const abierto = e.currentTarget.open; setArchivosAbiertos(v => ({ ...v, [p.pedidoId]: abierto })); }}>
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-2 text-xs font-medium text-amber-900 [&::-webkit-details-marker]:hidden">
                    {archivosPorCorregir ? "Corregir archivos observados" : "Completar archivos pendientes"}
                    <ChevronDown size={13}/>
                  </summary>
                  {archivosAbiertos[p.pedidoId] && <ArchivosPedido pedido={{ id: p.pedidoId }}/>}
                </details>
              )}
              </div>
            </details>

            {semanasPagadas.map(semana => {
              const finalizada = semana.estado === "finalizada";
              const futura = semana.inicio && new Date(semana.inicio).getTime() > Date.now();
              return <div key={semana.id} className="space-y-3">
                <section className={`${CARD} overflow-hidden`} aria-label={`Semana ${semana.numeroSemana}`}>
                  <div className="flex items-center justify-between gap-3 border-b border-terracota-suave bg-terracota-suave/70 px-4 py-3 sm:px-5">
                    <div><h2 className="text-sm font-medium">Semana {semana.numeroSemana}</h2><p className="mt-0.5 text-[11px] text-tinta-apagado">Semana pagada</p></div>
                    <Etiqueta valor={finalizada ? "finalizado" : futura ? "programado" : "activo"} texto={finalizada ? "Finalizada" : futura ? "Programada" : "Activo"}/>
                  </div>
                  <div className="grid grid-cols-2 gap-4 p-4 text-xs sm:p-5">
                    <CampoInfo etiqueta="Redes elegidas" valor={semana.redes.map(redLabel).join(" · ")}/>
                    <CampoInfo etiqueta="Estado" valor={finalizada ? "Finalizada" : futura ? "Próxima" : "En curso"}/>
                    <CampoInfo etiqueta="Publicaciones programadas" valor={`${semana.programadas}/${semana.total}`}/>
                    <CampoInfo etiqueta="Publicaciones realizadas" valor={`${semana.realizadas}/${semana.total}`}/>
                    <CampoInfo etiqueta="Desde" valor={fechaLocal(semana.inicio,semana.zonaHoraria)}/>
                    <CampoInfo etiqueta="Hasta" valor={fechaLocal(semana.fin,semana.zonaHoraria)}/>
                  </div>
                  <p className="border-t border-borde px-4 py-3 text-xs text-tinta-apagado sm:px-5">Podés consultar el avance de tu semana contratada desde este panel.</p>
                </section>
                <details className={`${CARD} group`} aria-label={`Contenido programado de Semana ${semana.numeroSemana}`}>
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-2 px-4 py-3 text-sm font-medium [&::-webkit-details-marker]:hidden sm:px-5">Contenido programado · Semana {semana.numeroSemana} <ChevronDown size={13} className="group-open:rotate-180"/></summary>
                  <div className="space-y-4 border-t border-borde p-4 sm:p-5">
                    {semana.redes.map(red => <div key={red}>
                      <div className="mb-2 flex items-center gap-2"><LogoRed red={red} size={17}/><h3 className="text-xs font-medium">{redLabel(red)}</h3></div>
                      {semana.contenidos.map((c,i) => {
                        const enlace=enlacePublicado(c,red);
                        const estadoRed=c.estadoPorRed?.[red]||"programado";
                        return <div key={`${red}-${c.id||i}`} className="flex flex-wrap items-center justify-between gap-3 border-t border-borde py-3 text-xs">
                          <div><p className="font-medium">Contenido {i+1} · {nombreTipo(c.tipo)}</p>
                            <p className="text-[11px] text-tinta-apagado">{fechaContenido(c,semana.zonaHoraria)} · hora local</p></div>
                          <div className="flex flex-wrap items-center gap-2"><Etiqueta valor={estadoRed}/>
                            {estadoRed === "publicado" && enlace && <a href={enlace} target="_blank" rel="noopener noreferrer" className={`${BTN_SECUNDARIO} text-[11px]`}>Ver publicación <ExternalLink size={12}/></a>}
                            {estadoRed === "publicado" && red === "instagram" && !enlace && <span className="text-[11px] text-tinta-apagado">Enlace pendiente</span>}
                          </div>
                        </div>;
                      })}
                    </div>)}
                  </div>
                </details>
              </div>;
            })}

            {p.pedidoId === pedidoPrincipal?.pedidoId && renovacionReal && ["en_revision","aprobado"].includes(renovacionReal.estado) && (
              <section className={`${CARD} space-y-2 p-4 sm:p-5`} aria-label="Renovación bancaria pendiente">
                <h2 className="text-sm font-medium">Renovación bancaria</h2>
                <p className="text-xs text-tinta-suave">Pedido: <span className="break-all">{renovacionReal.pedidoId}</span></p>
                <Etiqueta valor="verificando" texto={renovacionReal.estado === "en_revision" ? "Pendiente" : "Pago aprobado · pendiente de activación"}/>
              </section>
            )}
            {p.pedidoId === pedidoPrincipal?.pedidoId && renovacionReal?.estado === "activada" && renovacionReal.configuracionEstado !== "programada" && (
              <section className={`${CARD} space-y-3 p-4 sm:p-5`} aria-label="Semana pagada">
                <h2 className="text-sm font-medium">Semana {renovacionReal.numeroSemana || 2} · pagada</h2>
                {renovacionReal.configuracionEstado === "programada" ?
                  <p role="status" className="text-xs text-emerald-700">Contenidos aprobados y programados. Consultá los detalles de la semana debajo de Semana 1.</p> :
                renovacionReal.configuracionEstado === "en_revision" ?
                  <p role="status" className="text-xs text-tinta-suave">Recibimos los cuatro contenidos. Están pendientes de revisión administrativa; todavía no están programados.</p> :
                  <button type="button" id="programar-semana-2" className={BTN_PRIMARIO}
                    onClick={() => setConfigurandoSemana2(v=>!v)}>
                    {configurandoSemana2 ? "Cerrar editor" : renovacionReal.configuracionEstado === "en_preparacion" ? "Continuar preparación" : "Programar nueva semana"} <ChevronDown size={13}/>
                  </button>}
                {configurandoSemana2 && !["en_revision","aprobada","programada"].includes(renovacionReal.configuracionEstado) &&
                  <EditorPrimeraSemana key={renovacionReal.id}
                    perfil={{...datos.perfil,...detallesPanel.perfil, nombreApellido:personal.nombre, emprendimiento:personal.emprendimiento, whatsapp:personal.whatsapp}}
                    email={datos.email} pedidoRenovacion={renovacionReal}
                    alFinalizar={() => {
                      setConfigurandoSemana2(false);
                      setRenovacionReal(prev => prev && ({...prev,configuracionEstado:"en_revision"}));
                      setMensaje("La semana pagada fue enviada a revisión administrativa.");
                      cargarRenovacionReal(p.pedidoId).catch(() => {});
                    }}/>
                }
                {renovacionReal.configuracionEstado === "en_revision" && Array.isArray(renovacionReal.resumenContenidos) &&
                  <details className="rounded-sm border border-borde p-3">
                    <summary className="cursor-pointer text-xs font-medium">Ver contenidos de la semana <ChevronDown size={13} className="inline"/></summary>
                    <div className="mt-3 space-y-2 border-t border-borde pt-3">
                      {renovacionReal.resumenContenidos.map(c=><p key={c.numero} className="text-xs">Contenido {c.numero} · {nombreTipo(c.tipo)} · {c.dia} {horaLocalEn12Horas(c.hora)}</p>)}
                    </div>
                  </details>}
              </section>
            )}

            <details className={`${CARD} group p-4 sm:p-5`}>
              <summary className="flex cursor-pointer list-none items-center justify-between gap-2 text-sm font-medium [&::-webkit-details-marker]:hidden">Configurar otra semana <ChevronDown size={13} className="group-open:rotate-180"/></summary>
              <div className="mt-3 space-y-3 border-t border-borde pt-3">
                <p className="text-xs text-tinta-apagado">Elegí en cuáles de tus redes vinculadas querés publicar</p>
                <div className="grid gap-2 sm:grid-cols-3">
                  {[{nombre:"Facebook",red:"facebook",precio:"$10.000 · USD 10"},{nombre:"Instagram",red:"instagram",precio:"$10.000 · USD 10"},{nombre:"Ambas",red:"ambas",precio:"$15.000 · USD 15",descuento:"25% de ahorro"}].map(op=><button type="button" key={op.red}
                    disabled={op.red==="ambas" ? !(redes.includes("instagram")&&redes.includes("facebook")) : !redes.includes(op.red)}
                    title={op.red==="ambas" ? "Necesitás tener ambas redes vinculadas" : "Red no incluida en el pedido inicial"}
                    onClick={()=>setPlanSemanal(v=>({...v,[p.pedidoId]:op.red}))}
                    className={`rounded-sm border p-3 text-left disabled:cursor-not-allowed disabled:opacity-40 ${planSemanal[p.pedidoId]===op.red?"border-terracota bg-terracota-suave":"border-borde bg-crema"}`}>
                    <p className="text-xs font-medium">{op.nombre}</p><p className="mt-1 text-[11px] text-tinta-apagado">{op.red==="ambas"?"Hasta 8 publicaciones":"Hasta 4 publicaciones"}</p>
                    <p className="mt-1 text-xs font-medium">{op.precio}</p>{op.descuento && <p className="text-[11px] text-emerald-700">{op.descuento}</p>}
                  </button>)}
                </div>
                {planSemanal[p.pedidoId] && <div className="space-y-2 border-t border-borde pt-3">
                  <p className="text-sm font-medium">Elegí como abonar</p>
                  <div className="flex flex-wrap gap-2"><button type="button" className={medioSemanal[p.pedidoId]==="transferencia"?BTN_PRIMARIO:BTN_SECUNDARIO}
                    onClick={()=>setMedioSemanal(v=>({...v,[p.pedidoId]:"transferencia"}))}>Transferencia bancaria</button>
                    <button type="button" className={medioSemanal[p.pedidoId]==="paypal"?BTN_PRIMARIO:BTN_SECUNDARIO}
                    onClick={()=>setMedioSemanal(v=>({...v,[p.pedidoId]:"paypal"}))}>PayPal</button></div>
                  {medioSemanal[p.pedidoId]==="paypal" &&
                    <RenovacionPaypalReal pedidoId={p.pedidoId} seleccion={planSemanal[p.pedidoId]} alActualizar={setRenovacionReal}/>}
                  {medioSemanal[p.pedidoId]==="transferencia" &&
                    <RenovacionTransferenciaReal pedidoId={p.pedidoId} seleccion={planSemanal[p.pedidoId]} alActualizar={setRenovacionReal}/>}
                </div>}
              </div>
            </details>
          </article>;
        })}
      </>}
    </div>
  </main>;
}
