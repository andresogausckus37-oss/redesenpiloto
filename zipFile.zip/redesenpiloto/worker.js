export { AccesoClientesDurable } from "./api/servicios/acceso-clientes-durable.js";
import handlerAdminLogin from "./api/admin/login.js";
import handlerVisitas from "./api/visitas.js";
import { ejecutarPruebaConexionMeta } from "./api/servicios/meta-conexion.js";
import { ejecutarConexionMetaPedido } from "./api/servicios/meta-pedidos.js";
import { ejecutarSimulacionCalendario, ejecutarPreparacionCalendario, ejecutarEnsayoCalendario, ejecutarReservaCalendario } from "./api/servicios/calendario-simulacion.js";
import { ejecutarSolicitudProgramacion } from "./api/servicios/solicitud-programacion.js";
import { ejecutarAdminProgramacion } from "./api/servicios/admin-programacion.js";
import { ejecutarCronClientes, servirMedioCliente } from "./api/servicios/publicaciones-clientes.js";
import { ejecutarActivacionSimulada } from "./api/servicios/activacion-simulada.js";
import { ejecutarPublicacionPiloto, ejecutarImagenPiloto } from "./api/servicios/publicacion-piloto-meta.js";
import { ejecutarAccesoClientes, diagnosticarConfiguracionClientes, ejecutarPanelClientes, obtenerClienteRegistrado } from "./api/servicios/clientes-acceso.js";
import { ejecutarArchivosPedido, ejecutarAdminArchivosPedido } from "./api/servicios/archivos-pedido.js";
import { ejecutarRenovacionTransferencia, ejecutarAdminRenovacionesTransferencia } from "./api/servicios/renovacion-transferencia.js";
import { ejecutarContenidosRenovacionReal } from "./api/servicios/renovacion-contenidos-reales.js";
import { ejecutarRenovacionPaypal } from "./api/servicios/renovacion-paypal.js";
import crypto from "crypto";
import { ejecutarDetallesPanel } from "./api/servicios/cliente-panel-detalles.js";
import { ejecutarTransferenciaEnsayo, ejecutarAdminTransferenciaEnsayo } from "./api/servicios/transferencias-prueba.js";

function sincronizarEntorno(env) {
  const claves = [
    "MONGODB_URI",
    "OPENAI_API_KEY",
    "ADMIN_PASSWORD",
    "CRON_SECRET",
    "THREADS_APP_ID",
    "THREADS_APP_SECRET",
    "INSTAGRAM_ACCESS_TOKEN",
    "FACEBOOK_PAGE_ID",
    "FACEBOOK_PAGE_ACCESS_TOKEN",
    "TELEGRAM_VISITAS_BOT_TOKEN",
    "TELEGRAM_VISITAS_CHAT_ID",
    "RESEND_API_KEY",
  ];
  for (const clave of claves) {
    if (env?.[clave] !== undefined && env?.[clave] !== null) {
      process.env[clave] = String(env[clave]);
    }
  }
}

async function leerBody(request) {
  if (
    request.method === "GET" ||
    request.method === "HEAD"
  ) {
    return {};
  }

  const tipo =
    request.headers.get("content-type") || "";

  if (
    tipo.includes(
      "application/json"
    )
  ) {
    try {
      return await request.json();
    } catch {
      return {};
    }
  }

  if (
    tipo.includes(
      "multipart/form-data"
    )
  ) {
    try {
      const formData =
        await request.formData();

      return Object.fromEntries(
        formData.entries()
      );
    } catch {
      return {};
    }
  }

  if (
    tipo.includes(
      "application/x-www-form-urlencoded"
    )
  ) {
    try {
      return Object.fromEntries(
        new URLSearchParams(
          await request.text()
        )
      );
    } catch {
      return {};
    }
  }

  return {};
}

function headersComoObjeto(request) {
  const headers = {};
  for (const [k, v] of request.headers.entries()) headers[k.toLowerCase()] = v;
  headers.cookie = request.headers.get("cookie") || "";
  headers.authorization = request.headers.get("authorization") || "";
  return headers;
}

function crearRespuestaApi(origen) {
  let statusCode = 200;
  const headers = new Headers({ "Cache-Control": "no-store" });
  let final = null;
  return {
    status(c) { statusCode = Number(c) || 200; return this; },
    setHeader(n, v) { headers.set(n, String(v)); return this; },
    json(d) {
      headers.set("Content-Type", "application/json; charset=utf-8");
      final = new Response(JSON.stringify(d), { status: statusCode, headers });
      return final;
    },
    send(d) {
      if (d !== null && typeof d === "object" && !(d instanceof ArrayBuffer)) return this.json(d);
      final = new Response(d == null ? "" : String(d), { status: statusCode, headers });
      return final;
    },
    redirect(codigoOUrl, urlOpcional) {
      let codigo = 302, url = codigoOUrl;
      if (typeof codigoOUrl === "number") { codigo = codigoOUrl; url = urlOpcional; }
      final = Response.redirect(new URL(String(url), origen).toString(), codigo);
      return final;
    },
    end() { final = new Response(null, { status: statusCode, headers }); return final; },
    obtenerRespuesta() { return final; }
  };
}

async function ejecutarHandlerGenerico(request, env, handler) {
  sincronizarEntorno(env);

  const url = new URL(request.url);

  const req = {
    method: request.method,
    url: request.url,
    query: Object.fromEntries(
      url.searchParams.entries()
    ),
    body: await leerBody(request),
    headers: headersComoObjeto(request),

    env: {},
  };

  const res = crearRespuestaApi(url.origin);

  const retorno = await handler(req, res);

  if (retorno instanceof Response) {
    return retorno;
  }

  return (
    res.obtenerRespuesta() ||
    Response.json(
      { ok: false, error: "La API no generó una respuesta." },
      { status: 500 }
    )
  );
}

// =========================================================
// PEDIDOS DE PUBLICACIONES · ETAPA 2: MONGODB, SIN COBROS ACTIVOS
// Aislado de los pedidos de la tienda y del cron de Mega Bazar.
// Precios validados en el servidor; la vista previa NO sube archivos.
// =========================================================
const PLAN_PUBLICACIONES = Object.freeze({
  id: "comunidad-semanal",
  nombre: "Comunidad Semanal",
  contenidos: 4,
  duracionDias: 7,
});

// Los precios del Worker son la fuente de verdad; no usar precioMostrado.
const PRECIOS_PUBLICACIONES = Object.freeze({
  ARS: Object.freeze({ 1: 10000, 2: 15000 }),
  USD: Object.freeze({ 1: 10, 2: 15 }),
});

// Identificadores IANA admitidos en el configurador (América y España).
const ZONAS_PUBLICACIONES = new Set([
  "America/Argentina/Buenos_Aires", "America/Belize", "America/La_Paz",
  "America/Noronha", "America/Manaus", "America/Rio_Branco",
  "America/Sao_Paulo", "America/Coyhaique", "Pacific/Easter",
  "America/Punta_Arenas", "America/Santiago", "America/Bogota",
  "America/Costa_Rica", "America/Havana", "Pacific/Galapagos",
  "America/Guayaquil", "America/El_Salvador", "Atlantic/Canary",
  "Europe/Madrid", "America/Anchorage", "America/Chicago",
  "America/Denver", "America/New_York", "Pacific/Honolulu",
  "America/Los_Angeles", "America/Phoenix", "America/Guatemala",
  "America/Port-au-Prince", "America/Tegucigalpa", "America/Tijuana",
  "America/Cancun", "America/Chihuahua", "America/Ciudad_Juarez",
  "America/Matamoros", "America/Mazatlan", "America/Mexico_City",
  "America/Hermosillo", "America/Managua", "America/Panama",
  "America/Asuncion", "America/Lima", "America/Puerto_Rico",
  "America/Santo_Domingo", "America/Montevideo", "America/Caracas",
]);
const DIAS_PUBLICACIONES = new Set([
  "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo",
]);
const HORAS_PUBLICACIONES = new Set([
  "09:00", "10:00", "12:00", "14:00", "17:00", "18:00", "19:00", "20:00", "21:00",
]);

function respuestaServicio(datos, estado = 200) {
  return Response.json(datos, {
    status: estado,
    headers: { "Cache-Control": "no-store" },
  });
}

async function leerJsonServicio(request) {
  if (!/^application\/json(?:;|$)/i.test(request.headers.get("content-type") || "")) {
    return { error: "El pedido debe enviarse como JSON.", estado: 415 };
  }
  const lector = request.body?.getReader();
  if (!lector) return { error: "Falta la configuración del pedido.", estado: 400 };
  const decoder = new TextDecoder();
  let texto = "", bytes = 0;
  try {
    while (true) {
      const { done, value } = await lector.read();
      if (done) break;
      bytes += value.byteLength;
      if (bytes > 64 * 1024) {
        await lector.cancel();
        return { error: "El pedido supera el tamaño permitido.", estado: 413 };
      }
      texto += decoder.decode(value, { stream: true });
    }
    texto += decoder.decode();
    const datos = JSON.parse(texto);
    if (!datos || typeof datos !== "object" || Array.isArray(datos)) {
      return { error: "Formato del pedido inválido.", estado: 400 };
    }
    return { datos };
  } catch {
    return { error: "No se pudo leer el JSON del pedido.", estado: 400 };
  }
}

function textoServicio(valor, maximo) {
  return typeof valor === "string" && valor.trim().length <= maximo
    ? valor.trim()
    : null;
}

function urlServicio(valor, maximo, soloHttps = false) {
  const texto = textoServicio(valor, maximo);
  if (texto === null) return null;
  if (!texto) return "";
  try {
    const url = new URL(texto);
    if ((soloHttps ? url.protocol !== "https:" : !["http:", "https:"].includes(url.protocol)) ||
        url.username || url.password || !url.hostname) return null;
    return url.toString();
  } catch {
    return null;
  }
}

// Acepta enlaces https://, www.dominio.com o dominio.com sin reescribirlos.
// Valida una URL segura para evitar esquemas peligrosos al mostrarla después.
function enlaceEscritoServicio(valor, maximo) {
  const texto = textoServicio(valor, maximo);
  if (texto === null || /[\x00-\x1f\x7f]/.test(texto)) return null;
  if (!texto) return "";
  try {
    const tieneProtocolo = /^[a-z][a-z0-9+.-]*:/i.test(texto);
    const destino = new URL(tieneProtocolo ? texto : `https://${texto}`);
    if (!["http:", "https:"].includes(destino.protocol) || destino.username || destino.password || !destino.hostname) return null;
    return texto;
  } catch { return null; }
}

// Los datos recibidos se copian campo por campo: no se persisten claves extra.
function validarConfiguracionServicio(datos) {
  if (datos.planId !== PLAN_PUBLICACIONES.id) {
    return { error: "El plan solicitado no existe." };
  }
  const redes = datos.redes;
  if (!Array.isArray(redes) || redes.length < 1 || redes.length > 2 ||
      new Set(redes).size !== redes.length ||
      !redes.every((red) => red === "instagram" || red === "facebook")) {
    return { error: "Seleccioná Instagram, Facebook o ambas redes." };
  }
  if (!ZONAS_PUBLICACIONES.has(datos.zonaHoraria)) {
    return { error: "Zona horaria no admitida." };
  }

  const n = datos.negocio;
  if (!n || typeof n !== "object" || Array.isArray(n)) {
    return { error: "Faltan los datos del emprendimiento." };
  }
  const negocio = {
    nombre: textoServicio(n.nombre, 120),
    rubro: textoServicio(n.rubro ?? "", 100),
    contacto: textoServicio(n.contacto, 120),
    email: textoServicio(n.email, 160),
    url: enlaceEscritoServicio(n.url ?? "", 300),
    whatsapp: textoServicio(n.whatsapp ?? "", 50),
    publico: textoServicio(n.publico ?? "", 180),
    tono: n.tono ?? "cercano",
  };
  if (!negocio.nombre || !negocio.contacto || !negocio.email ||
      !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(negocio.email) ||
      Object.values(negocio).some((valor) => valor === null) ||
      !["cercano", "profesional", "informal", "promocional"].includes(negocio.tono)) {
    return { error: "Revisá los datos del emprendimiento y el correo electrónico." };
  }
  if (negocio.whatsapp && !/^[+\d()\s.-]{5,50}$/.test(negocio.whatsapp)) {
    return { error: "El número de WhatsApp no es válido." };
  }

  if (!Array.isArray(datos.publicaciones) || datos.publicaciones.length !== PLAN_PUBLICACIONES.contenidos) {
    return { error: "El plan incluye exactamente cuatro contenidos." };
  }
  const publicaciones = datos.publicaciones.map((p, indice) => {
    if (!p || typeof p !== "object" || Array.isArray(p) ||
        p.id !== `contenido-${indice + 1}` ||
        !["reel", "carrusel", "imagen"].includes(p.tipo) ||
        !DIAS_PUBLICACIONES.has(p.dia) || !HORAS_PUBLICACIONES.has(p.hora)) return null;
    if (!(p.tipo === "reel" ? ["9:16"] : ["4:5", "1:1"]).includes(p.formato)) return null;

    const descripcion = textoServicio(p.descripcion ?? "", 1500);
    const ctaInstagram = textoServicio(p.ctaInstagram ?? "", 100);
    const ctaFacebook = textoServicio(p.ctaFacebook ?? "", 100);
    const urlFacebook = enlaceEscritoServicio(p.urlFacebook ?? "", 500);
    const hashtags = textoServicio(p.hashtags ?? "", 240);
    if ([descripcion, ctaInstagram, ctaFacebook, urlFacebook, hashtags].some((v) => v === null)) return null;

    const archivos = p.archivosSeleccionados ?? [];
    if (!Array.isArray(archivos) || archivos.length > (p.tipo === "carrusel" ? 10 : 1)) return null;
    const metadatos = archivos.map((archivo) => {
      if (!archivo || typeof archivo !== "object" || Array.isArray(archivo)) return null;
      const nombre = textoServicio(archivo.nombre, 180);
      const tipo = textoServicio(archivo.tipo, 80);
      const limite = p.tipo === "reel" ? 150 * 1024 * 1024 : 20 * 1024 * 1024;
      if (!nombre || tipo === null || !Number.isSafeInteger(archivo.tamano) ||
          archivo.tamano <= 0 || archivo.tamano > limite) return null;
      if (p.tipo === "reel" && tipo !== "video/mp4" && !/\.mp4$/i.test(nombre)) return null;
      if (p.tipo !== "reel" && !["image/jpeg", "image/png", "image/webp", ""].includes(tipo) &&
          !/\.(jpe?g|png|webp)$/i.test(nombre)) return null;
      return { nombre, tipo, tamano: archivo.tamano, estado: "pendiente_subida" };
    });
    if (metadatos.some((archivo) => !archivo)) return null;
    return {
      id: p.id, tipo: p.tipo, formato: p.formato,
      diaPreferido: p.dia, horaLocalPreferida: p.hora,
      descripcion, ctaInstagram, ctaFacebook, urlFacebook, hashtags,
      archivos: metadatos,
      fechaHoraDefinitiva: null,
      estado: "pendiente_preparacion",
    };
  });
  if (publicaciones.some((publicacion) => !publicacion)) {
    return { error: "Revisá los datos de las cuatro publicaciones." };
  }
  return { configuracion: {
    redes: [...redes], zonaHoraria: datos.zonaHoraria, negocio, publicaciones,
  } };
}

// Para abrir pedidos públicos se requiere Turnstile; Admin puede probar
// la escritura con su sesión existente. Esta verificación NO confirma pagos.
// Limitadores nativos de Cloudflare Workers. Protegen las rutas de servicios;
// los pedidos de la tienda y el calendario automatico no utilizan estos bindings.
function limitadoresServicioPreparados(env) {
  return [
    env?.SERVICIO_LIMITE_PEDIDOS,
    env?.SERVICIO_LIMITE_CONSULTAS,
    env?.SERVICIO_LIMITE_COMPROBANTES,
  ].every((binding) => typeof binding?.limit === "function");
}

async function comprobarLimiteServicio(request, env, nombreBinding, grupoAcotado = "") {
  const limitador = env?.[nombreBinding];
  if (typeof limitador?.limit !== "function") {
    return respuestaServicio({ ok: false, error: "La proteccion de solicitudes aun no esta configurada." }, 503);
  }
  // Creacion publica sin sesion: usar IP de Cloudflare (no X-Forwarded-For).
  // El limite es aproximado; usuarios que comparten IP pueden verse afectados.
  const ip = request.headers.get("CF-Connecting-IP")?.trim();
  if (!ip) {
    return respuestaServicio({ ok: false, error: "No se pudo verificar el origen de la solicitud." }, 403);
  }
  const clave = crypto.createHash("sha256").update(grupoAcotado ? `${ip}:${grupoAcotado}` : ip).digest("hex");
  try {
    const resultado = await limitador.limit({ key: clave });
    if (!resultado?.success) {
      return respuestaServicio({
        ok: false,
        error: "Se realizaron demasiadas solicitudes. Espera un minuto e intenta nuevamente.",
      }, 429);
    }
    return null;
  } catch (error) {
    console.error("Error del limitador de servicios:", error);
    return respuestaServicio({ ok: false, error: "La proteccion de solicitudes no esta disponible." }, 503);
  }
}

async function validarAccesoCrearServicio(request, env, datos) {
  if (adminAutorizadoWorker(request, env)) return { ok: true };
  if (!env.SERVICIO_TURNSTILE_SECRET) {
    return { error: "Aún no está habilitada la validación de pedidos públicos.", estado: 503 };
  }
  const token = textoServicio(datos.turnstileToken, 2048);
  if (!token) return { error: "Completá la verificación de seguridad.", estado: 403 };
  try {
    const formulario = new URLSearchParams({
      secret: env.SERVICIO_TURNSTILE_SECRET,
      response: token,
    });
    const ip = request.headers.get("CF-Connecting-IP");
    if (ip) formulario.set("remoteip", ip);
    const respuesta = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST", body: formulario,
    });
    if (!respuesta.ok) return { error: "No se pudo completar la verificación de seguridad.", estado: 503 };
    const verificacion = await respuesta.json();
    // El token debe haberse emitido para el mismo dominio de este sitio.
    const hostnameEsperado = new URL(request.url).hostname.toLowerCase();
    const hostnameVerificado = String(verificacion.hostname ?? "").toLowerCase();
    return verificacion.success && hostnameVerificado === hostnameEsperado
      ? { ok: true }
      : { error: "Verificación de seguridad inválida, vencida o de otro dominio.", estado: 403 };
  } catch {
    return { error: "No se pudo comprobar la verificación de seguridad.", estado: 503 };
  }
}

// El cliente ya pasó Turnstile en el registro y verificó el correo por OTP.
// Un flag independiente sigue protegiendo la habilitación de las pruebas.
function preparacionPruebaDisponible(request, env, protegida = false) {
  if (String(env?.SERVICIO_PRUEBAS_PREPARACION_HABILITADA ?? "").toLowerCase() !== "true") return false;
  if (protegida && !limitadoresServicioPreparados(env)) return false;
  return true;
}

async function apiPruebaPublicaciones(request, env, ruta) {
  const esEstado = ruta === "/api/servicios/publicaciones/prueba/estado";
  if (request.method !== (esEstado ? "GET" : "POST")) {
    return respuestaServicio({ ok: false, error: "Método no permitido." }, 405);
  }
  if (esEstado) {
    const pedidoId = new URL(request.url).searchParams.get("pedidoId");
    if (!pedidoServicioIdValido(pedidoId)) return respuestaServicio({ ok: false, error: "Pedido inválido." }, 400);
    const exceso = await comprobarLimiteServicio(request, env, "SERVICIO_LIMITE_CONSULTAS");
    if (exceso) return exceso;
    try {
      return await conColeccionServicios(env, async coleccion => {
        const pedido = await coleccion.findOne({ pedidoId, tipo: "publicaciones", modalidadContratacion: "prueba_gratuita" });
        if (!pedido || !clienteServicioAutorizado(request, pedido)) return respuestaServicio({ ok: false, error: "Pedido no encontrado o acceso no autorizado." }, 404);
        return respuestaServicio({ ok: true, pedidoId, modalidad: "prueba_gratuita", moneda: pedido.moneda,
          precio: 0, precioRenovacion: pedido.precioRenovacion, metodoPago: "ninguno",
          estado: pedido.estado, estadoServicio: pedido.estadoServicio, estadoContenidos: pedido.estadoContenidos,
          prueba: { estado: pedido.prueba?.estado || "pendiente_activacion", inicio: pedido.prueba?.inicio || null,
            fin: pedido.prueba?.fin || null }, pagoHabilitado: false });
      });
    } catch {
      return respuestaServicio({ ok: false, error: "No se pudo consultar la prueba." }, 503);
    }
  }

  if (!preparacionPruebaDisponible(request, env, true)) {
    return respuestaServicio({ ok: false, error: "La preparación de pruebas todavía no está habilitada." }, 503);
  }
  // Protección por IP adicional a la sesión verificada del titular.
  const exceso = await comprobarLimiteServicio(request, env, "SERVICIO_LIMITE_PEDIDOS");
  if (exceso) return exceso;
  if (request.headers.get("origin") !== new URL(request.url).origin) {
    return respuestaServicio({ ok: false, error: "Origen no autorizado." }, 403);
  }
  const lectura = await leerJsonServicio(request);
  if (lectura.error) return respuestaServicio({ ok: false, error: lectura.error }, lectura.estado);
  const datos = lectura.datos;
  if (!["ARS", "USD"].includes(datos.moneda)) {
    return respuestaServicio({ ok: false, error: "Moneda no admitida." }, 400);
  }
  // La segunda verificación de Cloudflare no es necesaria: la prueba solo
  // puede crearla una cuenta con correo validado y sesión activa.
  let usuario = null;
  try { usuario = await obtenerClienteRegistrado(request, env); }
  catch { return respuestaServicio({ ok: false, error: "No se pudo verificar la sesión de cliente." }, 503); }
  if (!usuario?.id) return respuestaServicio({ ok: false, error: "Iniciá sesión con tu correo confirmado." }, 401);
  const validacion = validarConfiguracionServicio(datos);
  if (validacion.error) return respuestaServicio({ ok: false, error: validacion.error }, 400);
  if (usuario.email !== validacion.configuracion.negocio.email.toLowerCase()) {
    return respuestaServicio({ ok: false, error: "Usá el correo verificado de tu cuenta para iniciar la prueba." }, 400);
  }

  let mongo, reservado = false;
  const pedidoId = `SER-${crypto.randomUUID()}`;
  const fecha = new Date();
  // Una sola prueba por cuenta con correo verificado.
  const identidad = `cuenta:${usuario.id}`;
  try {
    sincronizarEntorno(env);
    const { MongoClient } = await import("mongodb");
    mongo = new MongoClient(env.MONGODB_URI);
    await mongo.connect();
    const db = mongo.db("andres_imprimibles");
    const reservas = db.collection("clientes_pruebas_reservas");
    const cuenta = await db.collection("clientes_usuarios").findOne({ _id: usuario.id },
      { projection: { perfil: 1, emailVerificado: 1 } });
    if (cuenta?.emailVerificado !== true || !cuenta?.perfil?.emprendimiento) {
      return respuestaServicio({ ok: false, error: "Completá tu registro antes de programar la prueba." }, 403);
    }
    // Los datos personales no pueden ser sustituidos por el formulario enviado.
    validacion.configuracion.negocio = {
      ...validacion.configuracion.negocio,
      nombre: cuenta.perfil.emprendimiento,
      contacto: cuenta.perfil.nombre,
      email: usuario.email,
      whatsapp: cuenta.perfil.whatsapp,
      url: cuenta.perfil.web || "",
    };
    try {
      await reservas.insertOne({ _id: identidad, pedidoId, creadoEn: fecha, emailVerificado: true });
      reservado = true;
    } catch (error) {
      if (error?.code === 11000) return respuestaServicio({ ok: false,
        error: "Ya tenés una prueba asociada a esta cuenta. Revisá tu panel privado." }, 409);
      throw error;
    }
    const tokenAcceso = crypto.randomBytes(32).toString("hex");
    const precioRenovacion = PRECIOS_PUBLICACIONES[datos.moneda][validacion.configuracion.redes.length];
    await db.collection("pedidos_servicios").insertOne({
      pedidoId, tokenAccesoHash: crypto.createHash("sha256").update(tokenAcceso).digest("hex"),
      tipo: "publicaciones", planId: PLAN_PUBLICACIONES.id, nombrePlan: PLAN_PUBLICACIONES.nombre,
      contenidos: PLAN_PUBLICACIONES.contenidos, duracionDias: PLAN_PUBLICACIONES.duracionDias,
      modalidadContratacion: "prueba_gratuita", moneda: datos.moneda, precio: 0, precioRenovacion,
      metodoPago: "ninguno", cantidadPublicaciones: 4 * validacion.configuracion.redes.length,
      ...validacion.configuracion,
      clienteUsuarioId: usuario.id, clienteVinculadoEn: fecha,
      accesoOrigen: "cuenta_verificada",
      modalidadCalendario: "periodo_flexible_7_dias_consecutivos",
      criterioInicio: "pendiente_de_activacion_y_autorizacion_explicita",
      fechaInicioServicio: null, fechaFinServicio: null,
      estado: "prueba_en_preparacion", estadoPago: "no_requerido",
      estadoCuentas: "pendiente_vinculacion", estadoContenidos: "pendiente_carga", estadoServicio: "sin_activar",
      prueba: { estado: "pendiente_activacion", inicio: null, fin: null, recordatorioEn: null },
      archivosSubidos: false, comprobante: null, paypalOrderId: null, paypalCaptureId: null,
      creadoEn: fecha, actualizadoEn: fecha, pagadoEn: null, activadoEn: null,
      historialEstados: [{ estado: "prueba_en_preparacion", fecha }],
    });
    return respuestaServicio({ ok: true, pedidoId, tokenAcceso, modalidad: "prueba_gratuita",
      moneda: datos.moneda, precio: 0, precioRenovacion, metodoPago: "ninguno",
      estado: "prueba_en_preparacion", estadoServicio: "sin_activar",
      prueba: { estado: "pendiente_activacion", inicio: null, fin: null },
      pagoHabilitado: false, cuentaVinculada: true }, 201);
  } catch (error) {
    // Si Mongo falla al crear la orden, no impedir reintentos con una reserva huérfana.
    if (reservado && mongo) await mongo.db("andres_imprimibles").collection("clientes_pruebas_reservas")
      .deleteOne({ _id: identidad, pedidoId }).catch(() => {});
    console.error("Error preparando prueba gratuita:", error?.message || "error interno");
    return respuestaServicio({ ok: false, error: "No se pudo preparar el pedido gratuito." }, 503);
  } finally {
    if (mongo) await mongo.close().catch(() => {});
  }
}

async function apiPedidosPublicaciones(request, env, ruta) {
  // El Site Key es público y puede viajar en la respuesta del plan.
  // La Secret Key nunca se devuelve al navegador.
  const turnstileSiteKey = String(env?.SERVICIO_TURNSTILE_SITE_KEY ?? "").trim();
  const turnstilePreparado = Boolean(turnstileSiteKey && env?.SERVICIO_TURNSTILE_SECRET);
  const proteccionesPreparadas = limitadoresServicioPreparados(env);
  const transferenciaPreparada = transferenciasServiciosHabilitadas(env) &&
    Boolean(cuentaTransferenciaServicio(env)) && Boolean(bucketComprobantesServicio(env));
  if (ruta === "/api/servicios/publicaciones/plan") {
    if (request.method !== "GET") return respuestaServicio({ ok: false, error: "Método no permitido." }, 405);
    return respuestaServicio({
      ok: true, plan: PLAN_PUBLICACIONES,
      precios: PRECIOS_PUBLICACIONES,
      mediosPago: { ARS: "transferencia", USD: "paypal" },
      turnstileSiteKey: turnstileSiteKey,
      proteccionesPreparadas,
      pedidosHabilitados: String(env?.SERVICIO_PEDIDOS_HABILITADOS ?? "").toLowerCase() === "true" &&
        turnstilePreparado && transferenciaPreparada && proteccionesPreparadas,
      transferenciasHabilitadas: transferenciaPreparada && proteccionesPreparadas,
      cobrosHabilitados: false,
      pruebasDisponibles: preparacionPruebaDisponible(request, env, true),
      pruebaModoPrivado: false,
    });
  }
  if (request.method !== "POST") {
    return respuestaServicio({ ok: false, error: "Método no permitido." }, 405);
  }
  if (String(env?.SERVICIO_PEDIDOS_HABILITADOS ?? "").toLowerCase() !== "true" ||
      !turnstilePreparado || !transferenciaPreparada || !proteccionesPreparadas) {
    return respuestaServicio({ ok: false, error: "La contratación de publicaciones aún no está habilitada." }, 503);
  }
  const exceso = await comprobarLimiteServicio(request, env, "SERVICIO_LIMITE_PEDIDOS");
  if (exceso) return exceso;
  const lectura = await leerJsonServicio(request);
  if (lectura.error) return respuestaServicio({ ok: false, error: lectura.error }, lectura.estado);
  const datos = lectura.datos;
  // La contratacion inicial es solo por transferencia ARS; PayPal aun no esta integrado.
  if (datos.moneda !== "ARS") {
    return respuestaServicio({ ok: false, error: "Por ahora solo se admiten contrataciones en ARS." }, 400);
  }
  const validacion = validarConfiguracionServicio(datos);
  if (validacion.error) return respuestaServicio({ ok: false, error: validacion.error }, 400);
  const acceso = await validarAccesoCrearServicio(request, env, datos);
  if (acceso.error) return respuestaServicio({ ok: false, error: acceso.error }, acceso.estado);

  const precio = PRECIOS_PUBLICACIONES[datos.moneda][validacion.configuracion.redes.length];
  const metodoPago = datos.moneda === "ARS" ? "transferencia" : "paypal";
  const estado = datos.moneda === "ARS" ? "pendiente_comprobante" : "pendiente_paypal";
  let cliente;
  try {
    sincronizarEntorno(env);
    const { MongoClient } = await import("mongodb");
    cliente = new MongoClient(env.MONGODB_URI);
    await cliente.connect();
    const coleccion = cliente.db("andres_imprimibles").collection("pedidos_servicios");
    const fecha = new Date();
    const pedidoId = `SER-${crypto.randomUUID()}`;
    const tokenAcceso = crypto.randomBytes(32).toString("hex");
    const tokenAccesoHash = crypto.createHash("sha256").update(tokenAcceso).digest("hex");
    await coleccion.insertOne({
      pedidoId, tokenAccesoHash, tipo: "publicaciones", planId: PLAN_PUBLICACIONES.id,
      nombrePlan: PLAN_PUBLICACIONES.nombre, contenidos: PLAN_PUBLICACIONES.contenidos,
      duracionDias: PLAN_PUBLICACIONES.duracionDias,
      moneda: datos.moneda, precio, metodoPago,
      cantidadPublicaciones: PLAN_PUBLICACIONES.contenidos * validacion.configuracion.redes.length,
      ...validacion.configuracion,
      modalidadCalendario: "periodo_flexible_7_dias_consecutivos",
      criterioInicio: "primera_publicacion_confirmada_tras_pago_cuentas_y_aprobacion",
      fechaInicioServicio: null, fechaFinServicio: null,
      estado, estadoPago: "pendiente", estadoCuentas: "pendiente_vinculacion",
      estadoContenidos: "pendiente_carga", estadoServicio: "sin_activar",
      archivosSubidos: false, comprobante: null,
      paypalOrderId: null, paypalCaptureId: null,
      creadoEn: fecha, actualizadoEn: fecha, pagadoEn: null, activadoEn: null,
      historialEstados: [{ estado, fecha }],
    });
    return respuestaServicio({
      ok: true, pedidoId, tokenAcceso, planId: PLAN_PUBLICACIONES.id,
      moneda: datos.moneda, precio, metodoPago, estado,
      pagoHabilitado: false,
    }, 201);
  } catch (error) {
    console.error("Error guardando pedido de publicaciones en MongoDB:", error);
    return respuestaServicio({ ok: false, error: "No se pudo guardar el pedido de publicaciones." }, 500);
  } finally {
    if (cliente) await cliente.close().catch((error) => console.error("MongoDB close:", error));
  }
}

// =========================================================
// TRANSFERENCIAS DE PUBLICACIONES · ETAPA 2
// Independientes de "pedidos" (tienda). NO procesa cobros automáticos.
// Comprobantes únicamente en un bucket R2 PRIVADO.
// =========================================================
const ESTADOS_TRANSFERENCIA_SERVICIO = Object.freeze({
  ESPERANDO: "pendiente_comprobante",
  COMPROBANTE: "verificando_comprobante",
  VERIFICANDO: "verificando_pago",
  COMPLETANDO: "completando_operacion",
});

function transferenciasServiciosHabilitadas(env) {
  return String(env?.SERVICIO_TRANSFERENCIAS_HABILITADAS ?? "").toLowerCase() === "true";
}

function cuentaTransferenciaServicio(env) {
  const titular = String(env?.SERVICIO_TRANSFERENCIA_TITULAR ?? "").trim();
  const entidad = String(env?.SERVICIO_TRANSFERENCIA_ENTIDAD ?? "").trim();
  const alias = String(env?.SERVICIO_TRANSFERENCIA_ALIAS ?? "").trim();
  const cbuCvu = String(env?.SERVICIO_TRANSFERENCIA_CBU_CVU ?? "").replace(/\s/g, "");
  if (!titular || titular.length > 120 || !entidad || entidad.length > 80 ||
      !/^[\w.-]{6,60}$/.test(alias) || !/^\d{22}$/.test(cbuCvu)) return null;
  return { titular, entidad, alias, cbuCvu };
}

function pedidoServicioIdValido(valor) {
  return typeof valor === "string" && /^SER-[a-f0-9-]{36}$/i.test(valor);
}

function tokenClienteServicio(request) {
  const autorizacion = request.headers.get("authorization") || "";
  const match = /^Bearer ([a-f0-9]{64})$/i.exec(autorizacion);
  return match?.[1] || null;
}

function clienteServicioAutorizado(request, pedido) {
  const token = tokenClienteServicio(request);
  const hashGuardado = pedido?.tokenAccesoHash;
  if (!token || typeof hashGuardado !== "string" || !/^[a-f0-9]{64}$/i.test(hashGuardado)) return false;
  const calculado = crypto.createHash("sha256").update(token).digest("hex");
  return crypto.timingSafeEqual(Buffer.from(calculado, "hex"), Buffer.from(hashGuardado, "hex"));
}

async function conColeccionServicios(env, accion) {
  sincronizarEntorno(env);
  if (!env?.MONGODB_URI) throw new Error("MongoDB no configurado.");
  const { MongoClient } = await import("mongodb");
  const cliente = new MongoClient(env.MONGODB_URI);
  try {
    await cliente.connect();
    return await accion(cliente.db("andres_imprimibles").collection("pedidos_servicios"));
  } finally {
    await cliente.close().catch(() => {});
  }
}

function bucketComprobantesServicio(env) {
  const bucket = env?.SERVICIOS_COMPROBANTES_R2;
  return bucket?.put && bucket?.get ? bucket : null;
}

async function leerArchivoComprobanteServicio(request, maxBytes) {
  const declarado = Number(request.headers.get("content-length") || 0);
  if (declarado > maxBytes) return null;
  if (!request.body) return null;
  const lector = request.body.getReader();
  let total = 0;
  const partes = [];
  while (true) {
    const { done, value } = await lector.read();
    if (done) break;
    total += value.byteLength;
    if (total > maxBytes) { await lector.cancel(); return null; }
    partes.push(value);
  }
  if (total < 100) return null;
  const resultado = new Uint8Array(total);
  let posicion = 0;
  for (const parte of partes) { resultado.set(parte, posicion); posicion += parte.byteLength; }
  return resultado;
}

function tipoComprobanteServicio(bytes) {
  if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) {
    return { tipo: "image/jpeg", extension: "jpg" };
  }
  if ([137, 80, 78, 71, 13, 10, 26, 10].every((b, i) => bytes[i] === b)) {
    return { tipo: "image/png", extension: "png" };
  }
  if (bytes[0] === 37 && bytes[1] === 80 && bytes[2] === 68 && bytes[3] === 70 && bytes[4] === 45) {
    return { tipo: "application/pdf", extension: "pdf" };
  }
  return null;
}

async function apiTransferenciaServicio(request, env, ruta) {
  if (!transferenciasServiciosHabilitadas(env)) {
    return respuestaServicio({ ok: false, error: "Las transferencias de publicaciones aún no están habilitadas." }, 503);
  }
  const cuenta = cuentaTransferenciaServicio(env);
  if (!cuenta) return respuestaServicio({ ok: false, error: "La cuenta bancaria todavía no está configurada." }, 503);

  const subir = ruta.endsWith("/comprobante");
  if (request.method !== (subir ? "POST" : "GET")) {
    return respuestaServicio({ ok: false, error: "Método no permitido." }, 405);
  }
  const pedidoId = new URL(request.url).searchParams.get("pedidoId");
  if (!pedidoServicioIdValido(pedidoId)) return respuestaServicio({ ok: false, error: "Identificador de pedido inválido." }, 400);
  const exceso = await comprobarLimiteServicio(request, env,
    subir ? "SERVICIO_LIMITE_COMPROBANTES" : "SERVICIO_LIMITE_CONSULTAS");
  if (exceso) return exceso;
  try {
    return await conColeccionServicios(env, async (coleccion) => {
      const pedido = await coleccion.findOne({ pedidoId, tipo: "publicaciones", metodoPago: "transferencia", moneda: "ARS" });
      if (!pedido || !clienteServicioAutorizado(request, pedido)) {
        return respuestaServicio({ ok: false, error: "Pedido no encontrado o acceso no autorizado." }, 404);
      }
      if (!subir) {
        return respuestaServicio({
          ok: true, pedidoId, moneda: "ARS", precio: pedido.precio,
          estado: pedido.estado, cuenta,
          comprobanteRecibido: Boolean(pedido.comprobante),
        });
      }
      if (pedido.estado !== ESTADOS_TRANSFERENCIA_SERVICIO.ESPERANDO) {
        return respuestaServicio({ ok: false, error: "Este pedido ya tiene un comprobante o no admite nuevas cargas." }, 409);
      }
      const bucket = bucketComprobantesServicio(env);
      if (!bucket) return respuestaServicio({ ok: false, error: "El almacenamiento privado de comprobantes no está preparado." }, 503);
      if (!/^(image\/jpeg|image\/png|application\/pdf)(?:;|$)/i.test(request.headers.get("content-type") || "")) {
        return respuestaServicio({ ok: false, error: "Adjuntá una imagen JPG/PNG o un PDF." }, 415);
      }
      const bytes = await leerArchivoComprobanteServicio(request, 8 * 1024 * 1024);
      if (!bytes) return respuestaServicio({ ok: false, error: "El comprobante debe ocupar entre 100 bytes y 8 MB." }, 413);
      const formato = tipoComprobanteServicio(bytes);
      if (!formato) return respuestaServicio({ ok: false, error: "El comprobante no es un JPG, PNG o PDF válido." }, 415);
      const fecha = new Date();
      const clave = `comprobantes/publicaciones/${pedidoId}/${crypto.randomUUID()}.${formato.extension}`;
      await bucket.put(clave, bytes, { httpMetadata: { contentType: formato.tipo } });
      try {
        const resultado = await coleccion.updateOne(
          { _id: pedido._id, estado: ESTADOS_TRANSFERENCIA_SERVICIO.ESPERANDO, comprobante: null },
          {
            $set: {
              comprobante: { r2Key: clave, tipo: formato.tipo, tamano: bytes.byteLength, subidoEn: fecha },
              estado: ESTADOS_TRANSFERENCIA_SERVICIO.COMPROBANTE,
              estadoPago: "verificando_comprobante", actualizadoEn: fecha,
            },
            $push: { historialEstados: { estado: ESTADOS_TRANSFERENCIA_SERVICIO.COMPROBANTE, fecha } },
          }
        );
        if (resultado.modifiedCount !== 1) {
          await bucket.delete(clave);
          return respuestaServicio({ ok: false, error: "El pedido cambió de estado. Actualizá la página." }, 409);
        }
      } catch (error) { await bucket.delete(clave).catch(() => {}); throw error; }
      return respuestaServicio({ ok: true, pedidoId, estado: ESTADOS_TRANSFERENCIA_SERVICIO.COMPROBANTE }, 201);
    });
  } catch (error) {
    console.error("Error en transferencia de publicaciones:", error);
    return respuestaServicio({ ok: false, error: "No se pudo procesar la transferencia del servicio." }, 500);
  }
}

async function apiAdminTransferenciasServicio(request, env) {
  if (!adminAutorizadoWorker(request, env)) return respuestaServicio({ ok: false, error: "No autorizado." }, 401);
  const url = new URL(request.url);
  const accion = url.searchParams.get("accion") || "listar";
  if (!((accion === "listar" || accion === "comprobante") && request.method === "GET") &&
      !(accion === "avanzar" && request.method === "POST")) {
    return respuestaServicio({ ok: false, error: "Método o acción no permitidos." }, 405);
  }
  // La sesión admin usa cookies; para mutaciones, exigir mismo origen como defensa CSRF.
  if (accion === "avanzar" && request.headers.get("origin") !== url.origin) {
    return respuestaServicio({ ok: false, error: "Origen no autorizado." }, 403);
  }
  try {
    return await conColeccionServicios(env, async (coleccion) => {
      if (accion === "listar") {
        const pedidos = await coleccion.find({ tipo: "publicaciones", metodoPago: "transferencia", pedidoId: /^SER-/ })
          .sort({ creadoEn: -1 }).limit(100)
          .project({ _id: 0, pedidoId: 1, precio: 1, moneda: 1, estado: 1, creadoEn: 1,
            "negocio.nombre": 1, "negocio.email": 1, comprobante: 1 }).toArray();
        return respuestaServicio({ ok: true, pedidos: pedidos.map((p) => ({
          pedidoId: p.pedidoId, precio: p.precio, moneda: p.moneda, estado: p.estado,
          creadoEn: p.creadoEn, negocio: p.negocio,
          comprobanteRecibido: Boolean(p.comprobante),
        })) });
      }
      let pedidoId;
      if (accion === "comprobante") pedidoId = url.searchParams.get("pedidoId");
      else {
        const lectura = await leerJsonServicio(request);
        if (lectura.error) return respuestaServicio({ ok: false, error: lectura.error }, lectura.estado);
        pedidoId = lectura.datos.pedidoId;
      }
      if (!pedidoServicioIdValido(pedidoId)) return respuestaServicio({ ok: false, error: "Pedido inválido." }, 400);
      const pedido = await coleccion.findOne({ pedidoId, tipo: "publicaciones", metodoPago: "transferencia" });
      if (!pedido) return respuestaServicio({ ok: false, error: "Pedido no encontrado." }, 404);
      if (accion === "comprobante") {
        if (!pedido.comprobante?.r2Key) return respuestaServicio({ ok: false, error: "El pedido no tiene comprobante." }, 404);
        const bucket = bucketComprobantesServicio(env);
        if (!bucket) return respuestaServicio({ ok: false, error: "Bucket privado no disponible." }, 503);
        const objeto = await bucket.get(pedido.comprobante.r2Key);
        if (!objeto) return respuestaServicio({ ok: false, error: "No se encontró el comprobante." }, 404);
        return new Response(objeto.body, { headers: {
          "Content-Type": pedido.comprobante.tipo,
          "Content-Disposition": `inline; filename="comprobante-${pedidoId}.${pedido.comprobante.tipo === "application/pdf" ? "pdf" : pedido.comprobante.tipo === "image/png" ? "png" : "jpg"}"`,
          "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff",
        } });
      }
      let proximo, estadoPago;
      if (pedido.estado === ESTADOS_TRANSFERENCIA_SERVICIO.COMPROBANTE) {
        proximo = ESTADOS_TRANSFERENCIA_SERVICIO.VERIFICANDO;
        estadoPago = "verificando";
      } else if (pedido.estado === ESTADOS_TRANSFERENCIA_SERVICIO.VERIFICANDO) {
        proximo = ESTADOS_TRANSFERENCIA_SERVICIO.COMPLETANDO;
        estadoPago = "confirmado";
      } else {
        return respuestaServicio({ ok: false, error: "Este pedido no admite avanzar de estado." }, 409);
      }
      const fecha = new Date();
      const cambios = { estado: proximo, estadoPago, actualizadoEn: fecha };
      if (proximo === ESTADOS_TRANSFERENCIA_SERVICIO.COMPLETANDO) cambios.pagadoEn = fecha;
      const resultado = await coleccion.updateOne(
        { _id: pedido._id, estado: pedido.estado, "comprobante.r2Key": { $exists: true } },
        { $set: cambios, $push: { historialEstados: { estado: proximo, fecha } } }
      );
      if (resultado.modifiedCount !== 1) {
        return respuestaServicio({ ok: false, error: "El estado cambió. Actualizá el panel." }, 409);
      }
      // Pago confirmado != servicio activado. El contenido requiere aprobación posterior.
      return respuestaServicio({ ok: true, pedidoId, estado: proximo, estadoPago, servicioActivado: false });
    });
  } catch (error) {
    console.error("Error en administración de transferencias de servicios:", error);
    return respuestaServicio({ ok: false, error: "No se pudo completar la operación." }, 500);
  }
}

async function pruebaMongoDB(env) {
  sincronizarEntorno(env);
  if (!env.MONGODB_URI) return Response.json({ ok:false, error:"MONGODB_URI no está configurado" }, { status:500 });
  try {
    const { MongoClient } = await import("mongodb");
    const cliente = new MongoClient(env.MONGODB_URI);
    await cliente.connect();
    await cliente.db("andres_imprimibles").command({ ping:1 });
    await cliente.close();
    return Response.json({ ok:true, mensaje:"Cloudflare conectado correctamente a MongoDB" });
  } catch (error) {
    return Response.json({ ok:false, error:error?.message || "Error conectando con MongoDB" }, { status:500 });
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    // FASE3_RUTAS_ACCESO_ANTES_DEL_ENTORNO
// Registro de clientes de Comunidad Semanal, aislado de Admin y de Mega Bazar.
if (url.pathname.startsWith("/api/servicios/clientes/acceso/")) {
  const exceso = await comprobarLimiteServicio(request, env, "SERVICIO_LIMITE_CONSULTAS");
  if (exceso) return exceso;
  // FASE8: en el despliegue inicial permanece APAGADO.
  if (String(env.SERVICIO_ACCESO_DURABLE_HABILITADO || "").toLowerCase() === "true") {
    if (!env.ACCESO_CLIENTES_DURABLE) {
      return Response.json({ ok: false, error: "Servicio de acceso temporalmente no disponible." }, { status: 503 });
    }
    const ip = request.headers.get("CF-Connecting-IP")?.trim();
    if (!ip) return Response.json({ ok: false, error: "No se pudo validar el origen de la solicitud." }, { status: 403 });
    // No se acepta el valor de IP proporcionado por el navegador.
    const headers = new Headers(request.headers);
    headers.set("x-servicio-ip-verificada", ip);
    const delegado = new Request(request, { headers });
    try {
      const stub = env.ACCESO_CLIENTES_DURABLE.getByName("acceso-clientes-v1");
      return await stub.fetch(delegado);
    } catch (error) {
      console.warn("Fase 8: acceso Durable Object no disponible", String(error?.name || "Error").slice(0, 80));
      // Nunca reintentar automáticamente OTP: podría haberse enviado el correo.
      return Response.json({ ok: false, error: "Servicio de acceso temporalmente no disponible." }, { status: 503 });
    }
  }
  return ejecutarAccesoClientes(request, env);
}
// Perfil y conexión de Facebook desde el panel del titular, sin tocar el cron.
if (url.pathname === "/api/servicios/clientes/panel/detalles" ||
    url.pathname === "/api/servicios/clientes/panel/detalles/desconectar-facebook") {
  const exceso = await comprobarLimiteServicio(request, env, "SERVICIO_LIMITE_CONSULTAS");
  if (exceso) return exceso;
  return ejecutarDetallesPanel(request, env);
}
// Panel de usuarios registrados: sesion propia + comprobacion privada al vincular pedidos.
if (url.pathname === "/api/servicios/clientes/panel" ||
    url.pathname === "/api/servicios/clientes/panel/vincular" ||
    url.pathname === "/api/servicios/clientes/panel/recuperar-acceso") {
  const exceso = await comprobarLimiteServicio(request, env, "SERVICIO_LIMITE_CONSULTAS");
  if (exceso) return exceso;
  return ejecutarPanelClientes(request, env);
}
    // FIN_FASE3_RUTAS_ACCESO
    // FASE5_CPU_IG_20261024: la conexión de Meta no depende de process.env.
// Meta de clientes: acceso Bearer por pedido y retorno OAuth separado de Admin.
if (url.pathname.startsWith("/api/servicios/meta/pedidos/")) {
  if (url.pathname !== "/api/servicios/meta/pedidos/callback" &&
      url.pathname !== "/api/servicios/meta/pedidos/instagram/callback") {
    const exceso = await comprobarLimiteServicio(request, env, "SERVICIO_LIMITE_CONSULTAS");
    if (exceso) return exceso;
  }
  return ejecutarConexionMetaPedido(request, env);
}

    // FASE6_AUTORIZACION_DEMANDA_20261024: solicitudes usan env directamente; no necesitan process.env.
// Confirmación voluntaria e independiente de la revisión técnica.
// No activa la prueba ni modifica el cron de la tienda.
if (url.pathname.startsWith("/api/servicios/publicaciones/solicitud/")) {
  const exceso = await comprobarLimiteServicio(request, env, request.method === "GET"
    ? "SERVICIO_LIMITE_CONSULTAS" : "SERVICIO_LIMITE_PEDIDOS");
  if (exceso) return exceso;
  return ejecutarSolicitudProgramacion(request, env);
}

    sincronizarEntorno(env);
    // Retiramos rutas de pago ficticio: no se crean ni aprueban más ensayos.
    if (url.pathname.startsWith("/api/servicios/publicaciones/transferencia-ensayo") ||
        url.pathname.startsWith("/api/admin/servicios/publicaciones/transferencias-ensayo")) {
      return Response.json({ok:false,error:"Los ensayos de pago dejaron de estar disponibles."},{status:410});
    }

    
if (url.pathname === "/api/diagnostico-facebook") {
  if (!adminAutorizadoWorker(request, env)) {
    return Response.json(
      { error: "No autorizado" },
      { status: 401 }
    );
  }

  return Response.json({
    pageIdEnCloudflare:
      Boolean(String(env.FACEBOOK_PAGE_ID || "").trim()),

    tokenEnCloudflare:
      Boolean(String(env.FACEBOOK_PAGE_ACCESS_TOKEN || "").trim()),

    pageIdEnProceso:
      Boolean(String(process.env.FACEBOOK_PAGE_ID || "").trim()),

    tokenEnProceso:
      Boolean(String(process.env.FACEBOOK_PAGE_ACCESS_TOKEN || "").trim())
  });
}
    

    if (url.pathname === "/api/prueba-mongodb") return pruebaMongoDB(env);

if (url.pathname === "/api/admin/login") {
  try {
    return await ejecutarHandlerGenerico(
      request,
      env,
      handlerAdminLogin
    );
  } catch (error) {
    return Response.json(
      { ok: false, error: error?.message || "Error en login admin" },
      { status: 500 }
    );
  }
}

// Diagnóstico de solo lectura, disponible exclusivamente para una sesión Admin.
// No se muestran los secretos, sus longitudes ni el remitente configurado.
if (url.pathname === "/api/admin/servicios/clientes/diagnostico") {
  if (request.method !== "GET") {
    return respuestaServicio({ ok: false, error: "Método no permitido." }, 405);
  }
  if (!adminAutorizadoWorker(request, env)) {
    return respuestaServicio({ ok: false, error: "No autorizado." }, 401);
  }
  return respuestaServicio(diagnosticarConfiguracionClientes(env));
}

// Renovaciones bancarias reales: separadas del ensayo privado de $0.
if (url.pathname.startsWith("/api/servicios/publicaciones/renovacion-contenidos/")) {
  // Archivos independientes del cron; el backend verifica titularidad, pago y activación.
  return ejecutarContenidosRenovacionReal(request,env);
}

// FASE10: PayPal usa el mismo sistema de semanas, sin tocar cron de tienda ni clientes.
if (url.pathname.startsWith("/api/servicios/publicaciones/renovacion-paypal")) {
  if (url.pathname !== "/api/servicios/publicaciones/renovacion-paypal/webhook") {
    const exceso = await comprobarLimiteServicio(request, env, request.method === "POST"
      ? "SERVICIO_LIMITE_PEDIDOS" : "SERVICIO_LIMITE_CONSULTAS");
    if (exceso) return exceso;
  }
  return ejecutarRenovacionPaypal(request, env);
}
if (url.pathname === "/api/servicios/publicaciones/renovacion-transferencia" ||
    url.pathname === "/api/servicios/publicaciones/renovacion-transferencia/crear" ||
    url.pathname === "/api/servicios/publicaciones/renovacion-transferencia/comprobante") {
  const exceso = await comprobarLimiteServicio(request, env,
    url.pathname.endsWith("/comprobante") ? "SERVICIO_LIMITE_COMPROBANTES" :
    request.method === "POST" ? "SERVICIO_LIMITE_PEDIDOS" : "SERVICIO_LIMITE_CONSULTAS");
  if (exceso) return exceso;
  return ejecutarRenovacionTransferencia(request, env);
}
if (url.pathname === "/api/admin/servicios/publicaciones/renovaciones-transferencia") {
  return ejecutarAdminRenovacionesTransferencia(request, env, adminAutorizadoWorker(request, env));
}

if (url.pathname === "/api/servicios/publicaciones/transferencia" ||
    url.pathname === "/api/servicios/publicaciones/transferencia/comprobante") {
  return apiTransferenciaServicio(request, env, url.pathname);
}
if (url.pathname === "/api/admin/servicios/meta/iniciar" ||
    url.pathname === "/api/servicios/meta/callback") {
  return ejecutarPruebaConexionMeta(request, env, adminAutorizadoWorker(request, env));
}

// Multimedia del servicio: colección y bucket privados, sin vínculos con Mega Bazar.
if (url.pathname.startsWith("/api/servicios/publicaciones/archivos/")) {
  // Inicio: cupo acotado por contenido y posición, sin quitar el límite por IP.
  // Las partes y finalización mantienen la protección del pedido en MongoDB.
  const accion = url.pathname.slice("/api/servicios/publicaciones/archivos/".length);
  if (!["parte", "finalizar", "cancelar"].includes(accion)) {
    let grupo = "";
    if (accion === "estado") grupo = "archivos-estado";
    if (accion === "iniciar" && request.method === "POST") {
      const contenido = url.searchParams.get("contenido") || "";
      const pos = url.searchParams.get("pos") || "";
      if (/^contenido-[1-4]$/.test(contenido) && /^[0-9]$/.test(pos)) {
        grupo = `archivos-iniciar:${contenido}:${pos}`;
      }
    }
    const exceso = await comprobarLimiteServicio(request, env, "SERVICIO_LIMITE_CONSULTAS", grupo);
    if (exceso) return exceso;
  }
  return ejecutarArchivosPedido(request, env);
}
if (url.pathname === "/api/admin/servicios/publicaciones/programacion") {
  return ejecutarAdminProgramacion(request, env, adminAutorizadoWorker(request, env));
}

if (url.pathname === "/api/admin/servicios/publicaciones/archivos") {
  return ejecutarAdminArchivosPedido(request, env, adminAutorizadoWorker(request, env));
}

// Ensayo administrativo GET, sin escrituras ni publicaciones en Meta.
// NO altera cron de Mega Bazar, pedidos ni reservas existentes.
if (url.pathname === "/api/admin/servicios/publicaciones/activacion-simulada") {
  return ejecutarActivacionSimulada(request, env, adminAutorizadoWorker(request, env));
}

// Publicación piloto manual aislada; apagada por defecto. Nunca entra en scheduled().
if (url.pathname.startsWith("/api/servicios/piloto-meta/media/")) {
  return ejecutarImagenPiloto(request, env);
}
if (url.pathname.startsWith("/api/admin/servicios/publicaciones/piloto-meta")) {
  const exceso = await comprobarLimiteServicio(request, env, request.method === "POST"
    ? "SERVICIO_LIMITE_PEDIDOS" : "SERVICIO_LIMITE_CONSULTAS");
  if (exceso) return exceso;
  return ejecutarPublicacionPiloto(request, env, adminAutorizadoWorker(request, env));
}

// Ensayo de pago a $0 y correos aislado de cobros y publicaciones reales.
if (url.pathname === "/api/servicios/publicaciones/transferencia-ensayo" ||
    url.pathname.startsWith("/api/servicios/publicaciones/transferencia-ensayo/")) {
  const esMedioEnsayo = url.pathname === "/api/servicios/publicaciones/transferencia-ensayo/medio";
  let grupoEnsayo = "";
  if (request.method === "POST") {
    if (esMedioEnsayo) {
      // Hasta 4 contenidos y 10 posiciones por contenido. Nunca incluir el ID
      // de pedido en la clave: un atacante podría rotarlo para evadir el límite.
      const contenido = url.searchParams.get("contenido") || "";
      const posicionTexto = url.searchParams.get("pos") || "";
      if (/^contenido-[1-4]$/.test(contenido) && /^(?:[0-9])$/.test(posicionTexto)) {
        grupoEnsayo = `ensayo-medio:${contenido}:${posicionTexto}`;
      }
    } else if (url.pathname.endsWith("/configurar")) grupoEnsayo = "ensayo-configurar";
    else if (url.pathname.endsWith("/enviar")) grupoEnsayo = "ensayo-enviar";
  }
  const exceso = await comprobarLimiteServicio(request, env,
    esMedioEnsayo ? "SERVICIO_LIMITE_COMPROBANTES" :
      request.method === "POST" ? "SERVICIO_LIMITE_PEDIDOS" : "SERVICIO_LIMITE_CONSULTAS",
    grupoEnsayo);
  if (exceso) return exceso;
  return ejecutarTransferenciaEnsayo(request, env);
}
if (url.pathname === "/api/admin/servicios/publicaciones/transferencias-ensayo") {
  return ejecutarAdminTransferenciaEnsayo(request, env, adminAutorizadoWorker(request, env));
}

if (url.pathname === "/api/admin/servicios/transferencias") {
  return apiAdminTransferenciasServicio(request, env);
}

// Simulación bajo sesión de cliente o Bearer del pedido. Solo lectura;
// no llama a Meta ni modifica la ejecución scheduled() de Mega Bazar.
if (url.pathname === "/api/servicios/publicaciones/calendario/simulacion") {
  const exceso = await comprobarLimiteServicio(request, env, "SERVICIO_LIMITE_CONSULTAS");
  if (exceso) return exceso;
  return ejecutarSimulacionCalendario(request, env);
}

// Ensayo aislado y SOLO LECTURA. No llega a ejecutarCronRedes ni a Meta.
if (url.pathname === "/api/servicios/publicaciones/calendario/ensayo") {
  const exceso = await comprobarLimiteServicio(request, env, "SERVICIO_LIMITE_CONSULTAS");
  if (exceso) return exceso;
  return ejecutarEnsayoCalendario(request, env);
}

// Reserva atómica de ocho eventos bloqueados; sin ejecución, sin publicar.
// Aislada de scheduled() y de la automatización de Mega Bazar.
if (url.pathname === "/api/servicios/publicaciones/calendario/reservar") {
  const exceso = await comprobarLimiteServicio(request, env, "SERVICIO_LIMITE_PEDIDOS");
  if (exceso) return exceso;
  return ejecutarReservaCalendario(request, env);
}

// Guarda solamente una propuesta no ejecutable, después de verificar la
// titularidad del cliente. No toca el cron ni el estado de la prueba.
if (url.pathname === "/api/servicios/publicaciones/calendario/preparar") {
  const exceso = await comprobarLimiteServicio(request, env, "SERVICIO_LIMITE_PEDIDOS");
  if (exceso) return exceso;
  return ejecutarPreparacionCalendario(request, env);
}

if (url.pathname === "/api/servicios/publicaciones/prueba" ||
    url.pathname === "/api/servicios/publicaciones/prueba/estado") {
  return apiPruebaPublicaciones(request, env, url.pathname);
}

if (
  url.pathname === "/api/servicios/publicaciones/plan" ||
  url.pathname === "/api/servicios/publicaciones/pedidos"
) {
  return apiPedidosPublicaciones(request, env, url.pathname);
}

if (url.pathname === "/api/visitas") {
  try {
    return await ejecutarHandlerGenerico(
      request,
      env,
      handlerVisitas
    );
  } catch (error) {
    return Response.json(
      {
        ok: false,
        error: error?.message || "Error en API de visitas",
      },
      { status: 500 }
    );
  }
}

    if (url.pathname.startsWith("/api/servicios/publicaciones/media/")) {
      return servirMedioCliente(request, env);
    }
    if (url.pathname.startsWith("/api/")) {
  return Response.json(
    {
      ok: false,
      error: `API no migrada a Cloudflare: ${url.pathname}`
    },
    { status: 404 }
  );
    }

    return env.ASSETS.fetch(request);
  },

  async scheduled(controller, env, ctx) {
    ctx.waitUntil(ejecutarCronClientes(env).catch(error => {
      console.error("Cron clientes:", error?.message || "ERROR");
      throw error;
    }));
  }
};

function obtenerCookiesWorker(request) {
  const cookies = {};
  const header =
    request.headers.get("cookie") || "";

  header.split(";").forEach((cookie) => {
    const [nombre, ...valor] =
      cookie.trim().split("=");

    if (nombre) {
      cookies[nombre] =
        decodeURIComponent(
          valor.join("=")
        );
    }
  });

  return cookies;
}

function adminAutorizadoWorker(
  request,
  env
) {
  const adminPassword =
    env.ADMIN_PASSWORD;

  if (!adminPassword) {
    return false;
  }

  const tokenEsperado = crypto
    .createHmac(
      "sha256",
      String(adminPassword)
    )
    .update(
      "andres-imprimibles-admin"
    )
    .digest("hex");

  const token =
    obtenerCookiesWorker(request)
      .admin_token;

  if (!token) {
    return false;
  }

  const a = Buffer.from(token);
  const b = Buffer.from(
    tokenEsperado
  );

  if (a.length !== b.length) {
    return false;
  }

  return crypto.timingSafeEqual(
    a,
    b
  );
}
