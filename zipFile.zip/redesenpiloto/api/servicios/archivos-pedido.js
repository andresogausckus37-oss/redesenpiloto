// Servicio independiente: archivos multimedia privados por pedido. Nunca publica en Meta.
// Los archivos se suben en partes a R2 y se referencian desde MongoDB.
import crypto from "node:crypto";
import { MongoClient } from "mongodb";
import { obtenerClienteRegistrado } from "./clientes-acceso.js";

const DB = "andres_imprimibles";
const PART_SIZE = 8 * 1024 * 1024;
const MAX_IMAGE = 20 * 1024 * 1024;
const MAX_VIDEO = 150 * 1024 * 1024;
const VENCE_MS = 24 * 60 * 60 * 1000;
const RUTA = "/api/servicios/publicaciones/archivos";
const RUTA_ADMIN = "/api/admin/servicios/publicaciones/archivos";
const VALID_ID = /^SER-[0-9a-f-]{36}$/i;
const VALID_TOKEN = /^[0-9a-f]{64}$/i;
const TIPOS = new Set(["image/jpeg", "image/png", "image/webp", "video/mp4"]);

function json(data, status = 200) {
  return Response.json(data, { status, headers: { "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff" } });
}
function fallo(message, status = 400) { return json({ ok: false, error: message }, status); }
// DIAGNOSTICO_SUBIDA_503_V1: nunca exponer mensajes de excepciones, tokens ni rutas privadas.
function errorSeguro(err, accion = "SOLICITUD") {
  if (err?.status && err?.publico) return fallo(err.publico, err.status);
  const permitido = new Set(["R2_CREAR", "R2_PARTE", "R2_COMPLETAR", "R2_VERIFICAR",
    "MONGODB_CONEXION", "INICIAR", "PARTE", "FINALIZAR", "ESTADO", "CANCELAR", "ELIMINAR"]);
  const fase = permitido.has(err?.fase) ? err.fase : permitido.has(accion) ? accion : "SOLICITUD";
  console.error("Archivos de servicio: fallo controlado", { fase, tipo: String(err?.name || "Error").slice(0, 50) });
  return json({ ok: false, error: "No se pudo completar esta etapa de la subida. Los archivos confirmados permanecen guardados.", codigo: `ARCHIVOS_${fase}` }, 503);
}
async function pasoDiagnostico(fase, operacion) {
  try { return await operacion(); }
  catch (e) { if (!e.fase) e.fase = fase; throw e; }
}
function lanzar(mensaje, status) { const e = new Error(mensaje); e.status = status; e.publico = mensaje; throw e; }
function validarId(id) { return typeof id === "string" && VALID_ID.test(id); }
function validarContenido(id) { return /^contenido-[1-4]$/.test(id || ""); }
function validarPosicion(v) { if (typeof v !== "string" && typeof v !== "number") return null; const n = Number(v); return Number.isInteger(n) && n >= 0 && n < 10 ? n : null; }
function tiempo() { return new Date(); }
function bucket(env) {
  if (!env?.SERVICIOS_CONTENIDOS_R2?.createMultipartUpload || !env?.SERVICIOS_CONTENIDOS_R2?.get) {
    lanzar("Falta configurar el bucket privado SERVICIOS_CONTENIDOS_R2.", 503);
  }
  return env.SERVICIOS_CONTENIDOS_R2;
}
function nombreSeguro(nombre) {
  const limpio = String(nombre || "").replace(/[\\/\0-\x1f\x7f]/g, "_").trim();
  if (!limpio || limpio.length > 180) lanzar("El nombre del archivo no es válido.", 400);
  return limpio;
}
function maxPosiciones(tipo) { return tipo === "carrusel" ? 10 : 1; }
function tipoValido(tipoContenido, mime) {
  return TIPOS.has(mime) && (tipoContenido === "reel" ? mime === "video/mp4" : mime !== "video/mp4");
}
function firmaCorrecta(bytes, mime) {
  if (bytes.length < 12) return false;
  if (mime === "image/jpeg") return bytes[0] === 255 && bytes[1] === 216 && bytes[2] === 255;
  if (mime === "image/png") return [137,80,78,71,13,10,26,10].every((n,i) => bytes[i] === n);
  if (mime === "image/webp") return String.fromCharCode(...bytes.slice(0,4)) === "RIFF" && String.fromCharCode(...bytes.slice(8,12)) === "WEBP";
  if (mime === "video/mp4") return String.fromCharCode(...bytes.slice(4,8)) === "ftyp";
  return false;
}
function idArchivo(pedidoId, contenidoId, posicion) { return `${pedidoId}:${contenidoId}:${posicion}`; }
function preparacionAutorizada(pedido) {
  const gratis = pedido?.modalidadContratacion === "prueba_gratuita" &&
    pedido?.estadoPago === "no_requerido" && pedido?.metodoPago === "ninguno" &&
    pedido?.prueba?.estado === "pendiente_activacion";
  const pago = pedido?.estadoPago === "confirmado" && Boolean(pedido?.pagadoEn);
  return (gratis || pago) && pedido?.estadoServicio === "sin_activar";
}

function permisoPedido(pedido, escritura) {
  if (!pedido || pedido.tipo !== "publicaciones" || !Array.isArray(pedido.publicaciones) || pedido.publicaciones.length !== 4) lanzar("Pedido no encontrado.", 404);
  if (escritura && (!preparacionAutorizada(pedido) || pedido.estadoContenidos === "aprobados")) {
    lanzar("La carga requiere un pedido habilitado y contenidos todavía no aprobados.", 403);
  }
}
function accesoCliente(request, pedido) {
  const token = /^Bearer ([a-f0-9]{64})$/i.exec(request.headers.get("authorization") || "")?.[1];
  if (!token || !VALID_TOKEN.test(pedido?.tokenAccesoHash)) return false;
  const calculado = crypto.createHash("sha256").update(token).digest();
  return crypto.timingSafeEqual(calculado, Buffer.from(pedido.tokenAccesoHash, "hex"));
}
async function conDb(env, fn) {
  if (!env?.MONGODB_URI) lanzar("MongoDB no está configurado.", 503);
  const client = new MongoClient(env.MONGODB_URI);
  try { await pasoDiagnostico("MONGODB_CONEXION", () => client.connect()); return await fn(client.db(DB)); }
  finally { await client.close().catch(() => {}); }
}
function publicacionesDelPedido(pedido) {
  return pedido.publicaciones.map(p => ({ id: p.id, tipo: p.tipo, descripcion: String(p.descripcion || "").slice(0,1500), diaPreferido: p.diaPreferido, horaLocalPreferida: p.horaLocalPreferida }));
}
async function leerJson(request) {
  if (!/^application\/json(?:;|$)/i.test(request.headers.get("content-type") || "")) lanzar("Se requiere JSON.", 415);
  if (Number(request.headers.get("content-length") || 0) > 4096) lanzar("Solicitud demasiado grande.", 413);
  const texto = await request.text();
  if (texto.length > 4096) lanzar("Solicitud demasiado grande.", 413);
  try { const valor = JSON.parse(texto); if (valor && !Array.isArray(valor) && typeof valor === "object") return valor; }
  catch { /* inválido */ }
  lanzar("JSON inválido.", 400);
}
async function buscarPedido(db, request, env, pedidoId, escritura = false) {
  if (!validarId(pedidoId)) lanzar("Pedido inválido.", 400);
  const pedido = await db.collection("pedidos_servicios").findOne({ pedidoId, tipo: "publicaciones" });
  if (!pedido) lanzar("Pedido no encontrado o acceso no autorizado.", 404);
  const tokenValido = accesoCliente(request, pedido);
  let cuentaValida = false;
  if (!tokenValido && pedido.clienteUsuarioId &&
      request.headers.get("x-comunidad-panel") === "1") {
    const origen = new URL(request.url).origin;
    const headerOrigen = request.headers.get("origin");
    const contexto = request.headers.get("sec-fetch-site");
    // El uso de cookies solo se admite desde el mismo sitio, con cabecera explícita.
    if ((!headerOrigen || headerOrigen === origen) && (!contexto || contexto === "same-origin")) {
      const usuario = await obtenerClienteRegistrado(request, env);
      cuentaValida = Boolean(usuario?.id && usuario.id === pedido.clienteUsuarioId);
    }
  }
  if (!tokenValido && !cuentaValida) lanzar("Pedido no encontrado o acceso no autorizado.", 404);
  permisoPedido(pedido, escritura);
  return pedido;
}
async function estadoArchivos(db, pedido) {
  const archivos = await db.collection("archivos_servicios").find({ pedidoId: pedido.pedidoId, estado: "subido" })
    .project({ _id:0, contenidoId:1, posicion:1, nombre:1, tipo:1, tamano:1, revision:1, motivoRevision:1, subidoEn:1 }).sort({ contenidoId:1, posicion:1 }).toArray();
  return { ok: true, pedidoId: pedido.pedidoId, habilitada: preparacionAutorizada(pedido) && pedido.estadoContenidos !== "aprobados", estadoContenidos: pedido.estadoContenidos || "pendiente_carga", publicaciones: publicacionesDelPedido(pedido), archivos };
}
async function actualizarEstado(db, pedidoId) {
  const pedidos = db.collection("pedidos_servicios");
  const pedido = await pedidos.findOne({ pedidoId, tipo: "publicaciones" });
  if (!pedido) return;
  const archivos = await db.collection("archivos_servicios").find({ pedidoId, estado: "subido" }).project({ contenidoId:1, revision:1 }).toArray();
  const completos = pedido.publicaciones.length === 4 && pedido.publicaciones.every(p => {
    const n = archivos.filter(a => a.contenidoId === p.id).length;
    return n >= (p.tipo === "carrusel" ? 2 : 1) && n <= maxPosiciones(p.tipo);
  });
  const aprobados = completos && archivos.every(a => a.revision === "aprobado");
  const correcciones = archivos.some(a => a.revision === "rechazado");
  const nuevo = correcciones ? "correccion_solicitada" : aprobados ? "aprobados" : completos ? "pendiente_revision" : archivos.length ? "en_preparacion" : "pendiente_carga";
  await pedidos.updateOne({ _id: pedido._id, estadoServicio: "sin_activar" }, { $set: { estadoContenidos: nuevo, archivosSubidos: completos, actualizadoEn: tiempo() } });
}
async function iniciar(request, env, db) {
  const input = await leerJson(request);
  const pedido = await buscarPedido(db, request, env, input.pedidoId, true);
  const p = pedido.publicaciones.find(p => p.id === input.contenidoId);
  const posicion = validarPosicion(input.posicion);
  if (!p || !validarContenido(input.contenidoId) || posicion === null || posicion >= maxPosiciones(p.tipo)) lanzar("Contenido o posición no válidos.", 400);
  const nombre = nombreSeguro(input.nombre);
  const tipo = String(input.tipo || "").toLowerCase();
  const tamano = input.tamano;
  if (!tipoValido(p.tipo, tipo) || !Number.isSafeInteger(tamano) || tamano < 12 || tamano > (tipo === "video/mp4" ? MAX_VIDEO : MAX_IMAGE)) {
    lanzar("Formato o tamaño incorrecto. Se admiten imágenes de 20 MB o videos MP4 de 150 MB como máximo.", 400);
  }
  const id = idArchivo(input.pedidoId, input.contenidoId, posicion);
  const archivos = db.collection("archivos_servicios");
  const previo = await archivos.findOne({ _id:id });
  if (previo?.revision === "aprobado") lanzar("El material aprobado no puede reemplazarse.", 409);
  const cargas = db.collection("cargas_archivos_servicios");
  const anterior = await cargas.findOne({ _id:id });
  // Si el usuario cerró el navegador a mitad de una carga, permitir reemplazarla.
  // Solo las cargas que están finalizando en R2 requieren revisión antes de reintentar.
  if (anterior?.estado === "finalizando") lanzar("Esta carga está finalizando. Consultá el estado antes de reintentar.", 409);
  if (anterior) {
    await env.SERVICIOS_CONTENIDOS_R2.resumeMultipartUpload(anterior.r2Key, anterior.uploadId).abort().catch(() => {});
    await cargas.deleteOne({ _id:id });
  }
  const r2 = bucket(env);
  const r2Key = `contenidos/publicaciones/${input.pedidoId}/${input.contenidoId}/${posicion}/${crypto.randomUUID()}`;
  const carga = await pasoDiagnostico("R2_CREAR", () => r2.createMultipartUpload(r2Key, { httpMetadata: { contentType: tipo } }));
  const cargaId = crypto.randomUUID();
  try {
    await cargas.insertOne({ _id:id, pedidoId:input.pedidoId, contenidoId:input.contenidoId, posicion, nombre, tipo, tamano, r2Key, uploadId:carga.uploadId, cargaId, estado:"abierta", partes:{}, creadaEn:tiempo(), expiraEn:new Date(Date.now()+VENCE_MS) });
  } catch (e) {
    await carga.abort().catch(() => {});
    if (e?.code === 11000) lanzar("Ya existe una carga en curso.", 409);
    throw e;
  }
  return json({ ok:true, cargaId, tamanoParte:PART_SIZE, totalPartes:Math.ceil(tamano/PART_SIZE) }, 201);
}
async function subirParte(request, env, db, url) {
  const pedidoId = url.searchParams.get("pedidoId");
  const cargaId = url.searchParams.get("cargaId");
  const numero = Number(url.searchParams.get("numero"));
  await buscarPedido(db, request, env, pedidoId, true);
  if (!/^[0-9a-f-]{36}$/i.test(cargaId || "") || !Number.isInteger(numero) || numero < 1 || numero > 19) lanzar("Parte no válida.", 400);
  const sesion = await db.collection("cargas_archivos_servicios").findOne({ pedidoId, cargaId, estado:"abierta" });
  if (!sesion || new Date(sesion.expiraEn).getTime() < Date.now()) lanzar("La carga no existe o expiró.", 404);
  const total = Math.ceil(sesion.tamano/PART_SIZE);
  if (numero > total) lanzar("Número de parte inválido.", 400);
  const longitud = numero === total ? sesion.tamano - PART_SIZE*(total-1) : PART_SIZE;
  if (Number(request.headers.get("content-length")) !== longitud) lanzar("El tamaño de esta parte no coincide.", 413);
  if (!/^application\/octet-stream(?:;|$)/i.test(request.headers.get("content-type") || "")) lanzar("Formato de transferencia incorrecto.", 415);
  const bytes = new Uint8Array(await request.arrayBuffer());
  if (bytes.byteLength !== longitud) lanzar("Parte incompleta.", 400);
  if (numero === 1 && !firmaCorrecta(bytes, sesion.tipo)) lanzar("El archivo no coincide con su formato declarado.", 415);
  const r2 = bucket(env);
  const parte = await pasoDiagnostico("R2_PARTE", () => r2.resumeMultipartUpload(sesion.r2Key, sesion.uploadId).uploadPart(numero, bytes));
  await db.collection("cargas_archivos_servicios").updateOne({ _id:sesion._id, cargaId, estado:"abierta" }, { $set: { [`partes.${numero}`]: { partNumber:numero, etag:parte.etag, tamano:longitud } } });
  return json({ ok:true, numero, total });
}
async function finalizar(request, env, db) {
  const input = await leerJson(request);
  await buscarPedido(db, request, env, input.pedidoId, true);
  const carga = await db.collection("cargas_archivos_servicios").findOne({ pedidoId:input.pedidoId, cargaId:input.cargaId, estado:"abierta" });
  if (!carga || new Date(carga.expiraEn).getTime() < Date.now()) lanzar("La carga no existe o expiró.", 404);
  const total = Math.ceil(carga.tamano/PART_SIZE);
  const partes = Array.from({length:total},(_,i)=>carga.partes?.[i+1]);
  if (partes.some((p,i) => !p || p.partNumber !== i+1 || !p.etag || p.tamano !== (i+1===total ? carga.tamano-PART_SIZE*(total-1) : PART_SIZE))) {
    lanzar("Faltan partes por subir.", 409);
  }
  const cargas = db.collection("cargas_archivos_servicios");
  const bloqueo = await cargas.updateOne({ _id:carga._id, cargaId:carga.cargaId, estado:"abierta" }, { $set: { estado:"finalizando" } });
  if (bloqueo.modifiedCount !== 1) lanzar("Otra operación está finalizando esta carga.", 409);
  const r2 = bucket(env);
  try {
    await pasoDiagnostico("R2_COMPLETAR", () => r2.resumeMultipartUpload(carga.r2Key,carga.uploadId).complete(partes.map(p=>({partNumber:p.partNumber, etag:p.etag}))));
    const objeto = await pasoDiagnostico("R2_VERIFICAR", () => r2.head(carga.r2Key));
    if (!objeto || objeto.size !== carga.tamano) lanzar("R2 no confirmó el archivo completo.", 503);
    const coleccion = db.collection("archivos_servicios");
    const anterior = await coleccion.findOne({ _id:carga._id });
    if (anterior?.revision === "aprobado") lanzar("No se puede reemplazar un archivo aprobado.", 409);
    await coleccion.updateOne({ _id:carga._id }, { $set: { pedidoId:carga.pedidoId, contenidoId:carga.contenidoId, posicion:carga.posicion, nombre:carga.nombre, tipo:carga.tipo, tamano:carga.tamano, r2Key:carga.r2Key, estado:"subido", revision:"pendiente", motivoRevision:"", revisadoEn:null, subidoEn:tiempo() } }, { upsert:true });
    await cargas.deleteOne({ _id:carga._id, cargaId:carga.cargaId });
    await actualizarEstado(db,carga.pedidoId);
    if (anterior?.r2Key && anterior.r2Key !== carga.r2Key) await r2.delete(anterior.r2Key).catch(() => {});
    return json({ ok:true, mensaje:"Archivo guardado para revisión." });
  } catch (error) {
    // Si ya se completó en R2, mantener el registro para diagnóstico administrativo.
    const existe = await r2.head(carga.r2Key).catch(() => null);
    if (!existe) await cargas.updateOne({ _id:carga._id, estado:"finalizando" }, { $set:{ estado:"abierta" } }).catch(() => {});
    throw error;
  }
}
async function cancelar(request, env, db) {
  const input = await leerJson(request);
  await buscarPedido(db, request, env, input.pedidoId, true);
  const carga = await db.collection("cargas_archivos_servicios").findOne({ pedidoId:input.pedidoId, cargaId:input.cargaId, estado:"abierta" });
  if (!carga) return json({ok:true});
  await bucket(env).resumeMultipartUpload(carga.r2Key,carga.uploadId).abort().catch(() => {});
  await db.collection("cargas_archivos_servicios").deleteOne({ _id:carga._id, cargaId:carga.cargaId });
  return json({ok:true});
}
async function eliminar(request, env, db) {
  const input = await leerJson(request);
  await buscarPedido(db, request, env, input.pedidoId, true);
  const posicion = validarPosicion(input.posicion);
  if (!validarContenido(input.contenidoId) || posicion === null) lanzar("Archivo inválido.",400);
  const id = idArchivo(input.pedidoId,input.contenidoId,posicion);
  const archivos = db.collection("archivos_servicios");
  const archivo = await archivos.findOne({ _id:id, pedidoId:input.pedidoId });
  if (!archivo) lanzar("Archivo no encontrado.",404);
  if (archivo.revision === "aprobado") lanzar("El archivo aprobado no se puede eliminar.",409);
  const resultado = await archivos.deleteOne({ _id:id, revision:{$ne:"aprobado"} });
  if (!resultado.deletedCount) lanzar("El estado del archivo cambió. Actualizá el pedido.",409);
  await actualizarEstado(db,input.pedidoId);
  await bucket(env).delete(archivo.r2Key).catch(() => {});
  return json({ok:true});
}
export async function ejecutarArchivosPedido(request, env) {
  let accion = "SOLICITUD";
  try {
    const url = new URL(request.url);
    accion = url.pathname.slice(RUTA.length+1).toUpperCase();
    const ruta = accion.toLowerCase();
    const metodos = {estado:"GET",iniciar:"POST",parte:"PUT",finalizar:"POST",cancelar:"POST",eliminar:"POST"};
    if (!(ruta in metodos)) return fallo("Ruta no disponible.",404);
    if (request.method !== metodos[ruta]) return fallo("Método no permitido.",405);
    bucket(env);
    return await conDb(env, async db => {
      if (ruta === "estado") { const pedido = await buscarPedido(db, request, env, url.searchParams.get("pedidoId")); return json(await estadoArchivos(db,pedido)); }
      if (ruta === "iniciar") return iniciar(request,env,db);
      if (ruta === "parte") return subirParte(request,env,db,url);
      if (ruta === "finalizar") return finalizar(request,env,db);
      if (ruta === "cancelar") return cancelar(request,env,db);
      return eliminar(request,env,db);
    });
  } catch(e) { return errorSeguro(e, accion); }
}
function escapar(s) { return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"})[c]); }
function html(titulo, cuerpo, status=200) {
  return new Response(`<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escapar(titulo)}</title><style>
  :root{color-scheme:light}*{box-sizing:border-box}
  body{margin:0;background:#f8fafb;color:#26303c;font:400 14px/1.6 Montserrat,system-ui,-apple-system,sans-serif}
  main{max-width:1020px;margin:0 auto;padding:36px 22px 70px}
  .topbar{display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;margin-bottom:32px;color:#73808b;font-size:12px}
  .topbar a{color:#526171;text-decoration:none}.topbar a:hover{text-decoration:underline}
  .encabezado{margin-bottom:26px}.encabezado p{color:#73808b;font-size:13px;margin:8px 0 0}
  h1{font-size:clamp(21px,3vw,27px);letter-spacing:-.035em;line-height:1.3;font-weight:500;margin:0}
  h2{font-size:16px;font-weight:500;line-height:1.4;margin:0}h3{font-size:14px;font-weight:500;margin:0}
  p{line-height:1.65;margin:9px 0}.muted,small{color:#788592;font-size:12px}
  section{border:1px solid #e9edf1;border-radius:10px;padding:24px 26px;margin:18px 0;background:#fff}
  .seccion-cabecera{display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;margin-bottom:10px}
  a{color:#526779;text-decoration:none}a:hover{text-decoration:underline}
  .meta-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin:14px 0}
  .dato{padding:13px 15px;background:#fafbfc;border:1px solid #f0f2f4;border-radius:8px;min-width:0}
  .dato small{display:block;margin-bottom:5px}.dato strong{font-weight:500;overflow-wrap:anywhere}
  .chip{display:inline-flex;align-items:center;background:#f7f9fa;border:1px solid #e8ecf0;border-radius:100px;padding:3px 9px;font-size:11px;color:#637281;font-weight:500}
  .archivo{display:grid;grid-template-columns:110px minmax(0,1fr);gap:18px;align-items:start;padding:18px 0;border-top:1px solid #f0f2f4}
  .media{width:110px;height:104px;border-radius:8px;overflow:hidden;background:#f4f6f8;border:1px solid #e9edf1;display:flex;align-items:center;justify-content:center}
  .media img,.media video{display:block;max-width:100%;max-height:100%;width:100%;height:100%;object-fit:contain}
  .archivo-info{min-width:0}.archivo-info p{margin:0 0 6px}.archivo-info .nombre{font-weight:500;overflow-wrap:anywhere}
  .botonera{display:flex;flex-wrap:wrap;gap:10px;margin:12px 0 0;align-items:center}
  input,button,select,textarea{font:inherit;border:1px solid #dce3e9;border-radius:7px;padding:9px 12px}
  input{max-width:100%;min-height:40px}.busqueda{display:flex;align-items:center;flex-wrap:wrap;gap:10px;margin-top:14px}
  .busqueda input{width:360px}button{background:#3d5263;color:#fff;border-color:#3d5263;cursor:pointer;min-height:38px;font-weight:500}
  button:hover{background:#283b4a}.correccion button{background:#fff;color:#815b50;border-color:#e5d9d5}
  .correccion button:hover{background:#fbf7f5}
  input:focus-visible,button:focus-visible,textarea:focus-visible,summary:focus-visible,a:focus-visible{outline:2px solid #8d9eae;outline-offset:2px}
  .correccion{margin-top:10px;border:1px solid #e9edf1;border-radius:8px;padding:10px 12px;max-width:560px}
  .correccion summary{font-weight:500;font-size:12px;color:#835b50;cursor:pointer}
  .correccion form{margin:12px 0 0}.correccion label{display:block;font-size:12px;color:#52606d}
  textarea{display:block;width:100%;max-width:100%;margin:8px 0 12px;min-height:88px;resize:vertical;font:inherit}
  .copy{margin:12px 0 16px;border-left:2px solid #edf0f3;padding:0 14px;overflow-wrap:anywhere;white-space:pre-wrap;color:#465361}
  .mensaje{border-radius:8px;background:#fafbfc;color:#75808a;padding:12px 14px;margin-top:15px;font-size:12px}
  .footer-nav{display:flex;flex-wrap:wrap;gap:10px;margin-top:28px}
  .enlace-suave{display:inline-block;border:1px solid #e3e8ed;border-radius:7px;padding:8px 12px;font-size:12px;font-weight:500}
  code{overflow-wrap:anywhere;font-size:12px}
  @media(max-width:640px){main{padding:24px 14px 45px}.topbar{margin-bottom:24px}section{padding:18px 16px;margin:14px 0}.archivo{grid-template-columns:80px minmax(0,1fr);gap:12px}.media{width:80px;height:80px}.meta-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.busqueda input{width:100%}.busqueda button{width:100%}}
  @media(max-width:390px){.meta-grid{grid-template-columns:1fr}.archivo{grid-template-columns:1fr}.media{width:110px;height:100px}}
  </style></head><body><main><div class="topbar"><a href="/admin">← Administración</a><span>Publicaciones automáticas · Revisión técnica</span></div><header class="encabezado"><h1>${escapar(titulo)}</h1><p>Verificá los archivos de cada contenido antes de aprobar o solicitar correcciones.</p></header>${cuerpo}<nav class="footer-nav"><a class="enlace-suave" href="/admin">Volver a Administración</a><a class="enlace-suave" href="/api/admin/servicios/publicaciones/programacion">Programación de semanas</a></nav></main></body></html>`, {status,headers:{"Content-Type":"text/html; charset=utf-8","Cache-Control":"no-store","Referrer-Policy":"no-referrer","X-Content-Type-Options":"nosniff","Content-Security-Policy":"default-src 'none'; style-src 'unsafe-inline'; img-src 'self'; media-src 'self'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'"}});
}
// Token antifalsificacion para formularios de revision de Administración.
// Mantiene la proteccion CSRF aunque el navegador omita Origin en un POST.
const DURACION_REVISION_SEGUNDOS = 30 * 60;
function firmaRevision(env, pedidoId, contenidoId, posicion, marca) {
  const clave = String(env?.ADMIN_PASSWORD ?? "");
  if (!clave) return "";
  const datos = `revision-archivos-v1\n${pedidoId}\n${contenidoId}\n${posicion}\n${marca}`;
  return crypto.createHmac("sha256", clave).update(datos).digest("hex");
}
function tokenRevision(env, pedidoId, contenidoId, posicion) {
  const marca = Math.floor(Date.now() / 1000);
  return `${marca}.${firmaRevision(env, pedidoId, contenidoId, posicion, marca)}`;
}
function tokenRevisionValido(env, pedidoId, contenidoId, posicion, valor) {
  const coincidencia = /^(\d{10,12})\.([a-f0-9]{64})$/.exec(String(valor || ""));
  if (!coincidencia) return false;
  const marca = Number(coincidencia[1]);
  const ahora = Math.floor(Date.now() / 1000);
  if (!Number.isSafeInteger(marca) || marca > ahora + 60 || ahora - marca > DURACION_REVISION_SEGUNDOS) return false;
  const esperada = firmaRevision(env, pedidoId, contenidoId, posicion, marca);
  return /^[a-f0-9]{64}$/.test(esperada) && crypto.timingSafeEqual(Buffer.from(coincidencia[2], "hex"), Buffer.from(esperada, "hex"));
}
function origenRevisionAceptable(request, url) {
  const origen = request.headers.get("origin");
  // Algunos navegadores aplican Referrer-Policy: no-referrer y envian Origin: null.
  // En todos los casos se requiere tambien el token CSRF firmado.
  if (origen && origen !== "null" && origen !== url.origin) return false;
  const contexto = request.headers.get("sec-fetch-site");
  if (contexto && contexto !== "same-origin") return false;
  return true;
}
export async function ejecutarAdminArchivosPedido(request, env, autorizado) {
  if (!autorizado) return html("Acceso no autorizado","<p>Iniciá sesión en Administración.</p>",401);
  const url = new URL(request.url);
  const pedidoId = url.searchParams.get("pedidoId");
  if(url.searchParams.has('semanaId')){
    const { ejecutarAdminSemanaPagada } = await import('./admin-semanas-pagadas.js');
    return ejecutarAdminSemanaPagada(request,env,autorizado,'archivos');
  }
  try {
    bucket(env);
    if (request.method === "GET") {
      if (!pedidoId) return await conDb(env,async db=>{
        const { listarRenovacionesPendientes }=await import('./admin-semanas-pagadas.js');
        const pagadas=await listarRenovacionesPendientes(db);
        const links=pagadas.map(x=>`<p><a class="enlace-suave" href="${RUTA_ADMIN}?semanaId=${encodeURIComponent(x._id)}">Semana ${Number(x.numeroSemana)||2} · ${escapar(x.email||'Cliente')} · ${escapar(x.configuracionEstado)}</a></p>`).join('');
        return html("Revisión de contenidos",`<section><h2>Semanas pagadas reales</h2>${links||'<p>Sin semanas pagadas pendientes.</p>'}</section><section><h2>Buscar prueba gratuita</h2><form class="busqueda" method="get"><input aria-label="ID del pedido" name="pedidoId" placeholder="ID del pedido · SER-..." required><button type="submit">Buscar pedido</button></form></section>`);
      });
      if (!validarId(pedidoId)) return html("Pedido incorrecto","<p>El código es inválido.</p>",400);
      return await conDb(env, async db => {
        const pedido = await db.collection("pedidos_servicios").findOne({pedidoId,tipo:"publicaciones"});
        if (!pedido) return html("Pedido no encontrado","<p>No existe ese pedido.</p>",404);
        const pos = validarPosicion(url.searchParams.get("posicion"));
        const contenidoId = url.searchParams.get("contenidoId");
        if (url.searchParams.get("accion") === "ver") {
          if (!validarContenido(contenidoId) || pos === null) return html("Archivo incorrecto","<p>Parámetros inválidos.</p>",400);
          const archivo = await db.collection("archivos_servicios").findOne({ _id:idArchivo(pedidoId,contenidoId,pos), estado:"subido" });
          if (!archivo) return html("No disponible","<p>Archivo no encontrado.</p>",404);
          // Soporta Range para reproducir videos desde el navegador móvil sin
          // descargar el MP4 completo en cada solicitud.
          const rangoCabecera = request.headers.get("range");
          let rango = null;
          if (rangoCabecera) {
            const m = /^bytes=(\d+)-(\d*)$/.exec(rangoCabecera);
            if (!m) return new Response(null, { status:416,headers:{"Content-Range":`bytes */${archivo.tamano}`} });
            const inicio = Number(m[1]);
            const fin = m[2] ? Number(m[2]) : archivo.tamano-1;
            if (!Number.isSafeInteger(inicio) || !Number.isSafeInteger(fin) || inicio>fin || fin>=archivo.tamano) {
              return new Response(null, { status:416,headers:{"Content-Range":`bytes */${archivo.tamano}`} });
            }
            rango = { offset:inicio,length:fin-inicio+1 };
          }
          const objeto = await bucket(env).get(archivo.r2Key, rango ? {range:rango} : undefined);
          if (!objeto) return html("No disponible","<p>Archivo privado no encontrado en R2.</p>",404);
          const headers = {"Content-Type":archivo.tipo,"Content-Disposition":"inline","Cache-Control":"private, no-store","X-Content-Type-Options":"nosniff","Content-Security-Policy":"default-src 'none'","Accept-Ranges":"bytes","Content-Length":String(rango?rango.length:archivo.tamano)};
          if (rango) headers["Content-Range"] = `bytes ${rango.offset}-${rango.offset+rango.length-1}/${archivo.tamano}`;
          return new Response(objeto.body,{ status:rango?206:200,headers });
        }
        const archivos = await db.collection("archivos_servicios").find({pedidoId,estado:"subido"}).sort({contenidoId:1,posicion:1}).toArray();
        const revisable = preparacionAutorizada(pedido);
        const tarjetas = pedido.publicaciones.map((p, indice) => {
          const lista = archivos.filter(a => a.contenidoId === p.id);
          return `<section><div class="seccion-cabecera"><h2>Contenido ${indice + 1} · ${escapar(p.tipo)}</h2><span class="chip">${lista.length} archivo${lista.length === 1 ? "" : "s"}</span></div><p class="muted">${escapar(p.diaPreferido || "Día sin definir")} · ${escapar(p.horaLocalPreferida || "Horario sin definir")} hora local</p><div class="copy">${escapar(p.descripcion || "Sin texto de publicación")}</div>${lista.length ? lista.map(a => {
            const enlace = `${RUTA_ADMIN}?pedidoId=${encodeURIComponent(pedidoId)}&accion=ver&contenidoId=${encodeURIComponent(p.id)}&posicion=${a.posicion}`;
            const medio = a.tipo.startsWith("image/") ? `<img src="${escapar(enlace)}" alt="${escapar(a.nombre)}" loading="lazy">` : `<video src="${escapar(enlace)}" controls preload="none" playsinline></video>`;
            const csrf = tokenRevision(env, pedidoId, p.id, a.posicion);
            const campos = `<input type="hidden" name="pedidoId" value="${escapar(pedidoId)}"><input type="hidden" name="contenidoId" value="${escapar(p.id)}"><input type="hidden" name="posicion" value="${a.posicion}"><input type="hidden" name="csrfRevision" value="${escapar(csrf)}">`;
            const motivoAnterior = a.revision === "rechazado" && a.motivoRevision ? `<p class="mal"><small>Corrección anterior: ${escapar(a.motivoRevision)}</small></p>` : "";
            const estadoArchivo = a.revision === "aprobado" ? "Aprobado" : a.revision === "rechazado" ? "Corrección solicitada" : "Pendiente de revisión";
            return `<article class="archivo"><div class="media">${medio}</div><div class="archivo-info"><p class="nombre">${escapar(a.nombre)}</p><p class="muted">${Math.ceil(a.tamano/1024)} KB · Archivo ${a.posicion + 1}</p><p><span class="chip">${estadoArchivo}</span></p>${motivoAnterior}${revisable ? `
              <div class="botonera"><form action="${RUTA_ADMIN}" method="post">${campos}<button name="revision" value="aprobado">Aprobar técnicamente</button></form></div>
              <details class="correccion"><summary>Solicitar corrección</summary><form action="${RUTA_ADMIN}" method="post">${campos}<label>Motivo técnico de la corrección (10 a 500 caracteres)<textarea name="motivoRevision" minlength="10" maxlength="500" required placeholder="Ej.: El archivo MP4 no puede reproducirse; volvé a exportarlo."></textarea></label><button name="revision" value="rechazado">Enviar solicitud de corrección</button></form></details>` : '<p class="muted">La revisión de archivos está cerrada para este pedido.</p>'}</div></article>`;
          }).join("") : '<div class="mensaje">Todavía no hay archivos cargados para este contenido.</div>'}</section>`;
        }).join("");
        return html("Revisión de contenidos",`<section><div class="seccion-cabecera"><h2>Resumen del pedido</h2><a class="enlace-suave" href="/api/admin/servicios/publicaciones/programacion?pedidoId=${encodeURIComponent(pedidoId)}">Ver programación ↗</a></div><div class="meta-grid"><div class="dato"><small>ID del pedido</small><strong>${escapar(pedidoId)}</strong></div><div class="dato"><small>Estado del contenido</small><strong>${escapar((pedido.estadoContenidos || "—").replaceAll("_", " "))}</strong></div><div class="dato"><small>Estado del pago</small><strong>${escapar((pedido.estadoPago || "—").replaceAll("_", " "))}</strong></div><div class="dato"><small>Archivos recibidos</small><strong>${archivos.length}</strong></div></div>${pedidoId === "SER-7ebdd0fa-4795-4cd9-a688-a72a1e26b937" ? `<p><a class="enlace-suave" href="/api/admin/servicios/publicaciones/activacion-simulada?pedidoId=${encodeURIComponent(pedidoId)}">Simular activación (sin publicar)</a></p>` : ""}</section>${tarjetas}<div class="mensaje">La aprobación técnica de archivos no activa ni programa publicaciones. La activación se gestiona por separado.</div>`);
      });
    }
    if (request.method === "POST") {
      if (!origenRevisionAceptable(request, url)) return html("Origen no autorizado","<p>Volvé a abrir la pantalla de revisión.</p>",403);
      if (Number(request.headers.get("content-length") || 0)>2048) return html("Solicitud grande","<p>Solicitud inválida.</p>",413);
      const cuerpo = await request.text();
      if (cuerpo.length > 2048) return html("Solicitud grande","<p>Solicitud inválida.</p>",413);
      const form = new URLSearchParams(cuerpo);
      const pid = form.get("pedidoId"), cid = form.get("contenidoId"), pos = validarPosicion(form.get("posicion")), revision = form.get("revision");
      if (!validarId(pid) || !validarContenido(cid) || pos===null || !["aprobado","rechazado"].includes(revision)) return html("Revisión inválida","<p>Datos incorrectos.</p>",400);
      if (!tokenRevisionValido(env, pid, cid, pos, form.get("csrfRevision"))) return html("Revisión vencida","<p>Volvé a abrir la pantalla de revisión y repetí la acción.</p>",403);
      const motivoRevision = typeof form.get("motivoRevision") === "string" ? form.get("motivoRevision").trim() : "";
      if (revision === "rechazado" && (motivoRevision.length < 10 || motivoRevision.length > 500)) {
        return html("Motivo necesario","<p>Explicá el problema técnico o de cumplimiento en 10 a 500 caracteres. No se revisan preferencias creativas.</p>",400);
      }
      return await conDb(env, async db => {
        const pedido = await db.collection("pedidos_servicios").findOne({pedidoId:pid,tipo:"publicaciones"});
        if (!pedido || !preparacionAutorizada(pedido)) return html("Pedido no habilitado","<p>Se requiere un pedido habilitado y todavía no activado.</p>",403);
        const result = await db.collection("archivos_servicios").updateOne({ _id:idArchivo(pid,cid,pos), pedidoId:pid, estado:"subido" },{ $set:{ revision, motivoRevision: revision === "rechazado" ? motivoRevision : "", revisadoEn:tiempo() } });
        if (!result.matchedCount) return html("Archivo no encontrado","<p>El archivo ya no existe.</p>",404);
        await actualizarEstado(db,pid);
        return Response.redirect(`${url.origin}${RUTA_ADMIN}?pedidoId=${encodeURIComponent(pid)}`,303);
      });
    }
    return html("Método inválido","<p>Operación no admitida.</p>",405);
  } catch (e) { console.error("Error revisión de contenidos:",e?.message || "Error"); return html("Revisión no disponible","<p>No fue posible revisar los archivos.</p>",503); }
}
